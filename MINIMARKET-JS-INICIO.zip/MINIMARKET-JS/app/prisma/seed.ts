import { todayChile, dateOnly } from "../lib/dates";
import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
const db = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});
async function main() {
  if (process.env.NODE_ENV === "production")
    throw Error("Los datos de demostración no se cargan en producción");
  for (const [email, name, role] of [
    ["admin@demo.local", "Administrador demo", "ADMIN"],
    ["caja@demo.local", "Trabajador demo", "WORKER"],
  ])
    await db.user.upsert({
      where: { email },
      update: {},
      create: { email, name, role, password: await hash("Demo2026!local", 12) },
    });
  for (const [barcode, name, brand, price, cost, stock, minimum] of [
    ["DEMO001", "Leche entera 1 L", "Marca demo", 1250, 850, 24, 10],
    ["DEMO002", "Arroz 1 kg", "Marca demo", 1490, 950, 8, 10],
    ["DEMO003", "Bebida 1,5 L", "Marca demo", 1990, 1200, 18, 6],
    ["DEMO004", "Pan de molde", "Marca demo", 2390, 1600, 4, 5],
  ] as const)
    await db.product.upsert({
      where: { barcode },
      update: {},
      create: { barcode, name, brand, price, cost, stock, minimum, demo: true },
    });
  const supplier = await db.supplier.upsert({
    where: { id: "supplier-demo" },
    update: {},
    create: {
      id: "supplier-demo",
      demo: true,
      name: "Distribuidora ficticia · DEMO",
      phone: "",
    },
  });
  const date = dateOnly(todayChile());
  await db.supplierOrder.upsert({
    where: { id: "order-demo" },
    update: {},
    create: {
      id: "order-demo",
      supplierId: supplier.id,
      date,
      detail:
        "12 unidades de leche entera 1 L · Marca demo\n6 unidades de arroz 1 kg · Marca demo",
      budget: 15900,
    },
  });
  console.log(
    "Datos ficticios cargados. Credenciales de demostración: ver README.",
  );
}
main().finally(() => db.$disconnect());

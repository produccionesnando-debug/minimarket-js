-- CreateTable
CREATE TABLE "GoogleAccount" (
    "id" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "linkedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "GoogleAccount_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GoogleGrant" (
    "email" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "approvedBy" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GoogleGrant_pkey" PRIMARY KEY ("email")
);

-- CreateTable
CREATE TABLE "GoogleAttempt" (
    "state" TEXT NOT NULL,
    "verifier" TEXT NOT NULL,
    "nonce" TEXT NOT NULL,
    "browserHash" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GoogleAttempt_pkey" PRIMARY KEY ("state")
);

-- CreateTable
CREATE TABLE "ClientConversation" (
    "id" TEXT NOT NULL,
    "requestKey" TEXT NOT NULL,
    "customerId" TEXT,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "source" TEXT NOT NULL DEFAULT 'MANUAL',
    "status" TEXT NOT NULL DEFAULT 'NUEVO',
    "assignedId" TEXT NOT NULL,
    "demo" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ClientConversation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClientMessage" (
    "id" TEXT NOT NULL,
    "externalId" TEXT,
    "conversationId" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "direction" TEXT NOT NULL DEFAULT 'ENTRANTE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actorId" TEXT,

    CONSTRAINT "ClientMessage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClientOrder" (
    "id" TEXT NOT NULL,
    "requestKey" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "customerId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'SOLICITADO',
    "mode" TEXT NOT NULL DEFAULT 'RETIRO',
    "requestedAt" TIMESTAMP(3),
    "notes" TEXT NOT NULL DEFAULT '',
    "createdBy" TEXT NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "saleId" TEXT,
    "demo" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "ClientOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClientOrderItem" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "productId" TEXT,
    "description" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "price" INTEGER,
    "reserved" BOOLEAN NOT NULL DEFAULT false,
    "supplierId" TEXT,
    "committedAt" TIMESTAMP(3),
    "procurement" TEXT NOT NULL DEFAULT 'PENDIENTE',

    CONSTRAINT "ClientOrderItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuickReply" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "body" TEXT NOT NULL,

    CONSTRAINT "QuickReply_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MessagingSettings" (
    "id" TEXT NOT NULL DEFAULT 'global',
    "retentionDays" INTEGER NOT NULL DEFAULT 365,
    "inboundEnabled" BOOLEAN NOT NULL DEFAULT false,
    "assignedId" TEXT,

    CONSTRAINT "MessagingSettings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "GoogleAccount_subject_key" ON "GoogleAccount"("subject");

-- CreateIndex
CREATE UNIQUE INDEX "GoogleAccount_userId_key" ON "GoogleAccount"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "GoogleGrant_userId_key" ON "GoogleGrant"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "ClientConversation_requestKey_key" ON "ClientConversation"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "ClientMessage_externalId_key" ON "ClientMessage"("externalId");

-- CreateIndex
CREATE UNIQUE INDEX "ClientOrder_requestKey_key" ON "ClientOrder"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "ClientOrder_saleId_key" ON "ClientOrder"("saleId");

-- AddForeignKey
ALTER TABLE "ClientMessage" ADD CONSTRAINT "ClientMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "ClientConversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClientOrder" ADD CONSTRAINT "ClientOrder_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "ClientConversation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClientOrderItem" ADD CONSTRAINT "ClientOrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "ClientOrder"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "Collection" ADD COLUMN "orderId" TEXT;
ALTER TABLE "Collection" ADD CONSTRAINT "Collection_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "ClientOrder"(id);
ALTER TABLE "Collection" DROP CONSTRAINT "collection_direction";
ALTER TABLE "Collection" ADD CONSTRAINT "collection_direction" CHECK ((kind IN ('REEMBOLSO','REEMBOLSO_ANTICIPO') AND amount<0) OR (kind IN ('VENTA','ABONO','INGRESO','ANTICIPO') AND amount>0));
ALTER TABLE "ClientOrderItem" ADD CONSTRAINT "client_item_valid" CHECK (quantity>0 AND (price IS NULL OR price>=0));
INSERT INTO "MessagingSettings" (id,"retentionDays","inboundEnabled") VALUES ('global',365,false);
INSERT INTO "QuickReply" (id,title,body) VALUES
('reply-received','Recepción de pedido','Recibimos tu solicitud. Un trabajador revisará los productos y te confirmará disponibilidad.'),
('reply-stock','Disponibilidad','Estamos consultando disponibilidad de los productos solicitados.'),
('reply-price','Información de precios','Revisaremos los precios del pedido antes de confirmarlo contigo.'),
('reply-preparing','En preparación','Tu pedido confirmado está en preparación.'),
('reply-ready','Listo para retirar','Tu encargo está listo para retirar en el local. Confirma tu horario con el trabajador.'),
('reply-delivered','Entrega','Gracias. Por favor confirma que recibiste tu pedido.');

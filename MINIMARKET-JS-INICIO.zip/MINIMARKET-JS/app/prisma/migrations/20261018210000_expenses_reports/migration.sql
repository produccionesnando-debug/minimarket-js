-- DropForeignKey
ALTER TABLE "Expense" DROP CONSTRAINT "Expense_shiftId_fkey";

-- AlterTable
ALTER TABLE "Expense" ADD COLUMN     "actorId" TEXT,
ADD COLUMN     "bankAccountId" TEXT,
ADD COLUMN     "beneficiary" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "category" TEXT NOT NULL DEFAULT 'Sin categoría',
ADD COLUMN     "demo" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "method" TEXT NOT NULL DEFAULT 'EFECTIVO',
ADD COLUMN     "notes" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "requestKey" TEXT,
ADD COLUMN     "responsibleId" TEXT,
ADD COLUMN     "reviewedAt" TIMESTAMP(3),
ADD COLUMN     "reviewedById" TEXT,
ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'PENDIENTE',
ADD COLUMN     "version" INTEGER NOT NULL DEFAULT 0,
ALTER COLUMN "shiftId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "Sale" ADD COLUMN     "actorId" TEXT,
ADD COLUMN     "demo" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "requestKey" TEXT;

-- AlterTable
ALTER TABLE "SaleItem" ADD COLUMN     "category" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "unitCost" INTEGER;

-- AlterTable
ALTER TABLE "Shift" ADD COLUMN     "demo" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "openedById" TEXT,
ADD COLUMN     "reviewNotes" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "reviewStatus" TEXT NOT NULL DEFAULT 'PENDIENTE',
ADD COLUMN     "reviewedAt" TIMESTAMP(3),
ADD COLUMN     "reviewedById" TEXT;

-- AlterTable
ALTER TABLE "SupplierPayment" ADD COLUMN     "bankAccountId" TEXT;

-- CreateTable
CREATE TABLE "ExpenseAttachment" (
    "id" TEXT NOT NULL,
    "expenseId" TEXT NOT NULL,
    "storageKey" TEXT NOT NULL,
    "originalName" TEXT NOT NULL,
    "mime" TEXT NOT NULL,
    "bytes" INTEGER NOT NULL,
    "sha256" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ExpenseAttachment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExpenseRevision" (
    "id" TEXT NOT NULL,
    "expenseId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "changes" JSONB NOT NULL,
    "reason" TEXT NOT NULL,
    "actorId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDIENTE',
    "reviewedById" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ExpenseRevision_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BankAccount" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "initialBalance" INTEGER,
    "balanceDate" TIMESTAMP(3),
    "active" BOOLEAN NOT NULL DEFAULT true,
    "demo" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "BankAccount_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BankMovement" (
    "id" TEXT NOT NULL,
    "accountId" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "amount" INTEGER NOT NULL,
    "description" TEXT NOT NULL,
    "actorId" TEXT NOT NULL,
    "requestKey" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BankMovement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FinanceReserve" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "FinanceReserve_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FinanceConfig" (
    "id" TEXT NOT NULL DEFAULT 'global',
    "fundsConfirmed" BOOLEAN NOT NULL DEFAULT false,
    "reservesConfirmed" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "FinanceConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ChannelOrder" (
    "id" TEXT NOT NULL,
    "channel" TEXT NOT NULL DEFAULT 'PEDIDOSYA',
    "demo" BOOLEAN NOT NULL DEFAULT true,
    "status" TEXT NOT NULL DEFAULT 'RECIBIDO',
    "customerLabel" TEXT NOT NULL,
    "lines" JSONB NOT NULL,
    "total" INTEGER NOT NULL,
    "version" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ChannelOrder_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ExpenseAttachment_storageKey_key" ON "ExpenseAttachment"("storageKey");

-- CreateIndex
CREATE UNIQUE INDEX "ExpenseAttachment_expenseId_sha256_key" ON "ExpenseAttachment"("expenseId", "sha256");

-- CreateIndex
CREATE UNIQUE INDEX "BankMovement_requestKey_key" ON "BankMovement"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "Expense_requestKey_key" ON "Expense"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "Sale_requestKey_key" ON "Sale"("requestKey");

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_shiftId_fkey" FOREIGN KEY ("shiftId") REFERENCES "Shift"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_responsibleId_fkey" FOREIGN KEY ("responsibleId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES "BankAccount"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierPayment" ADD CONSTRAINT "SupplierPayment_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES "BankAccount"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExpenseAttachment" ADD CONSTRAINT "ExpenseAttachment_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES "Expense"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExpenseRevision" ADD CONSTRAINT "ExpenseRevision_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES "Expense"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BankMovement" ADD CONSTRAINT "BankMovement_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "BankAccount"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Existing expenses were cash outflows. Preserve their Chilean business date.
UPDATE "Expense" e SET "responsibleId"=s."userId", "actorId"=s."userId", "occurredAt"=((e."createdAt" AT TIME ZONE 'UTC') AT TIME ZONE 'America/Santiago')::date::timestamp FROM "Shift" s WHERE e."shiftId"=s."id";
UPDATE "Expense" e SET "occurredAt"=p."date", "category"='Pago proveedor' FROM "SupplierPayment" p WHERE e."paymentId"=p."id";
ALTER TABLE "Expense" ADD CONSTRAINT "expense_method" CHECK ("method" IN ('EFECTIVO','DEBITO','CREDITO','TRANSFERENCIA'));
ALTER TABLE "Expense" ADD CONSTRAINT "expense_status" CHECK ("status" IN ('PENDIENTE','APROBADO','ANULADO'));
ALTER TABLE "Expense" ADD CONSTRAINT "expense_cash_source" CHECK ("method"<>'EFECTIVO' OR "shiftId" IS NOT NULL);
ALTER TABLE "BankMovement" ADD CONSTRAINT "bank_nonzero" CHECK ("amount"<>0);
ALTER TABLE "FinanceReserve" ADD CONSTRAINT "reserve_nonnegative" CHECK ("amount">=0);
ALTER TABLE "ChannelOrder" ADD CONSTRAINT "channel_demo_only" CHECK ("demo"=true);

-- AlterTable
ALTER TABLE "Expense" ADD COLUMN     "kind" TEXT NOT NULL DEFAULT 'OPERATIVO',
ADD COLUMN     "paymentId" TEXT;

-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "category" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "flavor" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "presentation" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "unitType" TEXT NOT NULL DEFAULT 'UNIDAD';

-- AlterTable
ALTER TABLE "Supplier" ADD COLUMN     "importKey" TEXT,
ADD COLUMN     "paymentDayCount" TEXT NOT NULL DEFAULT 'PENDIENTE',
ADD COLUMN     "paymentDays" INTEGER,
ADD COLUMN     "paymentRule" TEXT NOT NULL DEFAULT 'PENDIENTE',
ADD COLUMN     "paymentWeekday" INTEGER,
ADD COLUMN     "preferCash" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "SupplierContact" ADD COLUMN     "importKey" TEXT;

-- AlterTable
ALTER TABLE "SupplierOrder" ADD COLUMN     "confirmedAt" TIMESTAMP(3),
ADD COLUMN     "cycleId" TEXT,
ADD COLUMN     "estimatedComplete" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "occurrenceKey" TEXT,
ADD COLUMN     "receivedAt" TIMESTAMP(3),
ADD COLUMN     "structured" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "SupplierCycle" (
    "id" TEXT NOT NULL,
    "importKey" TEXT,
    "supplierId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "anchorDay" INTEGER,
    "options" JSONB NOT NULL DEFAULT '[]',
    "allowedDays" INTEGER[] DEFAULT ARRAY[]::INTEGER[],
    "recommendedDay" INTEGER,
    "businessLeadDays" INTEGER,
    "intervalDays" INTEGER,
    "nextOrderDate" TIMESTAMP(3),
    "excludedDates" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "active" BOOLEAN NOT NULL DEFAULT true,
    "version" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SupplierCycle_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SupplierOrderLine" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "brand" TEXT NOT NULL,
    "presentation" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "estimatedCost" INTEGER,
    "receivedCost" INTEGER,

    CONSTRAINT "SupplierOrderLine_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StockMovement" (
    "id" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "orderLineId" TEXT,
    "type" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "unitCost" INTEGER,
    "note" TEXT NOT NULL,
    "actorId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "StockMovement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PurchaseInvoice" (
    "id" TEXT NOT NULL,
    "supplierId" TEXT NOT NULL,
    "orderId" TEXT,
    "reference" TEXT NOT NULL,
    "issuedAt" TIMESTAMP(3) NOT NULL,
    "receivedAt" TIMESTAMP(3) NOT NULL,
    "dueDate" TIMESTAMP(3),
    "amount" INTEGER NOT NULL,
    "notes" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PurchaseInvoice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SupplierPayment" (
    "id" TEXT NOT NULL,
    "invoiceId" TEXT NOT NULL,
    "requestKey" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "amount" INTEGER NOT NULL,
    "method" TEXT NOT NULL,
    "reference" TEXT NOT NULL DEFAULT '',
    "actorId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SupplierPayment_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "SupplierCycle_importKey_key" ON "SupplierCycle"("importKey");

-- CreateIndex
CREATE UNIQUE INDEX "SupplierOrderLine_orderId_productId_key" ON "SupplierOrderLine"("orderId", "productId");

-- CreateIndex
CREATE UNIQUE INDEX "StockMovement_orderLineId_key" ON "StockMovement"("orderLineId");

-- CreateIndex
CREATE INDEX "StockMovement_productId_createdAt_idx" ON "StockMovement"("productId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "PurchaseInvoice_orderId_key" ON "PurchaseInvoice"("orderId");

-- CreateIndex
CREATE UNIQUE INDEX "PurchaseInvoice_supplierId_reference_key" ON "PurchaseInvoice"("supplierId", "reference");

-- CreateIndex
CREATE UNIQUE INDEX "SupplierPayment_requestKey_key" ON "SupplierPayment"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "Expense_paymentId_key" ON "Expense"("paymentId");

-- CreateIndex
CREATE UNIQUE INDEX "Supplier_importKey_key" ON "Supplier"("importKey");

-- CreateIndex
CREATE UNIQUE INDEX "SupplierContact_importKey_key" ON "SupplierContact"("importKey");

-- CreateIndex
CREATE UNIQUE INDEX "SupplierOrder_occurrenceKey_key" ON "SupplierOrder"("occurrenceKey");

-- AddForeignKey
ALTER TABLE "SupplierOrder" ADD CONSTRAINT "SupplierOrder_cycleId_fkey" FOREIGN KEY ("cycleId") REFERENCES "SupplierCycle"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES "SupplierPayment"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierCycle" ADD CONSTRAINT "SupplierCycle_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierOrderLine" ADD CONSTRAINT "SupplierOrderLine_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "SupplierOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierOrderLine" ADD CONSTRAINT "SupplierOrderLine_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StockMovement" ADD CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StockMovement" ADD CONSTRAINT "StockMovement_orderLineId_fkey" FOREIGN KEY ("orderLineId") REFERENCES "SupplierOrderLine"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseInvoice" ADD CONSTRAINT "PurchaseInvoice_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseInvoice" ADD CONSTRAINT "PurchaseInvoice_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "SupplierOrder"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierPayment" ADD CONSTRAINT "SupplierPayment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "PurchaseInvoice"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "SupplierContact" DROP CONSTRAINT "contact_role";
ALTER TABLE "SupplierContact" ADD CONSTRAINT "contact_role" CHECK ("role" IN ('VENDEDOR','TRANSPORTISTA','COBRANZA','COMPROBANTES','SIN_DEFINIR'));
ALTER TABLE "SupplierOrder" DROP CONSTRAINT "order_status";
ALTER TABLE "SupplierOrder" ADD CONSTRAINT "order_status" CHECK ("status" IN ('BORRADOR','PENDIENTE','PREPARADO','ENVIADO','CONFIRMADO','RECIBIDO','CANCELADO'));
ALTER TABLE "SupplierCycle" ADD CONSTRAINT "cycle_kind" CHECK ("kind" IN ('WEEKLY','BUSINESS','INTERVAL','STOCK','FLEXIBLE'));
ALTER TABLE "SupplierOrderLine" ADD CONSTRAINT "order_line_positive" CHECK ("quantity">0 AND ("estimatedCost" IS NULL OR "estimatedCost">=0) AND ("receivedCost" IS NULL OR "receivedCost">=0));
ALTER TABLE "PurchaseInvoice" ADD CONSTRAINT "invoice_positive" CHECK ("amount">0);
ALTER TABLE "SupplierPayment" ADD CONSTRAINT "payment_positive" CHECK ("amount">0 AND "method" IN ('EFECTIVO','TRANSFERENCIA','DEBITO','CREDITO'));
ALTER TABLE "StockMovement" ADD CONSTRAINT "movement_nonzero" CHECK ("quantity"<>0 AND ("unitCost" IS NULL OR "unitCost">=0));
ALTER TABLE "Product" ADD COLUMN "demo" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Supplier" ADD COLUMN "demo" BOOLEAN NOT NULL DEFAULT false;
UPDATE "Product" SET "demo"=true WHERE "brand"='Marca demo' AND "barcode" IN ('DEMO001','DEMO002','DEMO003','DEMO004');
UPDATE "Supplier" SET "demo"=true WHERE "id"='supplier-demo' AND "name"='Distribuidora ficticia · DEMO';

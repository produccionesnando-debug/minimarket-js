ALTER TABLE "StockLoss" ADD COLUMN "estimatedWeightGrams" INTEGER;
ALTER TABLE "StockLoss" ADD CONSTRAINT "StockLoss_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES "InventoryLot"(id);
CREATE INDEX "InventoryReconciliation_status_idx" ON "InventoryReconciliation"(status);
CREATE INDEX "InventoryCount_actor_status_idx" ON "InventoryCount"("actorId",status);
CREATE INDEX "InventoryLot_product_expiry_idx" ON "InventoryLot"("productId","expiresAt");

CREATE TABLE "BrandIdentity" (
 "id" TEXT NOT NULL DEFAULT 'global',
 "original" BYTEA NOT NULL,
 "mime" TEXT NOT NULL,
 "sha256" TEXT NOT NULL,
 "width" INTEGER NOT NULL,
 "height" INTEGER NOT NULL,
 "updatedAt" TIMESTAMP(3) NOT NULL,
 CONSTRAINT "BrandIdentity_pkey" PRIMARY KEY ("id"),
 CONSTRAINT "brand_dimensions" CHECK (width>0 AND height>0)
);

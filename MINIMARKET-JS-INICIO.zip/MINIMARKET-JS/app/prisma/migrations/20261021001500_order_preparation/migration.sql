ALTER TABLE "SupplierOrder" ADD COLUMN "notes" TEXT NOT NULL DEFAULT '', ADD COLUMN "creationKey" TEXT;
CREATE UNIQUE INDEX "SupplierOrder_creationKey_key" ON "SupplierOrder"("creationKey");

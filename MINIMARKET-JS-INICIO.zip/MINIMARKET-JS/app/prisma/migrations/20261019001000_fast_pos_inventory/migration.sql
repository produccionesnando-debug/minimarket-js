ALTER TABLE "Product" ADD COLUMN active BOOLEAN NOT NULL DEFAULT true, ADD COLUMN "priceKnown" BOOLEAN NOT NULL DEFAULT true, ADD COLUMN "stockKnown" BOOLEAN NOT NULL DEFAULT true, ADD COLUMN "manualStockPolicy" TEXT NOT NULL DEFAULT 'PENDING', ADD COLUMN "needsLotReview" BOOLEAN NOT NULL DEFAULT false, ADD COLUMN "leadTimeDays" INTEGER;
ALTER TABLE "Product" DROP CONSTRAINT "stock_weight_unit";
ALTER TABLE "Product" ADD CONSTRAINT "stock_weight_unit" CHECK (("unitType" IN ('PESO','VARIABLE') AND stock=0) OR ("unitType" NOT IN ('PESO','VARIABLE') AND "stockGrams"=0));
ALTER TABLE "SaleItem" ADD COLUMN "manualAmount" INTEGER CHECK("manualAmount">0), ADD COLUMN "manualAmounts" INTEGER[] NOT NULL DEFAULT ARRAY[]::INTEGER[], ADD COLUMN "estimatedWeightGrams" INTEGER, ADD COLUMN "stockGramsDeducted" INTEGER NOT NULL DEFAULT 0;
UPDATE "SaleItem" SET "stockGramsDeducted"="weightGrams" WHERE "weightGrams" IS NOT NULL;
ALTER TABLE "StockMovement" ADD COLUMN "estimatedWeightGrams" INTEGER;
ALTER TABLE "ReturnLine" ADD COLUMN "estimatedWeightGrams" INTEGER, ADD COLUMN "stockGramsRestored" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "StockLoss" ADD COLUMN "lotId" TEXT;
ALTER TABLE "InternalProductCode" DROP CONSTRAINT "InternalProductCode_productId_key";
CREATE INDEX "InternalProductCode_productId_idx" ON "InternalProductCode"("productId");
CREATE TABLE "InventoryLot" (id TEXT PRIMARY KEY,"requestKey" TEXT NOT NULL UNIQUE,"productId" TEXT NOT NULL REFERENCES "Product"(id),code TEXT NOT NULL,"expiresAt" DATE NOT NULL,"receivedAt" DATE NOT NULL,units INTEGER NOT NULL DEFAULT 0 CHECK(units>=0),grams INTEGER NOT NULL DEFAULT 0 CHECK(grams>=0),"unitCost" INTEGER,"reconciled" BOOLEAN NOT NULL DEFAULT true,"createdBy" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE("productId",code));
CREATE INDEX "InventoryLot_expiresAt_idx" ON "InventoryLot"("expiresAt");
CREATE TABLE "InventoryReconciliation" (id TEXT PRIMARY KEY,"saleItemId" TEXT NOT NULL UNIQUE REFERENCES "SaleItem"(id),"productId" TEXT NOT NULL REFERENCES "Product"(id),amount INTEGER NOT NULL,"estimatedGrams" INTEGER,"deductedGrams" INTEGER NOT NULL DEFAULT 0,"actualGrams" INTEGER,status TEXT NOT NULL DEFAULT 'PENDING',note TEXT NOT NULL DEFAULT '',"resolvedBy" TEXT,"resolvedAt" TIMESTAMP(3),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "InventoryCount" (id TEXT PRIMARY KEY,"requestKey" TEXT NOT NULL UNIQUE,"actorId" TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'DRAFT',note TEXT NOT NULL DEFAULT '',"approvedBy" TEXT,"approvedAt" TIMESTAMP(3),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "InventoryCountLine" (id TEXT PRIMARY KEY,"countId" TEXT NOT NULL REFERENCES "InventoryCount"(id),"productId" TEXT NOT NULL REFERENCES "Product"(id),"productVersion" INTEGER NOT NULL,"systemUnits" INTEGER NOT NULL,"systemGrams" INTEGER NOT NULL,"wasKnown" BOOLEAN NOT NULL,"countedUnits" INTEGER NOT NULL DEFAULT 0 CHECK("countedUnits">=0),"countedGrams" INTEGER NOT NULL DEFAULT 0 CHECK("countedGrams">=0),UNIQUE("countId","productId"));
CREATE TABLE "InventoryCountEvent" ("requestKey" TEXT PRIMARY KEY,"countId" TEXT NOT NULL REFERENCES "InventoryCount"(id),"productId" TEXT NOT NULL REFERENCES "Product"(id),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "InventorySettings" (id TEXT PRIMARY KEY DEFAULT 'global',"expiryAlerts" INTEGER[] NOT NULL DEFAULT ARRAY[30,15,7,3],"historyDays" INTEGER NOT NULL DEFAULT 30,"noMovementDays" INTEGER NOT NULL DEFAULT 30,"defaultLeadDays" INTEGER NOT NULL DEFAULT 7,"marginThreshold" INTEGER NOT NULL DEFAULT 10,"highRotationDays" INTEGER NOT NULL DEFAULT 7);
INSERT INTO "InventorySettings"(id) VALUES('global');
CREATE TABLE "ReplenishmentReview" (id TEXT PRIMARY KEY,"requestKey" TEXT NOT NULL UNIQUE,"productId" TEXT NOT NULL REFERENCES "Product"(id),"supplierId" TEXT REFERENCES "Supplier"(id),units INTEGER NOT NULL DEFAULT 0,grams INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL,"actorId" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
-- Known configuration explicitly supplied by the owner. Zeroes are storage placeholders,
-- with priceKnown/stockKnown/costKnown=false; they are never presented as confirmed facts.
INSERT INTO "Product" (id,name,brand,barcode,"internalCode","barcodeKind",price,cost,stock,minimum,"unitType","costKnown","priceKnown","stockKnown","quickSale")
SELECT 'configured-pan-code20','Pan','','MMJS-PAN-20','20','INTERNAL',0,0,0,0,'VARIABLE',false,false,false,true
WHERE NOT EXISTS(SELECT 1 FROM "Product" WHERE "internalCode"='20' OR barcode='20');
INSERT INTO "InternalProductCode"(code,"productId") SELECT '20',id FROM "Product" WHERE id='configured-pan-code20' ON CONFLICT(code) DO NOTHING;

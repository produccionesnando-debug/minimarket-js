ALTER TABLE "SaleReturn" ADD COLUMN "shiftId" TEXT;
UPDATE "SaleReturn" r SET "shiftId" = c."shiftId" FROM "Collection" c WHERE c."returnId" = r.id;
CREATE INDEX "SaleReturn_shiftId_idx" ON "SaleReturn"("shiftId");
ALTER TABLE "SaleReturn" ADD CONSTRAINT "SaleReturn_shiftId_fkey" FOREIGN KEY ("shiftId") REFERENCES "Shift"("id") ON DELETE RESTRICT;

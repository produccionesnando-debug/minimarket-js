ALTER TABLE "StockMovement" DROP CONSTRAINT "movement_nonzero";
ALTER TABLE "StockMovement" ADD CONSTRAINT "movement_nonzero" CHECK (("quantity"<>0 AND "weightGrams" IS NULL) OR ("quantity"=0 AND "weightGrams" IS NOT NULL AND "weightGrams"<>0));
ALTER TABLE "Product" ADD CONSTRAINT "stock_weight_unit" CHECK (("unitType"='PESO' AND "stock"=0) OR ("unitType"<>'PESO' AND "stockGrams"=0));

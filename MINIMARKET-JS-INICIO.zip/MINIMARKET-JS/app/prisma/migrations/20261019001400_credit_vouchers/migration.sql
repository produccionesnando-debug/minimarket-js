CREATE TABLE "CreditVoucher" (
 "id" TEXT PRIMARY KEY, "number" SERIAL NOT NULL UNIQUE,
 "saleId" TEXT NOT NULL UNIQUE REFERENCES "Sale"("id"),
 "customerId" TEXT NOT NULL REFERENCES "Customer"("id"), "customerName" TEXT NOT NULL,
 "createdById" TEXT NOT NULL REFERENCES "User"("id"),"createdAt" TIMESTAMP(3) NOT NULL
);
CREATE TABLE "CreditReceipt" (
 "id" TEXT PRIMARY KEY,"number" SERIAL NOT NULL UNIQUE,"requestKey" TEXT NOT NULL UNIQUE,
 "fingerprint" TEXT NOT NULL,"customerId" TEXT NOT NULL REFERENCES "Customer"("id"),
 "actorId" TEXT NOT NULL REFERENCES "User"("id"),"shiftId" TEXT NOT NULL REFERENCES "Shift"("id"),
 "amount" INTEGER NOT NULL CHECK("amount">0),"reference" TEXT NOT NULL DEFAULT '',
 "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE "CreditAllocation" (
 "id" TEXT PRIMARY KEY,"receiptId" TEXT NOT NULL REFERENCES "CreditReceipt"("id"),
 "voucherId" TEXT NOT NULL REFERENCES "CreditVoucher"("id"),
 "customerPaymentId" TEXT NOT NULL UNIQUE REFERENCES "CustomerPayment"("id"),
 "balanceBefore" INTEGER NOT NULL,"balanceAfter" INTEGER NOT NULL,
 CHECK("balanceBefore">="balanceAfter" AND "balanceAfter">=0)
);
CREATE INDEX "CreditAllocation_receiptId_idx" ON "CreditAllocation"("receiptId");
CREATE INDEX "CreditAllocation_voucherId_idx" ON "CreditAllocation"("voucherId");
CREATE TABLE "NavigationSettings" ("id" TEXT PRIMARY KEY DEFAULT 'global',"mobileHome" TEXT NOT NULL DEFAULT '/pedidos',"roleShortcuts" JSONB NOT NULL DEFAULT '{}');
INSERT INTO "NavigationSettings" ("id") VALUES ('global');

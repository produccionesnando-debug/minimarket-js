-- Ampliación compatible de medios. No modifica ventas históricas.
ALTER TABLE "Sale" DROP CONSTRAINT "sale_method";
ALTER TABLE "Sale" ADD CONSTRAINT "sale_method" CHECK (method IN ('EFECTIVO','DEBITO','CREDITO','TRANSFERENCIA','MIXTO','FIADO'));
ALTER TABLE "Sale" ADD CONSTRAINT "sale_credit_bounds" CHECK ("creditAmount">=0 AND "creditAmount"<=total AND discount>=0 AND "paymentVersion" IN (0,1));
ALTER TABLE "Collection" ADD CONSTRAINT "collection_method" CHECK (method IN ('EFECTIVO','DEBITO','CREDITO','TRANSFERENCIA'));
ALTER TABLE "Collection" ADD CONSTRAINT "collection_direction" CHECK ((kind='REEMBOLSO' AND amount<0) OR (kind IN ('VENTA','ABONO','INGRESO') AND amount>0));
ALTER TABLE "ReturnLine" ADD CONSTRAINT "return_line_valid" CHECK (quantity>0 AND amount>=0);
ALTER TABLE "SaleReturn" ADD CONSTRAINT "return_credit_bounds" CHECK (amount>=0 AND "creditReduction">=0 AND "creditReduction"<=amount);

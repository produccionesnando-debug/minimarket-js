-- AlterTable
ALTER TABLE "Supplier" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "category" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "deliveryDays" INTEGER[] DEFAULT ARRAY[]::INTEGER[],
ADD COLUMN     "email" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "notes" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "orderDays" INTEGER[] DEFAULT ARRAY[]::INTEGER[],
ADD COLUMN     "paymentTerms" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "productsDescription" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "scheduleMode" TEXT NOT NULL DEFAULT 'FLEXIBLE',
ADD COLUMN     "version" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "whatsapp" TEXT NOT NULL DEFAULT '';

-- AlterTable
ALTER TABLE "SupplierOrder" ADD COLUMN     "orderDate" TIMESTAMP(3),
ADD COLUMN     "version" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true;

-- CreateTable
CREATE TABLE "SupplierContact" (
    "id" TEXT NOT NULL,
    "supplierId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "phone" TEXT NOT NULL DEFAULT '',
    "whatsapp" TEXT NOT NULL DEFAULT '',
    "email" TEXT NOT NULL DEFAULT '',
    "notes" TEXT NOT NULL DEFAULT '',

    CONSTRAINT "SupplierContact_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SupplierTask" (
    "id" TEXT NOT NULL,
    "supplierId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "amount" INTEGER NOT NULL DEFAULT 0,
    "description" TEXT NOT NULL,
    "doneAt" TIMESTAMP(3),

    CONSTRAINT "SupplierTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "actorId" TEXT NOT NULL,
    "actorName" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "entity" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "details" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_SupplierProducts" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,

    CONSTRAINT "_SupplierProducts_AB_pkey" PRIMARY KEY ("A","B")
);

-- CreateIndex
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_entity_entityId_idx" ON "AuditLog"("entity", "entityId");

-- CreateIndex
CREATE INDEX "_SupplierProducts_B_index" ON "_SupplierProducts"("B");

-- AddForeignKey
ALTER TABLE "SupplierContact" ADD CONSTRAINT "SupplierContact_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupplierTask" ADD CONSTRAINT "SupplierTask_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SupplierProducts" ADD CONSTRAINT "_SupplierProducts_A_fkey" FOREIGN KEY ("A") REFERENCES "Product"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SupplierProducts" ADD CONSTRAINT "_SupplierProducts_B_fkey" FOREIGN KEY ("B") REFERENCES "Supplier"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Preserve previous order history while adopting the six explicit states.
ALTER TABLE "User" DROP CONSTRAINT "user_role";
ALTER TABLE "User" ADD CONSTRAINT "user_role" CHECK ("role" IN ('ADMIN','SUPERVISOR','WORKER'));
ALTER TABLE "SupplierOrder" DROP CONSTRAINT "order_status";
UPDATE "SupplierOrder" SET "status" = 'ENVIADO' WHERE "status" = 'REALIZADO';
UPDATE "SupplierOrder" SET "status" = 'RECIBIDO' WHERE "status" = 'ENTREGADO';
ALTER TABLE "SupplierOrder" ADD CONSTRAINT "order_status" CHECK ("status" IN ('PENDIENTE','PREPARADO','ENVIADO','CONFIRMADO','RECIBIDO','CANCELADO'));
UPDATE "Supplier" SET "whatsapp" = "phone" WHERE "phone" <> '';
ALTER TABLE "Supplier" ADD CONSTRAINT "schedule_mode" CHECK ("scheduleMode" IN ('FIXED','FLEXIBLE','MIN_STOCK'));
ALTER TABLE "Supplier" ADD CONSTRAINT "schedule_days" CHECK ("orderDays" <@ ARRAY[1,2,3,4,5,6,7] AND "deliveryDays" <@ ARRAY[1,2,3,4,5,6,7]);
ALTER TABLE "SupplierContact" ADD CONSTRAINT "contact_role" CHECK ("role" IN ('VENDEDOR','TRANSPORTISTA','COBRANZA','COMPROBANTES'));
ALTER TABLE "SupplierTask" ADD CONSTRAINT "task_type" CHECK ("type" IN ('PEDIDO','ENTREGA','PAGO'));
ALTER TABLE "SupplierTask" ADD CONSTRAINT "task_amount" CHECK ("amount" >= 0);

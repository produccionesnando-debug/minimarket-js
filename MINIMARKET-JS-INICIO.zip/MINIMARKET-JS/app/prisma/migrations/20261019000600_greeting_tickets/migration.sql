-- CreateTable
CREATE TABLE "Scripture" (
    "id" TEXT NOT NULL,
    "text" TEXT NOT NULL,
    "reference" TEXT NOT NULL,
    "translation" TEXT NOT NULL,
    "topic" TEXT NOT NULL,
    "rights" TEXT NOT NULL DEFAULT 'PUBLIC_DOMAIN',
    "rightsNote" TEXT NOT NULL DEFAULT '',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Scripture_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DailyScripture" (
    "day" TEXT NOT NULL,
    "verseId" TEXT,
    "text" TEXT NOT NULL,
    "reference" TEXT NOT NULL,
    "translation" TEXT NOT NULL,

    CONSTRAINT "DailyScripture_pkey" PRIMARY KEY ("day")
);

-- CreateTable
CREATE TABLE "WelcomeSeen" (
    "userId" TEXT NOT NULL,
    "day" TEXT NOT NULL,
    "dismissedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "WelcomeSeen_pkey" PRIMARY KEY ("userId","day")
);

-- CreateTable
CREATE TABLE "PrintSettings" (
    "id" TEXT NOT NULL DEFAULT 'global',
    "paper" INTEGER NOT NULL DEFAULT 80,
    "showLogo" BOOLEAN NOT NULL DEFAULT true,
    "showVerse" BOOLEAN NOT NULL DEFAULT true,
    "autoPrint" BOOLEAN NOT NULL DEFAULT false,
    "cashierMode" TEXT NOT NULL DEFAULT 'NAME',
    "thanks" TEXT NOT NULL DEFAULT '¡Gracias por su compra!',
    "verseMode" TEXT NOT NULL DEFAULT 'DAY',
    "customerVerseId" TEXT,
    "fixedMessage" TEXT NOT NULL DEFAULT '',
    "greetingEnabled" BOOLEAN NOT NULL DEFAULT true,
    "encouragement" TEXT NOT NULL DEFAULT 'Que hoy sea un día de buenas ventas, atención amable y nuevas oportunidades.',

    CONSTRAINT "PrintSettings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PrintAttempt" (
    "id" TEXT NOT NULL,
    "requestKey" TEXT NOT NULL,
    "saleId" TEXT,
    "actorId" TEXT NOT NULL,
    "paper" INTEGER NOT NULL,
    "kind" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'REQUESTED',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PrintAttempt_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FiscalDocument" (
    "id" TEXT NOT NULL,
    "saleId" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "externalId" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FiscalDocument_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "PrintAttempt_requestKey_key" ON "PrintAttempt"("requestKey");

-- CreateIndex
CREATE UNIQUE INDEX "FiscalDocument_saleId_key" ON "FiscalDocument"("saleId");

-- CreateIndex
CREATE UNIQUE INDEX "FiscalDocument_provider_externalId_key" ON "FiscalDocument"("provider", "externalId");

ALTER TABLE "PrintSettings" ADD CONSTRAINT "ticket_paper" CHECK (paper IN (58,80));
INSERT INTO "PrintSettings" (id) VALUES ('global');
-- Selección breve de Reina-Valera 1909 (dominio público). Se conserva su ortografía.
INSERT INTO "Scripture" (id,text,reference,translation,topic,"updatedAt") VALUES
('rv1909-01','Jehová te bendiga, y te guarde:','Números 6:24','Reina-Valera 1909','Bendición',now()),
('rv1909-02','Encomienda á Jehová tus obras, Y tus pensamientos serán afirmados.','Proverbios 16:3','Reina-Valera 1909','Trabajo',now()),
('rv1909-03','EL peso falso abominación es á Jehová: Mas la pesa cabal le agrada.','Proverbios 11:1','Reina-Valera 1909','Honestidad',now()),
('rv1909-04','El temor de Jehová es el principio de la sabiduría; Y la ciencia de los santos es inteligencia.','Proverbios 9:10','Reina-Valera 1909','Sabiduría',now()),
('rv1909-05','Dad gracias en todo; porque esta es la voluntad de Dios para con vosotros en Cristo Jesús.','1 Tesalonicenses 5:18','Reina-Valera 1909','Gratitud',now()),
('rv1909-06','En paz me acostaré, y asimismo dormiré; Porque solo tú, Jehová, me haces estar confiado.','Salmos 4:8','Reina-Valera 1909','Paz',now()),
('rv1909-07','DIOS es nuestro amparo y fortaleza, Nuestro pronto auxilio en las tribulaciones.','Salmos 46:1','Reina-Valera 1909','Fortaleza',now()),
('rv1909-08','Porque tú, oh Señor Jehová, eres mi esperanza: Seguridad mía desde mi juventud.','Salmos 71:5','Reina-Valera 1909','Esperanza',now()),
('rv1909-09','No te vengarás, ni guardarás rencor á los hijos de tu pueblo: mas amarás á tu prójimo como á ti mismo: Yo Jehová.','Levítico 19:18','Reina-Valera 1909','Amor al prójimo',now()),
('rv1909-10','El alma liberal será engordada: Y el que saciare, él también será saciado.','Proverbios 11:25','Reina-Valera 1909','Prosperidad responsable',now());

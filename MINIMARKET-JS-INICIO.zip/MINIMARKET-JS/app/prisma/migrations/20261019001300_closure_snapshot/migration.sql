ALTER TABLE "Shift" ADD COLUMN "closureSnapshot" JSONB;

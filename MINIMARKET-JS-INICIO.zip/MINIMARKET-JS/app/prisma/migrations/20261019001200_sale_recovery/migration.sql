CREATE TABLE "ParkedSale" (
 "id" TEXT PRIMARY KEY, "requestKey" TEXT NOT NULL UNIQUE,
 "checkoutKey" TEXT NOT NULL UNIQUE, "actorId" TEXT NOT NULL REFERENCES "User"("id"),
 "actorName" TEXT NOT NULL, "shiftId" TEXT NOT NULL REFERENCES "Shift"("id"),
 "activeShiftId" TEXT REFERENCES "Shift"("id"), "claimedById" TEXT REFERENCES "User"("id"),
 "status" TEXT NOT NULL DEFAULT 'HELD' CHECK ("status" IN ('HELD','RESUMED','CANCELLED','COMPLETED')),
 "payload" JSONB NOT NULL, "saleId" TEXT UNIQUE REFERENCES "Sale"("id"),
 "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL
);
CREATE INDEX "ParkedSale_actorId_status_idx" ON "ParkedSale"("actorId","status");
CREATE TABLE "CartDraft" (
 "id" TEXT PRIMARY KEY, "actorId" TEXT NOT NULL REFERENCES "User"("id"),
 "shiftId" TEXT NOT NULL REFERENCES "Shift"("id"), "revision" INTEGER NOT NULL DEFAULT 1,
 "payload" JSONB NOT NULL, "updatedAt" TIMESTAMP(3) NOT NULL,
 UNIQUE("actorId","shiftId")
);
ALTER TABLE "Collection" ADD COLUMN "confirmationStatus" TEXT NOT NULL DEFAULT 'REGISTRO_MANUAL';
ALTER TABLE "Collection" ADD COLUMN "confirmationReference" TEXT NOT NULL DEFAULT '';
ALTER TABLE "Collection" ADD COLUMN "confirmedById" TEXT;
ALTER TABLE "Shift" ADD COLUMN "differenceAuthorizationRequired" BOOLEAN NOT NULL DEFAULT false;

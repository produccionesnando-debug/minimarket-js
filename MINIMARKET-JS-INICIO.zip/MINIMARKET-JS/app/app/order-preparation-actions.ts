"use server";
import { requirePermission } from "@/lib/auth";
import { mutation } from "@/lib/mutations";
import { createOrderProduct, prepareOrderShare } from "@/lib/order-preparation";
export async function addOrderProduct(input: unknown) {
  const actor = await requirePermission("purchases:write");
  let product:
    | {
        id: string;
        name: string;
        brand: string;
        presentation: string;
        flavor: string;
        cost: null;
        barcode: string;
        stockKnown: boolean;
        stock: number;
        minimum: number;
      }
    | undefined;
  const result = await mutation(async () => {
    const p = await createOrderProduct(actor, input);
    product = {
      id: p.id,
      name: p.name,
      brand: p.brand,
      presentation: p.presentation,
      flavor: p.flavor,
      cost: null,
      barcode: p.barcode,
      stockKnown: false,
      stock: 0,
      minimum: 0,
    };
  });
  return {
    ...result,
    product: product as
      | {
          id: string;
          name: string;
          brand: string;
          presentation: string;
          flavor: string;
          cost: null;
          barcode: string;
          stockKnown: boolean;
          stock: number;
          minimum: number;
        }
      | undefined,
  };
}
export async function prepareShare(input: unknown) {
  const actor = await requirePermission("purchases:write");
  let url = "";
  const result = await mutation(async () => {
    url = await prepareOrderShare(actor, input);
  });
  return { ...result, url };
}

"use server";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { mutation, type ActionResult, audit } from "@/lib/mutations";
import { saveCategory, priceSettings, editPrices } from "@/lib/catalog";
import { recordLoss } from "@/lib/losses";
import { db } from "@/lib/db";
import { serial } from "@/lib/cash";
import { allow } from "@/lib/pos";
export async function categoryAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await saveCategory(actor, {
      id: String(f.get("id") || "") || undefined,
      name: f.get("name"),
      parentId: String(f.get("parentId") || "") || null,
      active: f.get("active") !== "false",
    });
    revalidatePath("/", "layout");
  });
}
export async function priceSettingsAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await priceSettings(actor, {
      markup: Number(f.get("markup")),
      rounding: Number(f.get("rounding")),
      roundingMode: f.get("roundingMode"),
    });
    revalidatePath("/", "layout");
  }, "Regla comercial guardada. No se publicaron precios externos.");
}
export async function priceAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await editPrices(actor, {
      id: f.get("id"),
      version: Number(f.get("version")),
      price: Number(f.get("price")),
      cost: Number(f.get("cost")),
      channelFixed: f.get("channelFixed") === "on",
      channelPrice:
        f.get("channelPrice") === "" ? null : Number(f.get("channelPrice")),
      reason: f.get("reason"),
    });
    revalidatePath("/", "layout");
  }, "Precios guardados con historial. Sin publicación en PedidosYa.");
}
export async function lossAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await recordLoss(
      actor,
      {
        requestKey: f.get("requestKey"),
        productId: f.get("productId"),
        quantity: Number(f.get("quantity")),
        date: f.get("date"),
        reasonId: f.get("reasonId"),
        responsibleId: f.get("responsibleId") || actor.id,
        notes: f.get("notes") || "",
      },
      [...f.getAll("files"), ...f.getAll("camera")].filter(
        (v): v is File => v instanceof File && v.size > 0,
      ),
    );
    revalidatePath("/", "layout");
  }, "Merma registrada. Se descontó stock sin crear una venta ni una salida de dinero.");
}
export async function lossReasonAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const name = z.string().trim().min(2).max(100).parse(f.get("name"));
    await serial(async (tx) => {
      const id = String(f.get("id") || "");
      const reason = id
        ? await tx.lossReason.update({
            where: { id },
            data: { name, active: f.get("active") !== "false" },
          })
        : await tx.lossReason.create({ data: { name } });
      await audit(tx, actor, "MOTIVO_MERMA", "Motivo", reason.id, {
        name,
        active: reason.active,
      });
    });
    revalidatePath("/", "layout");
  });
}
export async function customerAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    allow(actor, "credits:authorize");
    const value = z
      .object({
        name: z.string().trim().min(2).max(150),
        phone: z.string().max(40),
        address: z.string().max(300),
        creditLimit: z.number().int().min(0).max(1000000000).nullable(),
        notes: z.string().max(1000),
        demo: z.boolean(),
        active: z.boolean(),
      })
      .parse({
        name: f.get("name"),
        phone: f.get("phone") || "",
        address: f.get("address") || "",
        creditLimit:
          f.get("creditLimit") === "" ? null : Number(f.get("creditLimit")),
        notes: f.get("notes") || "",
        demo: f.get("demo") === "on",
        active: f.get("active") !== "false",
      });
    await serial(async (tx) => {
      const id = String(f.get("id") || "");
      const c = id
        ? await tx.customer.update({
            where: { id },
            data: {
              name: value.name,
              phone: value.phone,
              address: value.address,
              creditLimit: value.creditLimit,
              notes: value.notes,
              active: value.active,
            },
          })
        : await tx.customer.create({ data: value });
      await audit(tx, actor, "CLIENTE_GUARDADO", "Cliente", c.id, {
        name: c.name,
        creditLimit: c.creditLimit,
        active: c.active,
      });
    });
    revalidatePath("/", "layout");
  }, "Ficha del cliente guardada.");
}

"use server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { serial } from "@/lib/cash";
import { todayChile } from "@/lib/dates";
import { TOPICS } from "@/lib/daily-scripture";
import { requestTicketPrint } from "@/lib/tickets";
import {
  audit,
  mutation,
  type ActionResult,
  ValidationError,
} from "@/lib/mutations";
import { revalidatePath } from "next/cache";
export async function dismissWelcome(day: string) {
  const actor = await requireUser();
  return mutation(async () => {
    if (day !== todayChile())
      throw new ValidationError("La fecha cambió; actualiza el saludo.");
    await db.welcomeSeen.upsert({
      where: { userId_day: { userId: actor.id, day } },
      create: { userId: actor.id, day },
      update: {},
    });
  });
}
export async function scriptureAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const data = z
      .object({
        text: z.string().trim().min(3).max(1000),
        reference: z.string().trim().min(2).max(100),
        translation: z.string().trim().min(2).max(100),
        topic: z.enum(TOPICS),
        rights: z.enum(["PUBLIC_DOMAIN", "AUTHORIZED"]),
        rightsNote: z.string().trim().max(500),
        active: z.boolean(),
      })
      .parse({
        text: f.get("text"),
        reference: f.get("reference"),
        translation: f.get("translation"),
        topic: f.get("topic"),
        rights: f.get("rights"),
        rightsNote: f.get("rightsNote") || "",
        active: f.get("active") === "on",
      });
    if (data.rights === "AUTHORIZED" && data.rightsNote.length < 8)
      throw new ValidationError("Indica la autorización de reproducción.");
    await serial(async (tx) => {
      const id = String(f.get("id") || "");
      const row = id
        ? await tx.scripture.update({ where: { id }, data })
        : await tx.scripture.create({ data });
      await audit(tx, actor, "VERSICULO_GUARDADO", "Versículo", row.id, {
        active: data.active,
        rights: data.rights,
      });
    });
    revalidatePath("/", "layout");
  }, "Biblioteca actualizada. El versículo ya elegido para hoy se conserva.");
}
export async function ticketSettingsAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const data = z
      .object({
        paper: z.coerce.number().refine((n) => n === 58 || n === 80),
        showLogo: z.boolean(),
        showVerse: z.boolean(),
        autoPrint: z.boolean(),
        cashierMode: z.enum(["NAME", "ID", "NONE"]),
        thanks: z.string().trim().min(1).max(180),
        verseMode: z.enum(["DAY", "CUSTOMER", "FIXED"]),
        customerVerseId: z.string().nullable(),
        fixedMessage: z.string().trim().max(180),
        greetingEnabled: z.boolean(),
        encouragement: z.string().trim().min(1).max(240),
      })
      .parse({
        paper: f.get("paper"),
        showLogo: f.get("showLogo") === "on",
        showVerse: f.get("showVerse") === "on",
        autoPrint: f.get("autoPrint") === "on",
        cashierMode: f.get("cashierMode"),
        thanks: f.get("thanks"),
        verseMode: f.get("verseMode"),
        customerVerseId: String(f.get("customerVerseId") || "") || null,
        fixedMessage: f.get("fixedMessage") || "",
        greetingEnabled: f.get("greetingEnabled") === "on",
        encouragement: f.get("encouragement"),
      });
    if (
      data.showVerse &&
      data.verseMode === "CUSTOMER" &&
      !(await db.scripture.findFirst({
        where: { id: data.customerVerseId || "", active: true },
      }))
    )
      throw new ValidationError(
        "Selecciona un versículo publicado para clientes.",
      );
    if (data.showVerse && data.verseMode === "FIXED" && !data.fixedMessage)
      throw new ValidationError("Escribe el mensaje fijo.");
    await serial(async (tx) => {
      await tx.printSettings.upsert({
        where: { id: "global" },
        create: { id: "global", ...data },
        update: data,
      });
      await audit(
        tx,
        actor,
        "CONFIGURACION_TICKETS",
        "Configuración",
        "global",
        {
          paper: data.paper,
          autoPrint: data.autoPrint,
          verseMode: data.verseMode,
        },
      );
    });
    revalidatePath("/", "layout");
  }, "Configuración guardada. La impresora se elige en el diálogo de Windows/navegador.");
}
export async function printTicketAction(input: unknown) {
  const actor = await requireUser();
  return mutation(async () => {
    await requestTicketPrint(actor, input);
  }, "Solicitud de impresión registrada; no confirma salida física de papel.");
}

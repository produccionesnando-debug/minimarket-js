import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getBrand } from "@/lib/brand";
import { ticketSale } from "@/lib/tickets";
import { printSettings, ticketVerse } from "@/lib/daily-scripture";
import { outstanding } from "@/lib/pos";
import { ThermalTicket, type ThermalData } from "@/components/thermal-ticket";
import { TicketPrint } from "@/components/ticket-print";
export default async function Ticket({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ papel?: string }>;
}) {
  const actor = await requireUser(),
    { id } = await params,
    p = await searchParams,
    [settings, brand, verse] = await Promise.all([
      printSettings(),
      getBrand(),
      ticketVerse(),
    ]);
  const paper: 58 | 80 =
    p.papel === "58"
      ? 58
      : p.papel === "80"
        ? 80
        : settings.paper === 58
          ? 58
          : 80;
  let data: ThermalData;
  if (id === "prueba") {
    if (actor.role !== "ADMIN") notFound();
    data = {
      id: "PRUEBA · NO ES VENTA",
      date: new Date().toLocaleString("es-CL", {
        timeZone: "America/Santiago",
      }),
      cashier: "Cajero de prueba",
      items: [
        {
          name: "Producto ficticio A",
          quantity: 2,
          unitPrice: 1300,
          total: 2600,
        },
        {
          name: "Producto ficticio B",
          quantity: 1,
          unitPrice: 2200,
          total: 2200,
        },
      ],
      discount: 0,
      total: 4800,
      payments: [
        { method: "EFECTIVO", amount: 4800, tendered: 5000, kind: "VENTA" },
      ],
      credit: 0,
      balance: 0,
      returned: 0,
      demo: true,
      test: true,
    };
  } else {
    const sale = await ticketSale(actor, id);
    if (!sale) notFound();
    data = {
      id: sale.id,
      date: sale.createdAt.toLocaleString("es-CL", {
        timeZone: "America/Santiago",
      }),
      cashier:
        settings.cashierMode === "NONE"
          ? ""
          : settings.cashierMode === "ID"
            ? sale.shift.user.id.slice(-8)
            : sale.shift.user.name,
      items: sale.items.map((i) => ({
        name: i.productName || i.product.name,
        quantity: i.quantity,
        weightGrams: i.weightGrams,
        manualAmount: i.manualAmount,
        estimatedWeightGrams: i.estimatedWeightGrams,
        unitPrice: i.unitPrice,
        total: i.lineTotal ?? i.unitPrice * i.quantity,
      })),
      discount: sale.discount,
      total: sale.total,
      payments:
        sale.paymentVersion === 0
          ? [
              {
                method: sale.method,
                amount: sale.total,
                tendered: null,
                kind: "VENTA",
              },
            ]
          : sale.collections
              .filter((c) => c.kind !== "INGRESO")
              .map((c) => ({
                method: c.method,
                amount: c.amount,
                tendered: c.tendered,
                kind: c.kind,
              })),
      credit: sale.creditAmount,
      balance: outstanding(sale),
      returned: sale.returns.reduce((a, r) => a + r.amount, 0),
      demo: sale.demo || process.env.DEMO_INSTANCE === "1",
      test: false,
    };
  }
  return (
    <div className="ticket-page">
      <nav className="toolbar no-print">
        <Link href={id === "prueba" ? "/impresoras" : "/ventas/" + id}>
          Volver
        </Link>
        <Link href={"/ticket/" + id + "?papel=58"}>58 mm</Link>
        <Link href={"/ticket/" + id + "?papel=80"}>80 mm</Link>
      </nav>
      <TicketPrint saleId={id === "prueba" ? undefined : id} paper={paper} />
      <ThermalTicket
        data={data}
        brand={brand}
        paper={paper}
        showLogo={settings.showLogo}
        thanks={settings.thanks}
        verse={verse}
      />
    </div>
  );
}

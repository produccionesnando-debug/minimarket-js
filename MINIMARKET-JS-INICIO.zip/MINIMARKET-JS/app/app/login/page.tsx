import { login } from "@/app/actions";
export default async function Login({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const p = await searchParams;
  return (
    <main className="login">
      <section className="card">
        <div className="logo">JS</div>
        <p className="eyebrow">TU NEGOCIO, EN ORDEN</p>
        <h1>MINIMARKET JS</h1>
        <p>Ingresa para comenzar tu jornada.</p>
        {p.error && (
          <p role="alert" className="alert">
            Correo o contraseña incorrectos.
          </p>
        )}
        <form action={login}>
          <label>
            Correo electrónico
            <input name="email" type="email" autoComplete="username" required />
          </label>
          <label>
            Contraseña
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
              minLength={8}
            />
          </label>
          <button>Iniciar sesión →</button>
        </form>
        <small>Acceso exclusivo para personal autorizado.</small>
      </section>
    </main>
  );
}

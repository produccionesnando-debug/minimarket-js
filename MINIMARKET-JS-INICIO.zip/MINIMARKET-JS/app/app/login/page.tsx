import { login } from "@/app/actions";
import { googleReady } from "@/lib/google";
export default async function Login({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; google?: string }>;
}) {
  const p = await searchParams;
  return (
    <main className="login">
      <section className="card">
        <div className="logo">JS</div>
        <p className="eyebrow">TU NEGOCIO, EN ORDEN</p>
        <h1>MINIMARKET JS</h1>
        <p>Ingresa para comenzar tu jornada.</p>
        {p.error && (
          <p role="alert" className="alert">
            Correo o contraseña incorrectos.
          </p>
        )}
        {p.google && (
          <p className="alert" role="alert">
            No se pudo iniciar sesión con Google. Revisa la configuración o
            solicita autorización al administrador.
          </p>
        )}
        {googleReady() ? (
          <a className="button secondary" href="/api/auth/google">
            Continuar con Google
          </a>
        ) : (
          <>
            <button disabled className="secondary">
              Continuar con Google
            </button>
            <p className="help">
              Google pendiente de configuración. Usa tu correo y contraseña.
            </p>
          </>
        )}
        <form action={login}>
          <label>
            Correo electrónico
            <input name="email" type="email" autoComplete="username" required />
          </label>
          <label>
            Contraseña
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
              minLength={8}
            />
          </label>
          <button>Iniciar sesión →</button>
        </form>
        <small>Acceso exclusivo para personal autorizado.</small>
      </section>
    </main>
  );
}

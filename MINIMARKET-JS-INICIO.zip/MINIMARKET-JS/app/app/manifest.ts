import type { MetadataRoute } from "next";
import { getBrand } from "@/lib/brand";
export const dynamic = "force-dynamic";
export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const brand = await getBrand();
  return {
    name: "MINIMARKET JS",
    short_name: "Minimarket JS",
    description: "Tu negocio en orden",
    lang: "es-CL",
    start_url: "/inicio",
    display: "standalone",
    background_color: "#f5f8fc",
    theme_color: "#075578",
    icons: brand.available
      ? [
          {
            src: "/api/identidad/logo?size=192&v=" + brand.version,
            sizes: "192x192",
            type: "image/png",
          },
          {
            src: "/api/identidad/logo?size=512&v=" + brand.version,
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable",
          },
        ]
      : [],
  };
}

"use server";
import { cookies } from "next/headers";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import {
  mutation,
  audit,
  ValidationError,
  type ActionResult,
} from "@/lib/mutations";
import { db } from "@/lib/db";
import { validDate } from "@/lib/dates";
import { cycleOptions } from "@/lib/schedules";
import {
  storeDraft,
  receiveOrder,
  createInvoice,
  recordPayment,
} from "@/lib/purchases";
const day = z.string().refine(validDate);
const key = (f: FormData, k = "id") =>
  z.string().min(1).max(100).parse(f.get(k));
const integer = (v: unknown, min = 0) =>
  z.coerce.number().int().min(min).max(1000000000).parse(v);
const refresh = () => {
  for (const p of [
    "/inicio",
    "/calendario",
    "/pedidos",
    "/proveedores",
    "/inventario",
    "/finanzas",
    "/caja",
    "/auditoria",
  ])
    revalidatePath(p, "layout");
  revalidatePath("/pedidos/[id]", "page");
  revalidatePath("/proveedores/[id]", "page");
};
export async function saveDraft(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("purchases:write");
  let id = "";
  const result = await mutation(async () => {
    const lines = z
      .array(
        z.object({
          productId: z.string().min(1),
          quantity: z.number().int().min(1).max(1000000),
          cost: z.number().int().min(0).max(1000000000).nullable(),
        }),
      )
      .min(1)
      .max(100)
      .parse(JSON.parse(String(f.get("lines"))));
    try {
      id = await storeDraft(actor, {
        id: String(f.get("id") || "") || undefined,
        version: integer(f.get("version")),
        supplierId: key(f, "supplierId"),
        cycleId: String(f.get("cycleId") || "") || undefined,
        orderDate: day.parse(f.get("orderDate")),
        deliveryDate: day.parse(f.get("date")),
        overrideDelivery: f.get("overrideDelivery") === "on",
        extraordinary: f.get("extraordinary") === "on",
        status: z.enum(["BORRADOR", "PENDIENTE"]).parse(f.get("status")),
        lines,
      });
    } catch (e) {
      if (e instanceof Error && /día|fecha|Elige/.test(e.message))
        throw new ValidationError(e.message);
      throw e;
    }
    refresh();
  }, "Pedido guardado.");
  if (result.success) {
    const draftKey = String(f.get("draftKey") || "");
    if (draftKey.startsWith("mmjs-order:") && draftKey.length < 400)
      (await cookies()).set("mm_order_clear", draftKey, {
        path: "/",
        sameSite: "lax",
        maxAge: 300,
      });
    redirect(`/pedidos/${id}`);
  }
  return result;
}
export async function receive(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("purchases:write");
  return mutation(async () => {
    const costs: Record<string, number | null> = {};
    for (const [k, v] of f.entries())
      if (k.startsWith("cost-"))
        costs[k.slice(5)] = v === "" ? null : integer(v);
    await receiveOrder(actor, key(f), integer(f.get("version")), costs);
    refresh();
  }, "Mercadería recibida. Inventario actualizado una sola vez; no se creó una factura ni un pago.");
}
export async function invoice(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("finance:write");
  return mutation(async () => {
    await createInvoice(actor, {
      supplierId: key(f, "supplierId"),
      orderId: String(f.get("orderId") || "") || undefined,
      reference: z.string().trim().min(1).max(100).parse(f.get("reference")),
      issuedAt: day.parse(f.get("issuedAt")),
      receivedAt: day.parse(f.get("receivedAt")),
      dueDate: f.get("dueDate") ? day.parse(f.get("dueDate")) : undefined,
      amount: integer(f.get("amount"), 1),
      notes: z
        .string()
        .max(2000)
        .parse(f.get("notes") || ""),
    });
    refresh();
  }, "Factura registrada sin alterar stock ni registrar pagos.");
}
export async function payment(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("finance:write");
  return mutation(async () => {
    await recordPayment(actor, {
      invoiceId: key(f, "invoiceId"),
      shiftId: String(f.get("shiftId") || "") || undefined,
      bankAccountId: String(f.get("bankAccountId") || "") || undefined,
      amount: integer(f.get("amount"), 1),
      method: z
        .enum(["EFECTIVO", "TRANSFERENCIA", "DEBITO", "CREDITO"])
        .parse(f.get("method")),
      date: day.parse(f.get("date")),
      reference: z
        .string()
        .max(200)
        .parse(f.get("reference") || ""),
      requestKey: z.uuid().parse(f.get("requestKey")),
    });
    refresh();
  }, "Pago registrado internamente. No se ejecutó ninguna transferencia ni pago externo.");
}
export async function saveCycle(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  return mutation(async () => {
    const kind = z
      .enum(["WEEKLY", "BUSINESS", "INTERVAL", "STOCK", "FLEXIBLE"])
      .parse(f.get("kind"));
    const options = cycleOptions.parse(
      JSON.parse(String(f.get("options") || "[]")),
    );
    const excludedDates = String(f.get("excludedDates") || "")
      .split(/\s+/)
      .filter(Boolean);
    z.array(day).parse(excludedDates);
    const data = {
      label: z.string().trim().min(2).max(150).parse(f.get("label")),
      kind,
      anchorDay: f.get("anchorDay") ? integer(f.get("anchorDay"), 1) : null,
      options: options as Prisma.InputJsonValue,
      allowedDays: f
        .getAll("allowedDays")
        .map((v) => z.coerce.number().int().min(1).max(7).parse(v)),
      recommendedDay: f.get("recommendedDay")
        ? integer(f.get("recommendedDay"), 1)
        : null,
      businessLeadDays: f.get("businessLeadDays")
        ? integer(f.get("businessLeadDays"))
        : null,
      intervalDays: f.get("intervalDays")
        ? integer(f.get("intervalDays"), 1)
        : null,
      nextOrderDate: f.get("nextOrderDate")
        ? new Date(day.parse(f.get("nextOrderDate")) + "T00:00:00Z")
        : null,
      excludedDates,
      active: f.get("active") === "on",
    };
    if ((data.anchorDay ?? 1) > 7 || (data.recommendedDay ?? 1) > 7)
      throw new ValidationError("Día de la semana inválido.");
    if (kind === "WEEKLY" && (!data.anchorDay || !options.length))
      throw new ValidationError(
        "Configura un día de anclaje y al menos una alternativa.",
      );
    if (
      kind === "BUSINESS" &&
      (data.businessLeadDays === null || !data.recommendedDay)
    )
      throw new ValidationError("Indica días hábiles y día recomendado.");
    if (kind === "INTERVAL" && !data.intervalDays)
      throw new ValidationError("Indica la frecuencia en días.");
    await db.$transaction(async (tx) => {
      const supplierId = key(f, "supplierId");
      if (
        !(await tx.supplier.findFirst({
          where: { id: supplierId, active: true },
        }))
      )
        throw new ValidationError("Proveedor inactivo.");
      const id = String(f.get("id") || "");
      let cycle;
      if (id) {
        const changed = await tx.supplierCycle.updateMany({
          where: { id, supplierId, version: integer(f.get("version")) },
          data: { ...data, version: { increment: 1 } },
        });
        if (!changed.count)
          throw new ValidationError("El ciclo cambió. Recarga la página.");
        cycle = { id };
      } else
        cycle = await tx.supplierCycle.create({
          data: { ...data, supplierId },
        });
      await audit(tx, actor, "CICLO_CONFIGURADO", "Ciclo", cycle.id, {
        ...data,
        nextOrderDate: data.nextOrderDate?.toISOString() ?? null,
      });
    });
    refresh();
  }, "Ciclo guardado. Las alternativas comparten un único pedido por período.");
}
export async function savePaymentRule(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  return mutation(async () => {
    const data = {
      paymentRule: z
        .enum(["PENDIENTE", "CONTADO", "DAYS", "NEXT_WEEKDAY"])
        .parse(f.get("paymentRule")),
      paymentDays: f.get("paymentDays") ? integer(f.get("paymentDays")) : null,
      paymentDayCount: z
        .enum(["PENDIENTE", "CORRIDOS", "HABILES"])
        .parse(f.get("paymentDayCount")),
      paymentWeekday: f.get("paymentWeekday")
        ? z.coerce.number().int().min(1).max(7).parse(f.get("paymentWeekday"))
        : null,
      preferCash: f.get("preferCash") === "on",
    };
    await db.$transaction(async (tx) => {
      const supplierId = key(f, "supplierId");
      await tx.supplier.update({ where: { id: supplierId }, data });
      await audit(
        tx,
        actor,
        "REGLA_PAGO_CONFIGURADA",
        "Proveedor",
        supplierId,
        data,
      );
    });
    refresh();
  }, "Condiciones actualizadas para facturas nuevas. Las facturas existentes no se modifican.");
}

"use server";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { serial } from "@/lib/cash";
import {
  audit,
  mutation,
  ValidationError,
  type ActionResult,
} from "@/lib/mutations";
import {
  createConversation,
  createClientOrder,
  reserveOrder,
  orderAdvance,
  cancelOrder,
  authorizedConversation,
  ATTENTION,
} from "@/lib/client-orders";
import { checkout } from "@/lib/pos";
import { can } from "@/lib/permissions";
import { dateOnly, validDate } from "@/lib/dates";
export async function conversationAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await createConversation(actor, {
      requestKey: f.get("requestKey"),
      name: f.get("name"),
      phone: f.get("phone"),
      body: f.get("body"),
      demo: f.get("demo") === "true",
      customerId: String(f.get("customerId") || "") || undefined,
    });
    revalidatePath("/", "layout");
  }, "Conversación registrada manualmente. No se envió ningún mensaje.");
}
export async function clientOrderAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const lines = JSON.parse(z.string().max(60000).parse(f.get("lines")));
    await createClientOrder(actor, {
      requestKey: f.get("requestKey"),
      conversationId: f.get("conversationId"),
      mode: f.get("mode"),
      requestedDate: String(f.get("requestedDate") || "") || undefined,
      notes: f.get("notes") || "",
      lines,
    });
    revalidatePath("/", "layout");
  }, "Pedido solicitado. Aún no es una venta ni una reserva.");
}
export async function orderOperation(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const id = z.string().min(1).parse(f.get("orderId")),
      op = String(f.get("op"));
    if (op === "confirm") await reserveOrder(actor, id);
    else if (op === "cancel") await cancelOrder(actor, id);
    else if (op === "advance" || op === "refund")
      await orderAdvance(actor, {
        requestKey: f.get("requestKey"),
        orderId: id,
        shiftId: f.get("shiftId"),
        amount: Number(f.get("amount")),
        method: f.get("method"),
        refund: op === "refund",
      });
    else if (op === "sell") {
      const o = await db.clientOrder.findUniqueOrThrow({
        where: { id },
        include: { items: true },
      });
      // checkout repeats authorization, reservation, price and advance validation atomically.
      const total = o.items.reduce(
          (a, i) => a + (i.price || 0) * i.quantity,
          0,
        ),
        sum = await db.collection.aggregate({
          where: { orderId: id },
          _sum: { amount: true },
        }),
        remaining = total - (sum._sum.amount || 0);
      await checkout(actor, {
        requestKey: f.get("requestKey"),
        orderId: id,
        shiftId: f.get("shiftId"),
        customerId: o.customerId || undefined,
        lines: o.items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          expectedPrice: i.price,
        })),
        payments:
          remaining > 0
            ? [
                {
                  method: f.get("method"),
                  amount: remaining,
                  tendered:
                    f.get("method") === "EFECTIVO"
                      ? Number(f.get("tendered"))
                      : undefined,
                },
              ]
            : [],
      });
    } else if (op === "deliver")
      await serial(async (tx) => {
        const o = await tx.clientOrder.findUniqueOrThrow({ where: { id } });
        await authorizedConversation(tx, actor, o.conversationId);
        if (!o.saleId)
          throw new ValidationError("Registra la venta antes de entregar.");
        await tx.clientOrder.update({
          where: { id },
          data: { status: "ENTREGADO" },
        });
        await tx.clientConversation.update({
          where: { id: o.conversationId },
          data: { status: "ENTREGADO" },
        });
        await audit(tx, actor, "ENCARGO_ENTREGADO", "Encargo", id, {});
      });
    else throw new ValidationError("Operación desconocida.");
    revalidatePath("/", "layout");
  }, "Operación registrada una sola vez.");
}
export async function attentionAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await serial(async (tx) => {
      const c = await authorizedConversation(
        tx,
        actor,
        String(f.get("conversationId")),
      );
      const assignedId = String(f.get("assignedId") || c.assignedId);
      if (assignedId !== c.assignedId && !can(actor.role, "shifts:manage"))
        throw new ValidationError("Solo un supervisor puede reasignar.");
      if (
        !(await tx.user.findFirst({ where: { id: assignedId, active: true } }))
      )
        throw new ValidationError("Responsable no activo.");
      const status = z.enum(ATTENTION).parse(f.get("status"));
      if (status === "ENTREGADO")
        throw new ValidationError("Marca entregado desde el pedido asociado.");
      await tx.clientConversation.update({
        where: { id: c.id },
        data: { status, assignedId },
      });
      await audit(tx, actor, "ATENCION_ACTUALIZADA", "Conversación", c.id, {
        status,
        assignedId,
      });
    });
    revalidatePath("/", "layout");
  });
}
export async function messageAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await serial(async (tx) => {
      const c = await authorizedConversation(
          tx,
          actor,
          String(f.get("conversationId")),
        ),
        body = z.string().trim().min(1).max(4000).parse(f.get("body")),
        key = z.uuid().parse(f.get("requestKey"));
      await tx.clientMessage.upsert({
        where: { externalId: "manual:" + key },
        create: {
          externalId: "manual:" + key,
          conversationId: c.id,
          body,
          actorId: actor.id,
        },
        update: {},
      });
      await tx.clientConversation.update({
        where: { id: c.id },
        data: { updatedAt: new Date() },
      });
    });
    revalidatePath("/", "layout");
  }, "Nota/mensaje manual guardado. No enviado por WhatsApp.");
}
export async function specialAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await serial(async (tx) => {
      const i = await tx.clientOrderItem.findUniqueOrThrow({
        where: { id: String(f.get("itemId")) },
        include: { order: true },
      });
      await authorizedConversation(tx, actor, i.order.conversationId);
      if (i.order.saleId || i.order.status !== "SOLICITADO")
        throw new ValidationError(
          "Solo se modifica un pedido solicitado sin reserva.",
        );
      const productId = String(f.get("productId") || "") || null,
        supplierId = String(f.get("supplierId") || "") || null,
        procurement = z
          .enum(["PENDIENTE", "PROPUESTA_COMPRA", "RECIBIDO"])
          .parse(f.get("procurement"));
      const product = productId
        ? await tx.product.findFirst({
            where: { id: productId, demo: i.order.demo },
          })
        : null;
      if (productId && !product)
        throw new ValidationError("Producto no disponible.");
      if (
        supplierId &&
        !(await tx.supplier.findFirst({
          where: { id: supplierId, demo: i.order.demo, active: true },
        }))
      )
        throw new ValidationError("Proveedor no disponible.");
      if (
        procurement === "RECIBIDO" &&
        (!product || product.stock < i.quantity)
      )
        throw new ValidationError(
          "Registra primero la recepción real en inventario.",
        );
      const date = String(f.get("committedDate") || "");
      if (date && !validDate(date))
        throw new ValidationError("Fecha inválida.");
      await tx.clientOrderItem.update({
        where: { id: i.id },
        data: {
          productId,
          price: product?.price ?? null,
          supplierId,
          committedAt: date ? dateOnly(date) : null,
          procurement,
        },
      });
      if (procurement === "RECIBIDO")
        await tx.clientMessage.create({
          data: {
            conversationId: i.order.conversationId,
            direction: "INTERNA",
            actorId: actor.id,
            body:
              "Encargo recibido y disponible para revisar: " + i.description,
          },
        });
      await audit(
        tx,
        actor,
        "ENCARGO_ESPECIAL_ACTUALIZADO",
        "Encargo",
        i.orderId,
        { itemId: i.id, procurement },
      );
    });
    revalidatePath("/", "layout");
  }, "Encargo actualizado. Propuesta interna; no realiza compras ni descuenta stock.");
}
export async function templateAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await serial(async (tx) => {
      const id = String(f.get("id"));
      await tx.quickReply.update({
        where: { id },
        data: {
          title: z.string().trim().min(1).max(100).parse(f.get("title")),
          body: z.string().trim().min(1).max(2000).parse(f.get("body")),
        },
      });
      await audit(tx, actor, "PLANTILLA_EDITADA", "Plantilla", id, {});
    });
    revalidatePath("/whatsapp");
  });
}
export async function accessAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await serial(async (tx) => {
      const userId = z.string().min(1).parse(f.get("userId")),
        op = f.get("op");
      const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      if (op === "revoke") {
        await tx.googleAccount.deleteMany({ where: { userId } });
        await tx.googleGrant.deleteMany({ where: { userId } });
        await tx.session.deleteMany({ where: { userId } });
      } else {
        const email = z.email().max(254).parse(f.get("email")).toLowerCase();
        if (
          !user.active ||
          (await tx.googleAccount.findUnique({ where: { userId } }))
        )
          throw new ValidationError("Usuario inactivo o ya vinculado.");
        await tx.googleGrant.deleteMany({ where: { userId } });
        await tx.googleGrant.upsert({
          where: { email },
          create: {
            email,
            userId,
            approvedBy: actor.id,
            expires: new Date(Date.now() + 7 * 86400000),
          },
          update: {
            userId,
            approvedBy: actor.id,
            expires: new Date(Date.now() + 7 * 86400000),
          },
        });
      }
      await audit(tx, actor, "AUTORIZACION_GOOGLE", "Usuario", userId, {
        operation: String(op),
      });
    });
    revalidatePath("/accesos");
  }, "Autorización actualizada. No se enviaron invitaciones por correo.");
}
export async function retentionAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await serial(async (tx) => {
      const retentionDays = z.coerce
        .number()
        .int()
        .min(1)
        .max(3650)
        .parse(f.get("retentionDays"));
      const assignedId = String(f.get("assignedId") || "") || null;
      if (
        assignedId &&
        !(await tx.user.findFirst({ where: { id: assignedId, active: true } }))
      )
        throw new ValidationError("Responsable no disponible.");
      await tx.messagingSettings.update({
        where: { id: "global" },
        data: {
          retentionDays,
          assignedId,
          inboundEnabled: f.get("inboundEnabled") === "on",
        },
      });
      if (f.get("purge") === "ELIMINAR") {
        const result = await tx.clientMessage.deleteMany({
          where: {
            createdAt: { lt: new Date(Date.now() - retentionDays * 86400000) },
          },
        });
        await audit(tx, actor, "MENSAJES_ELIMINADOS", "Privacidad", "global", {
          count: result.count,
          retentionDays,
        });
      }
    });
    revalidatePath("/whatsapp");
  }, "Política guardada. La eliminación requiere confirmación explícita.");
}

"use server";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { mutation, type ActionResult } from "@/lib/mutations";
import { checkout, payCredit, returnSale, extraIncome } from "@/lib/pos";
export async function checkoutAction(input: unknown) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await checkout(actor, input);
    revalidatePath("/", "layout");
  }, "Venta registrada.");
  return { ...result, id };
}
export async function customerPaymentAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await payCredit(actor, {
      requestKey: f.get("requestKey"),
      saleId: f.get("saleId"),
      shiftId: f.get("shiftId"),
      amount: Number(f.get("amount")),
      method: f.get("method"),
      reference: f.get("reference") || "",
    });
    revalidatePath("/", "layout");
  }, "Abono registrado una sola vez. No se creó otra venta.");
}
export async function returnAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await returnSale(actor, {
      requestKey: f.get("requestKey"),
      saleId: f.get("saleId"),
      shiftId: f.get("shiftId"),
      reason: f.get("reason"),
      method: f.get("method"),
      lines: JSON.parse(String(f.get("lines"))),
    });
    revalidatePath("/", "layout");
  }, "Devolución registrada.");
  return { ...result, id };
}
export async function incomeAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await extraIncome(actor, {
      requestKey: f.get("requestKey"),
      shiftId: f.get("shiftId"),
      amount: Number(f.get("amount")),
      method: f.get("method"),
      reason: f.get("reason"),
    });
    revalidatePath("/", "layout");
  }, "Ingreso adicional registrado. No es una venta.");
}

export async function quickProductAction(input: unknown) {
  const actor = await requireUser();
  let product:
    | Awaited<
        ReturnType<typeof import("@/lib/quick-product").createQuickProduct>
      >
    | undefined;
  const result = await mutation(async () => {
    const { createQuickProduct } = await import("@/lib/quick-product");
    product = await createQuickProduct(actor, input);
    revalidatePath("/", "layout");
  }, "Producto creado.");
  return { ...result, product };
}

export async function editQuickProductAction(input: unknown) {
  const actor = await requireUser();
  let product:
    | Awaited<ReturnType<typeof import("@/lib/quick-product").editQuickProduct>>
    | undefined;
  const result = await mutation(async () => {
    const { editQuickProduct } = await import("@/lib/quick-product");
    product = await editQuickProduct(actor, input);
    revalidatePath("/", "layout");
  }, "Producto actualizado; las ventas finalizadas conservan sus precios.");
  return { ...result, product };
}

export async function recoveryAction(
  operation: string,
  input: {
    shiftId: string;
    id?: string;
    requestKey?: string;
    payload?: unknown;
    revision?: number;
  },
) {
  const actor = await requireUser();
  const recovery = await import("@/lib/sale-recovery");
  let data: unknown;
  const result = await mutation(async () => {
    switch (operation) {
      case "list":
        data = await recovery.listHeld(actor);
        break;
      case "hold":
        data = await recovery.holdSale(
          actor,
          input.shiftId,
          input.payload,
          input.requestKey || "",
        );
        break;
      case "recover":
        data = await recovery.recoverHeld(actor, input.shiftId, input.id || "");
        break;
      case "cancel":
        await recovery.cancelHeld(actor, input.id || "");
        break;
      case "draft":
        data = await recovery.readDraft(actor, input.shiftId);
        break;
      case "save":
        data = await recovery.saveDraft(
          actor,
          input.shiftId,
          input.payload,
          input.revision ?? 0,
        );
        break;
      case "validate":
        data = await recovery.validateDraft(
          actor,
          input.shiftId,
          input.payload,
        );
        break;
      case "status":
        data = await recovery.saleStatus(actor, input.requestKey || "");
        break;
      default:
        throw new Error("Operación desconocida");
    }
  });
  return { ...result, data };
}

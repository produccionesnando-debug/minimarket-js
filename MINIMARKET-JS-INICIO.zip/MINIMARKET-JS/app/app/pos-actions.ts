"use server";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { mutation, type ActionResult } from "@/lib/mutations";
import { checkout, payCredit, returnSale, extraIncome } from "@/lib/pos";
export async function checkoutAction(input: unknown) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await checkout(actor, input);
    revalidatePath("/", "layout");
  }, "Venta registrada.");
  return { ...result, id };
}
export async function customerPaymentAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await payCredit(actor, {
      requestKey: f.get("requestKey"),
      saleId: f.get("saleId"),
      shiftId: f.get("shiftId"),
      amount: Number(f.get("amount")),
      method: f.get("method"),
      reference: f.get("reference") || "",
    });
    revalidatePath("/", "layout");
  }, "Abono registrado una sola vez. No se creó otra venta.");
}
export async function returnAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await returnSale(actor, {
      requestKey: f.get("requestKey"),
      saleId: f.get("saleId"),
      shiftId: f.get("shiftId"),
      reason: f.get("reason"),
      method: f.get("method"),
      lines: JSON.parse(String(f.get("lines"))),
    });
    revalidatePath("/", "layout");
  }, "Devolución registrada.");
  return { ...result, id };
}
export async function incomeAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await extraIncome(actor, {
      requestKey: f.get("requestKey"),
      shiftId: f.get("shiftId"),
      amount: Number(f.get("amount")),
      method: f.get("method"),
      reason: f.get("reason"),
    });
    revalidatePath("/", "layout");
  }, "Ingreso adicional registrado. No es una venta.");
}

export async function quickProductAction(input: unknown) {
  const actor = await requireUser();
  let product:
    | Awaited<
        ReturnType<typeof import("@/lib/quick-product").createQuickProduct>
      >
    | undefined;
  const result = await mutation(async () => {
    const { createQuickProduct } = await import("@/lib/quick-product");
    product = await createQuickProduct(actor, input);
    revalidatePath("/", "layout");
  }, "Producto creado.");
  return { ...result, product };
}

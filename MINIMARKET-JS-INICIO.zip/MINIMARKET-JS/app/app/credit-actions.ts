"use server";
import { requireUser } from "@/lib/auth";
import { mutation } from "@/lib/mutations";
import { collectVouchers } from "@/lib/credit-vouchers";
import { revalidatePath } from "next/cache";
export async function collectVoucherAction(input: unknown) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await collectVouchers(actor, input);
    revalidatePath("/", "layout");
  }, "Pago de fiados registrado. No se creó otra venta.");
  return { ...result, id };
}

export async function saveNavigation(
  _: import("@/lib/mutations").ActionResult,
  f: FormData,
) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const { MOBILE_HOMES, MOBILE_SHORTCUTS } =
        await import("@/lib/navigation-settings"),
      { db } = await import("@/lib/db"),
      { audit } = await import("@/lib/mutations"),
      { serial } = await import("@/lib/cash");
    const mobileHome = String(f.get("mobileHome"));
    if (!MOBILE_HOMES.includes(mobileHome as never))
      throw Error("Pantalla no válida");
    const roleShortcuts = Object.fromEntries(
      ["ADMIN", "SUPERVISOR", "WORKER"].map((role) => {
        const value = String(f.get(role));
        if (!MOBILE_SHORTCUTS.includes(value as never))
          throw Error("Acceso no válido");
        return [role, value];
      }),
    );
    await serial(async (tx) => {
      await tx.navigationSettings.upsert({
        where: { id: "global" },
        create: { id: "global", mobileHome, roleShortcuts },
        update: { mobileHome, roleShortcuts },
      });
      await audit(
        tx,
        actor,
        "NAVEGACION_CONFIGURADA",
        "Configuración",
        "global",
        { mobileHome, roleShortcuts },
      );
    });
    revalidatePath("/", "layout");
  }, "Navegación guardada. Se aplicará en el próximo inicio de sesión móvil.");
}

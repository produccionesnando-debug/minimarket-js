"use server";
import { requireUser } from "@/lib/auth";
import { saveBrand } from "@/lib/brand";
import { mutation, type ActionResult } from "@/lib/mutations";
import { revalidatePath } from "next/cache";
export async function brandAction(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const file = f.get("logo");
    if (!(file instanceof File)) throw Error("Falta archivo");
    await saveBrand(actor, file);
    revalidatePath("/", "layout");
  }, "Logo original guardado. Se actualizaron el acceso, navegación, comprobantes e iconos.");
}

"use server";
import { requirePermission } from "@/lib/auth";
import { mutation } from "@/lib/mutations";
import { saveHabitualList, type HabitualItem } from "@/lib/habitual-lists";
import { revalidatePath } from "next/cache";
export async function saveHabitual(input: unknown) {
  const actor = await requirePermission("purchases:write");
  let saved: { version: number; items: HabitualItem[] } | null = null;
  const result = await mutation(async () => {
    saved = await saveHabitualList(actor, input);
    revalidatePath("/pedidos", "layout");
    revalidatePath("/proveedores", "layout");
  }, "Lista habitual guardada. Los pedidos históricos no se modificaron.");
  return {
    ...result,
    saved: saved as { version: number; items: HabitualItem[] } | null,
  };
}

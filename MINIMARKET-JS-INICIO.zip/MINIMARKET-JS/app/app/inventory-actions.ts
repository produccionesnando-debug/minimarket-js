"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { mutation, type ActionResult, ValidationError } from "@/lib/mutations";
import { db } from "@/lib/db";
import { weightBased, gramsFromInput } from "@/lib/weight";
import { can } from "@/lib/permissions";
import {
  createInventoryLot,
  writeOffLot,
  reconcileManualStock,
  startPhysicalCount,
  recordPhysicalCount,
  approvePhysicalCount,
  confirmLotBalances,
  inventorySettings,
  resolveInventoryCode,
} from "@/lib/inventory-operations";
import { reviewReplenishment } from "@/lib/inventory-insights";
const str = (f: FormData, k: string) => String(f.get(k) || "");
function quantities(value: string, weighted: boolean) {
  if (!value.trim())
    throw new ValidationError("Ingresa una cantidad explícita.");
  if (weighted)
    return {
      units: 0,
      grams:
        Number(value.replace(",", ".")) === 0 ? 0 : gramsFromInput(value, "kg"),
    };
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0 || n > 1000000000)
    throw new ValidationError("Ingresa unidades enteras.");
  return { units: n, grams: 0 };
}
export async function lotAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const p = await db.product.findUniqueOrThrow({
      where: { id: str(f, "productId") },
    });
    await createInventoryLot(actor, {
      requestKey: str(f, "requestKey"),
      productId: p.id,
      code: str(f, "code"),
      expiresAt: str(f, "expiresAt"),
      receivedAt: str(f, "receivedAt"),
      ...quantities(str(f, "quantity"), weightBased(p)),
      unitCost: str(f, "unitCost") === "" ? null : Number(f.get("unitCost")),
      mode: str(f, "mode"),
    });
    revalidatePath("/", "layout");
  }, "Lote registrado una sola vez.");
}
export async function lotLossAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const l = await db.inventoryLot.findUniqueOrThrow({
        where: { id: str(f, "lotId") },
      }),
      p = await db.product.findUniqueOrThrow({ where: { id: l.productId } });
    await writeOffLot(actor, {
      requestKey: str(f, "requestKey"),
      lotId: l.id,
      reason: str(f, "reason"),
      ...quantities(str(f, "quantity"), weightBased(p)),
    });
    revalidatePath("/", "layout");
  }, "Merma del lote registrada y stock descontado una sola vez.");
}
export async function reconcileStockAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await reconcileManualStock(actor, {
      id: str(f, "id"),
      actualGrams:
        str(f, "actualKg") === ""
          ? null
          : quantities(str(f, "actualKg"), true).grams,
      noTracking: f.get("noTracking") === "on",
      note: str(f, "note"),
    });
    revalidatePath("/", "layout");
  }, "Conciliación registrada. No se modificó el dinero de la venta.");
}
export async function startCountAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await startPhysicalCount(actor, {
      requestKey: str(f, "requestKey"),
      note: str(f, "note"),
    });
  }, "Conteo creado.");
  if (id) redirect("/inventario/conteos/" + id);
  return result;
}
export async function countLookupAction(countId: string, code: string) {
  const actor = await requireUser();
  let product:
    { id: string; name: string; unitType: string; barcode: string } | undefined;
  const result = await mutation(async () => {
    const count = await db.inventoryCount.findUniqueOrThrow({
      where: { id: countId },
    });
    if (count.actorId !== actor.id && !can(actor.role, "inventory:adjust"))
      throw new ValidationError("Conteo de otro usuario.");
    if (count.status !== "DRAFT") throw new ValidationError("Conteo cerrado.");
    const p = await resolveInventoryCode(code.trim().slice(0, 100));
    if (!p) throw new ValidationError("Código no registrado.");
    product = {
      id: p.id,
      name: p.name,
      unitType: p.unitType,
      barcode: p.barcode,
    };
  });
  return { ...result, product };
}
export async function recordCountAction(input: {
  requestKey: string;
  countId: string;
  productId: string;
  units: number;
  grams: number;
  mode: "ADD" | "SET";
  recount?: boolean;
}) {
  const actor = await requireUser();
  return mutation(async () => {
    await recordPhysicalCount(actor, input);
    revalidatePath("/inventario/conteos/" + input.countId);
  }, "Cantidad contada guardada una sola vez.");
}
export async function setCountLineAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const p = await db.product.findUniqueOrThrow({
      where: { id: str(f, "productId") },
    });
    await recordPhysicalCount(actor, {
      requestKey: str(f, "requestKey"),
      countId: str(f, "countId"),
      productId: p.id,
      ...quantities(str(f, "quantity"), weightBased(p)),
      mode: "SET",
      recount: f.get("recount") === "on",
    });
    revalidatePath("/", "layout");
  }, "Conteo actualizado; aún no se ajustó el inventario.");
}
export async function approveCountAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    if (f.get("confirm") !== "on")
      throw new ValidationError("Confirma el ajuste autorizado.");
    await approvePhysicalCount(actor, str(f, "countId"));
    revalidatePath("/", "layout");
  }, "Conteo aprobado; diferencias ajustadas y auditadas una sola vez.");
}
export async function confirmLotsAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const p = await db.product.findUniqueOrThrow({
        where: { id: str(f, "productId") },
      }),
      lots = await db.inventoryLot.findMany({ where: { productId: p.id } });
    await confirmLotBalances(actor, {
      productId: p.id,
      version: Number(f.get("version")),
      lots: lots.map((l) => ({
        id: l.id,
        ...quantities(str(f, "lot-" + l.id), weightBased(p)),
      })),
    });
    revalidatePath("/", "layout");
  }, "Distribución física por lotes conciliada.");
}
export async function inventorySettingsAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await inventorySettings(actor, {
      expiryAlerts: [30, 15, 7, 3].filter((n) => f.get("alert-" + n) === "on"),
      historyDays: Number(f.get("historyDays")),
      noMovementDays: Number(f.get("noMovementDays")),
      defaultLeadDays: Number(f.get("defaultLeadDays")),
      marginThreshold: Number(f.get("marginThreshold")),
      highRotationDays: Number(f.get("highRotationDays")),
    });
    revalidatePath("/", "layout");
  }, "Reglas de inventario guardadas.");
}
export async function reviewRestockAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const p = await db.product.findUniqueOrThrow({
      where: { id: str(f, "productId") },
    });
    await reviewReplenishment(actor, {
      requestKey: str(f, "requestKey") || randomUUID(),
      productId: p.id,
      supplierId: str(f, "supplierId") || null,
      ...quantities(str(f, "quantity"), weightBased(p)),
      reason: str(f, "reason"),
    });
    revalidatePath("/inventario/inteligente");
  }, "Revisión guardada. No se envió ni creó automáticamente un pedido.");
}

import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { printSettings } from "@/lib/daily-scripture";
import { ticketSettingsAction } from "@/app/scripture-actions";
import { ActionForm } from "@/components/action-form";
export default async function Printers() {
  await requireUser(true);
  const [s, verses] = await Promise.all([
    printSettings(),
    db.scripture.findMany({
      where: { active: true, text: { not: "" } },
      orderBy: { reference: "asc" },
    }),
  ]);
  return (
    <>
      <h1>Impresoras y tickets</h1>
      <p>
        Impresión desde navegador para papel de 58 u 80 mm. El equipo se elige
        en el diálogo de impresión. No hay impresión silenciosa ni
        compatibilidad física certificada desde esta nube.
      </p>
      <section className="card">
        <ActionForm action={ticketSettingsAction}>
          <label>
            Ancho del papel
            <select name="paper" defaultValue={s.paper}>
              <option value="58">58 mm</option>
              <option value="80">80 mm</option>
            </select>
          </label>
          <label>
            <input
              name="showLogo"
              type="checkbox"
              defaultChecked={s.showLogo}
            />
            Mostrar logo oficial si está cargado
          </label>
          <label>
            <input
              name="showVerse"
              type="checkbox"
              defaultChecked={s.showVerse}
            />
            Mostrar versículo / mensaje al final
          </label>
          <label>
            <input
              name="autoPrint"
              type="checkbox"
              defaultChecked={s.autoPrint}
            />
            Solicitar impresión al finalizar la venta (puede ser bloqueada por
            el navegador)
          </label>
          <label>
            Identificación del cajero
            <select name="cashierMode" defaultValue={s.cashierMode}>
              <option value="NAME">Nombre</option>
              <option value="ID">Identificador interno</option>
              <option value="NONE">No imprimir</option>
            </select>
          </label>
          <label>
            Mensaje de agradecimiento
            <input
              name="thanks"
              maxLength={180}
              required
              defaultValue={s.thanks}
            />
          </label>
          <label>
            Mensaje bíblico para clientes
            <select name="verseMode" defaultValue={s.verseMode}>
              <option value="DAY">Versículo del día</option>
              <option value="CUSTOMER">Versículo especial para clientes</option>
              <option value="FIXED">Mensaje fijo</option>
            </select>
          </label>
          <label>
            Versículo especial
            <select
              name="customerVerseId"
              defaultValue={s.customerVerseId || ""}
            >
              <option value="">Elegir</option>
              {verses.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.reference} · {v.text.length} caracteres
                </option>
              ))}
            </select>
          </label>
          <label>
            Mensaje fijo autorizado
            <textarea
              name="fixedMessage"
              maxLength={180}
              defaultValue={s.fixedMessage}
            />
          </label>
          <p className="help">
            Los versículos de más de 180 caracteres se omiten del ticket en
            lugar de truncarlos; siguen disponibles en el saludo.
          </p>
          <label>
            <input
              name="greetingEnabled"
              type="checkbox"
              defaultChecked={s.greetingEnabled}
            />
            Mostrar bienvenida diaria y tarjeta del versículo
          </label>
          <label>
            Frase de ánimo
            <textarea
              name="encouragement"
              required
              maxLength={240}
              defaultValue={s.encouragement}
            />
          </label>
          <button>Guardar impresoras y mensajes</button>
        </ActionForm>
      </section>
      <div className="toolbar">
        <Link
          className="button secondary"
          href={"/ticket/prueba?papel=" + s.paper}
        >
          Página de prueba
        </Link>
        <Link className="button secondary" href="/versiculos">
          Administrar versículos
        </Link>
        <Link className="button secondary" href="/identidad">
          Cargar logo original
        </Link>
      </div>
    </>
  );
}

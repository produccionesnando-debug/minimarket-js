import { homeSummary } from "@/lib/reports";
import { occurrences, weekday } from "@/lib/schedules";
import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import {
  todayChile,
  validDate,
  dateOnly,
  isoDay,
  calendarRange,
  adjacentDate,
  formatDay,
  type CalendarView,
} from "@/lib/dates";
import {
  ORDER_STATUSES,
  STATUS_LABELS,
  OPEN_STATUSES,
} from "@/lib/order-status";
import { clp } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import {
  saveCalendarOrder,
  changeOrderStatus,
  saveTask,
  finishTask,
} from "@/app/phase1-actions";
type Event = {
  id: string;
  date: string;
  label: string;
  kind: "pedido" | "entrega" | "pago" | "fijo" | "stock";
  href: string;
  amount?: number;
};
export default async function Calendar({
  searchParams,
}: {
  searchParams: Promise<{
    vista?: string;
    fecha?: string;
    month?: string;
    proveedor?: string;
    estado?: string;
  }>;
}) {
  const user = await requireUser();
  const p = await searchParams;
  const summary = await homeSummary(user);
  const today = todayChile();
  const view: CalendarView = ["dia", "semana", "mes"].includes(p.vista || "")
    ? (p.vista as CalendarView)
    : p.month
      ? "mes"
      : "semana";
  const anchor = validDate(p.fecha || "")
    ? p.fecha!
    : p.month && validDate(p.month + "-01")
      ? p.month + "-01"
      : today;
  const { from, until, days } = calendarRange(anchor, view);
  const range = { gte: from, lt: until };
  const editable = can(user.role, "calendar:write");
  const supplierFilter = p.proveedor ? { supplierId: p.proveedor } : {};
  const stateFilter = ORDER_STATUSES.includes(
    p.estado as (typeof ORDER_STATUSES)[number],
  )
    ? { status: p.estado }
    : {};
  const [orders, suppliers, tasks, lowStock, invoices] = await Promise.all([
    db.supplierOrder.findMany({
      where: {
        ...supplierFilter,
        ...stateFilter,
        supplier: { demo: false },
        OR: [{ date: range }, { orderDate: range }],
      },
      include: { supplier: true },
      orderBy: [{ date: "asc" }, { id: "asc" }],
    }),
    db.supplier.findMany({
      where: { active: true, demo: false },
      include: { products: true, cycles: { where: { active: true } } },
      orderBy: { name: "asc" },
    }),
    db.supplierTask.findMany({
      where: { ...supplierFilter, date: range },
      include: { supplier: true },
      orderBy: { date: "asc" },
    }),
    db.product.findMany({
      where: { demo: false, stock: { lte: db.product.fields.minimum } },
      select: { id: true, name: true, stock: true, minimum: true },
      orderBy: { name: "asc" },
    }),
    db.purchaseInvoice.findMany({
      where: { ...supplierFilter, supplier: { demo: false }, dueDate: range },
      include: { supplier: true, payments: true },
    }),
  ]);
  const planned = suppliers
    .filter((s) => !p.proveedor || s.id === p.proveedor)
    .flatMap((s) =>
      s.cycles.flatMap((c) =>
        occurrences(c, from, until).map((o) => ({
          supplier: s,
          cycle: c,
          occurrence: o,
        })),
      ),
    );
  const existingKeys = await db.supplierOrder.findMany({
    where: { occurrenceKey: { in: planned.map((v) => v.occurrence.key) } },
    select: { occurrenceKey: true },
  });
  const used = new Set(existingKeys.map((o) => o.occurrenceKey));
  const freeformSuppliers = suppliers.filter((s) => !s.cycles.length);
  const events: Event[] = [];
  for (const order of orders) {
    if (order.status === "CANCELADO") continue;
    if (
      order.orderDate &&
      (OPEN_STATUSES.includes(order.status) || order.status === "BORRADOR") &&
      order.orderDate >= from &&
      order.orderDate < until
    )
      events.push({
        id: "pedido-" + order.id,
        date: isoDay(order.orderDate),
        label: `${STATUS_LABELS[order.status]} · ${order.supplier.name}`,
        kind: "pedido",
        href: `/pedidos/${order.id}`,
        amount: order.budget,
      });
    if (order.status !== "BORRADOR" && order.date >= from && order.date < until)
      events.push({
        id: "entrega-" + order.id,
        date: isoDay(order.date),
        label: `${order.status === "RECIBIDO" ? "Recibido" : "Entrega"} · ${order.supplier.name}`,
        kind: "entrega",
        href: `/pedidos/${order.id}`,
        amount: order.budget,
      });
  }
  for (const invoice of invoices) {
    const balance =
      invoice.amount - invoice.payments.reduce((a, p) => a + p.amount, 0);
    if (balance > 0)
      events.push({
        id: "invoice-" + invoice.id,
        date: isoDay(invoice.dueDate!),
        label: `Pago factura ${invoice.reference} · ${invoice.supplier.name}`,
        kind: "pago",
        href: "/finanzas",
        amount: balance,
      });
  }
  if (!p.estado || p.estado === "PENDIENTE" || p.estado === "BORRADOR")
    for (const { supplier, cycle, occurrence } of planned) {
      if (used.has(occurrence.key)) continue;
      const choice =
        occurrence.options.find(
          (o) => dateOnly(o.orderDate) >= from && dateOnly(o.orderDate) < until,
        ) || occurrence.options[0];
      if (!choice) continue;
      const href = `/pedidos/nuevo?proveedor=${supplier.id}&ciclo=${cycle.id}&fecha=${choice.orderDate}`;
      if (
        dateOnly(choice.orderDate) >= from &&
        dateOnly(choice.orderDate) < until
      )
        events.push({
          id: "planned-order-" + occurrence.key,
          date: choice.orderDate,
          label: `Preparar · ${supplier.name} · ${cycle.label}`,
          kind: "fijo",
          href,
        });
      if (
        ["WEEKLY", "BUSINESS"].includes(cycle.kind) &&
        dateOnly(choice.deliveryDate) >= from &&
        dateOnly(choice.deliveryDate) < until
      )
        events.push({
          id: "planned-delivery-" + occurrence.key,
          date: choice.deliveryDate,
          label: `Entrega prevista · ${supplier.name}${occurrence.options.length > 1 ? " (según alternativa)" : ""}`,
          kind: "fijo",
          href,
        });
    }
  for (const task of tasks)
    if (!task.doneAt)
      events.push({
        id: task.id,
        date: isoDay(task.date),
        label: `${task.type === "PAGO" ? "Pago pendiente" : task.type === "ENTREGA" ? "Entrega" : "Pedido"} · ${task.supplier.name}`,
        kind:
          task.type === "PAGO"
            ? "pago"
            : task.type === "ENTREGA"
              ? "entrega"
              : "pedido",
        href: "#task-" + task.id,
        amount: task.amount,
      });
  for (const day of days) {
    const date = isoDay(day);
    const dayOfWeek = weekday(day);
    for (const supplier of suppliers.filter(
      (s) => !p.proveedor || s.id === p.proveedor,
    )) {
      if (p.estado && p.estado !== "PENDIENTE") continue;
      for (const cycle of supplier.cycles.filter(
        (c) =>
          c.kind === "STOCK" &&
          (!c.allowedDays.length || c.allowedDays.includes(dayOfWeek)),
      )) {
        if (
          date === today &&
          supplier.products.some(
            (product) => !product.demo && product.stock <= product.minimum,
          )
        )
          events.push({
            id: `stock-cycle-${cycle.id}`,
            date,
            label: `Reponer · ${supplier.name}`,
            kind: "stock",
            href: `/pedidos/nuevo?proveedor=${supplier.id}&ciclo=${cycle.id}&fecha=${date}`,
          });
      }
      if (!supplier.cycles.length && supplier.scheduleMode === "FIXED") {
        if (
          supplier.orderDays.includes(dayOfWeek) &&
          !orders.some(
            (o) =>
              o.supplierId === supplier.id &&
              o.status !== "CANCELADO" &&
              o.orderDate &&
              isoDay(o.orderDate) === date,
          )
        )
          events.push({
            id: `fixed-order-${supplier.id}-${date}`,
            date,
            label: `Realizar pedido · ${supplier.name}`,
            kind: "fijo",
            href: `/proveedores/${supplier.id}`,
          });
        if (
          supplier.deliveryDays.includes(dayOfWeek) &&
          !orders.some(
            (o) =>
              o.supplierId === supplier.id &&
              o.status !== "CANCELADO" &&
              isoDay(o.date) === date,
          )
        )
          events.push({
            id: `fixed-delivery-${supplier.id}-${date}`,
            date,
            label: `Entrega habitual · ${supplier.name}`,
            kind: "fijo",
            href: `/proveedores/${supplier.id}`,
          });
      }
      if (supplier.scheduleMode === "MIN_STOCK" && date === today) {
        const low = supplier.products.filter(
          (product) => product.stock <= product.minimum,
        );
        if (low.length)
          events.push({
            id: "stock-" + supplier.id,
            date,
            label: `Reponer · ${supplier.name} (${low.length} productos)`,
            kind: "stock",
            href: `/proveedores/${supplier.id}`,
          });
      }
    }
  }
  const todayEvents = events.filter((e) => e.date === today);
  const pendingPayments = tasks.filter((t) => t.type === "PAGO" && !t.doneAt);
  const pendingOrders = orders.filter((o) => OPEN_STATUSES.includes(o.status));
  const overdue = orders.filter(
    (o) => OPEN_STATUSES.includes(o.status) && isoDay(o.date) < today,
  );
  const url = (date: string, v = view) =>
    `/calendario?vista=${v}&fecha=${date}&proveedor=${p.proveedor || ""}&estado=${p.estado || ""}`;
  const title =
    view === "mes"
      ? from.toLocaleDateString("es-CL", {
          month: "long",
          year: "numeric",
          timeZone: "UTC",
        })
      : view === "dia"
        ? formatDay(from)
        : `${from.toLocaleDateString("es-CL", { day: "numeric", month: "short", timeZone: "UTC" })} — ${days[6].toLocaleDateString("es-CL", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" })}`;
  return (
    <>
      <p className="eyebrow">TU JORNADA, EN ORDEN · HORARIO DE CHILE</p>
      <div className="page-heading">
        <div>
          <h1>Calendario de proveedores</h1>
          <p>Pedidos, entregas y recordatorios para organizar cada día.</p>
        </div>
        {editable && (
          <Link href="/proveedores/nuevo" className="button">
            + Agregar proveedor
          </Link>
        )}
      </div>
      <form className="filters">
        <input name="vista" type="hidden" value={view} />
        <input name="fecha" type="hidden" value={anchor} />
        <label>
          Filtrar por proveedor
          <select name="proveedor" defaultValue={p.proveedor || ""}>
            <option value="">Todos</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Filtrar por estado
          <select name="estado" defaultValue={p.estado || ""}>
            <option value="">Todos</option>
            {ORDER_STATUSES.map((state) => (
              <option key={state} value={state}>
                {STATUS_LABELS[state]}
              </option>
            ))}
          </select>
        </label>
        <button className="secondary">Filtrar calendario</button>
      </form>
      <div className="stats">
        {[
          ["Ventas del día", clp(summary.sales)],
          ["Gastos operativos del día", clp(summary.expenses)],
          ["Efectivo esperado en cajas", clp(summary.cash)],
          [
            "Saldo pendiente a proveedores",
            summary.payable === null ? "Acceso limitado" : clp(summary.payable),
          ],
          [
            "Presupuesto estimado de compras",
            summary.available === null
              ? "Pendiente de configuración"
              : clp(summary.available),
          ],
        ].map(([label, value]) => (
          <article key={label}>
            <small>{label}</small>
            <strong>{value}</strong>
          </article>
        ))}
      </div>
      <p className="help">
        El presupuesto solo se calcula con saldos y reservas confirmados;
        descuenta saldos a proveedores y reservas. No equivale a utilidad ni a
        crédito disponible.{" "}
        {user.role === "ADMIN" && (
          <Link href="/configuracion">Revisar configuración</Link>
        )}
      </p>
      <div className="stats">
        <article>
          <small>Pedidos abiertos en el período</small>
          <strong>{pendingOrders.length}</strong>
        </article>
        <article>
          <small>Compras estimadas del período</small>
          <strong>
            {clp(
              orders
                .filter((o) => o.status !== "CANCELADO")
                .reduce((a, o) => a + o.budget, 0),
            )}
          </strong>
          <small>Presupuestos referenciales, no pagos</small>
        </article>
        <article>
          <small>Pagos por revisar</small>
          <strong>
            {clp(
              invoices.reduce(
                (a, i) =>
                  a +
                  Math.max(
                    0,
                    i.amount - i.payments.reduce((b, v) => b + v.amount, 0),
                  ),
                0,
              ),
            )}
          </strong>
          <small>
            Facturas del período · {pendingPayments.length} recordatorios
            manuales separados
          </small>
        </article>
      </div>
      <div className="columns">
        <section className="card">
          <div className="section-heading">
            <h2>Qué corresponde hacer hoy</h2>
            <span className="badge">{formatDay(dateOnly(today))}</span>
          </div>
          {!(from <= dateOnly(today) && dateOnly(today) < until) ? (
            <p>
              Estás viendo otro período.{" "}
              <Link href={url(today, "dia")}>Ir a la agenda de hoy →</Link>
            </p>
          ) : todayEvents.length ? (
            <ul className="today-list">
              {todayEvents.map((e) => (
                <li key={e.id}>
                  <a href={e.href}>
                    <span className={`event-dot ${e.kind}`} />
                    {e.label}
                  </a>
                  {e.amount !== undefined && (
                    <small>{clp(e.amount)} referencial</small>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p>No hay tareas programadas para hoy en este período.</p>
          )}
          <div className="quick-links">
            <Link href="/proveedores">Directorio de proveedores →</Link>
            <Link href="/caja">Abrir mi caja →</Link>
          </div>
        </section>
        <section className="card">
          <h2>Alertas de inventario</h2>
          <p>{lowStock.length} productos necesitan reposición.</p>
          {lowStock.slice(0, 5).map((product) => (
            <div className="stock-row" key={product.id}>
              <Link href="/inventario">{product.name}</Link>
              <span className="badge warning">
                {product.stock} / mín. {product.minimum}
              </span>
            </div>
          ))}
          {!lowStock.length && <p>Sin productos bajo el mínimo registrado.</p>}
          {lowStock.length > 5 && (
            <Link href="/inventario">Ver todas las alertas →</Link>
          )}
        </section>
      </div>
      {!!overdue.length && (
        <p role="status" className="alert">
          Hay {overdue.length} entregas pendientes con fecha vencida en este
          período.
        </p>
      )}
      <section className="card calendar-card">
        <div className="calendar-toolbar">
          <div className="view-tabs" aria-label="Vista del calendario">
            {(["dia", "semana", "mes"] as const).map((v) => (
              <Link
                key={v}
                href={url(anchor, v)}
                aria-current={view === v ? "page" : undefined}
              >
                {v === "dia"
                  ? "Diaria"
                  : v === "semana"
                    ? "Semanal"
                    : "Mensual"}
              </Link>
            ))}
          </div>
          <form className="date-jump">
            <input type="hidden" name="vista" value={view} />
            <input name="proveedor" type="hidden" value={p.proveedor || ""} />
            <input name="estado" type="hidden" value={p.estado || ""} />
            <label>
              Ir a fecha
              <input name="fecha" type="date" defaultValue={anchor} required />
            </label>
            <button className="secondary">Ver fecha</button>
          </form>
        </div>
        <div className="section-heading calendar-heading">
          <h2>{title}</h2>
          <div className="toolbar">
            <Link
              href={url(adjacentDate(anchor, view, -1))}
              aria-label="Período anterior"
            >
              ←
            </Link>
            <Link href={url(today)}>Hoy</Link>
            <Link
              href={url(adjacentDate(anchor, view, 1))}
              aria-label="Período siguiente"
            >
              →
            </Link>
          </div>
        </div>
        <div
          className={`calendar calendar-${view}`}
          aria-label={`Calendario ${view === "semana" ? "semanal" : view === "dia" ? "diario" : "mensual"}`}
        >
          {view === "mes" && (
            <>
              {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((d) => (
                <b key={d}>{d}</b>
              ))}
              {Array.from({ length: (from.getUTCDay() + 6) % 7 }, (_, i) => (
                <div key={"blank" + i} className="empty" />
              ))}
            </>
          )}
          {days.map((day) => {
            const date = isoDay(day);
            const dayEvents = events.filter((e) => e.date === date);
            return (
              <div
                className={`day ${date === today ? "today" : ""}`}
                key={date}
              >
                <Link href={url(date, "dia")} className="day-heading">
                  {view === "mes"
                    ? day.getUTCDate()
                    : day.toLocaleDateString("es-CL", {
                        weekday: "short",
                        day: "numeric",
                        month: "short",
                        timeZone: "UTC",
                      })}
                </Link>
                {dayEvents.map((event) => (
                  <a
                    key={event.id}
                    className={`calendar-event event-${event.kind}`}
                    href={event.href}
                  >
                    {event.label}
                    {event.amount !== undefined && (
                      <small>{clp(event.amount)}</small>
                    )}
                  </a>
                ))}
                {!dayEvents.length && view !== "mes" && (
                  <small>Sin actividades</small>
                )}
              </div>
            );
          })}
        </div>
        <div className="legend">
          <span>Pedidos y entregas</span>
          <span>Recordatorios habituales: no confirman un pedido</span>
          <span>Pagos: no mueven dinero</span>
        </div>
      </section>
      <div className="columns">
        <section className="card">
          <h2>Pedidos del período</h2>
          {!orders.length && (
            <p>No hay pedidos registrados para estas fechas.</p>
          )}
          {orders.map((order) => (
            <article className="order" id={`order-${order.id}`} key={order.id}>
              <div className="section-heading">
                <h3>
                  <Link href={`/proveedores/${order.supplier.id}`}>
                    {order.supplier.name}
                  </Link>
                </h3>
                <span
                  className={
                    order.status === "CANCELADO" ? "badge warning" : "badge"
                  }
                >
                  {STATUS_LABELS[order.status]}
                </span>
              </div>
              <small>
                Pedido:{" "}
                {order.orderDate
                  ? order.orderDate.toLocaleDateString("es-CL", {
                      timeZone: "UTC",
                    })
                  : "Sin fecha registrada"}{" "}
                · Entrega:{" "}
                {order.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
              </small>
              <small>
                {clp(order.budget)} estimados
                {!order.supplier.active ? " · Proveedor inactivo" : ""}
              </small>
              <p className="pre">{order.detail}</p>
              <Link href={`/pedidos/${order.id}`}>
                Abrir detalle, productos y recepción →
              </Link>
              {editable && (
                <ActionForm
                  action={changeOrderStatus}
                  label={`Estado del pedido ${order.id}`}
                >
                  <input type="hidden" name="id" value={order.id} />
                  <input type="hidden" name="version" value={order.version} />
                  <div className="inline">
                    <select
                      name="status"
                      aria-label="Estado del pedido"
                      defaultValue={order.status}
                    >
                      {ORDER_STATUSES.filter(
                        (status) => status !== "RECIBIDO",
                      ).map((status) => (
                        <option key={status} value={status}>
                          {STATUS_LABELS[status]}
                        </option>
                      ))}
                    </select>
                    <button className="secondary">Actualizar</button>
                  </div>
                </ActionForm>
              )}
              <small>
                WhatsApp y recepción están disponibles en el detalle de pedidos
                por productos. Abrir WhatsApp no confirma el envío.
              </small>
            </article>
          ))}
          <h2>Recordatorios por fecha</h2>
          <p>
            Una tarea resuelta no equivale a un pago, una factura ni una
            recepción de mercadería.
          </p>
          {!tasks.length && <p>Sin recordatorios para estas fechas.</p>}
          {tasks.map((task) => (
            <article className="order" id={`task-${task.id}`} key={task.id}>
              <h3>
                {task.supplier.name}{" "}
                <span className="badge">
                  {task.type === "PAGO"
                    ? "Pago pendiente"
                    : task.type === "ENTREGA"
                      ? "Entrega"
                      : "Pedido"}
                </span>
              </h3>
              <small>
                {task.date.toLocaleDateString("es-CL", { timeZone: "UTC" })} ·{" "}
                {clp(task.amount)} referenciales ·{" "}
                {task.doneAt ? "Resuelto" : "Pendiente"}
              </small>
              <p>{task.description}</p>
              {editable && (
                <ActionForm action={finishTask}>
                  <input type="hidden" name="id" value={task.id} />
                  <input
                    type="hidden"
                    name="done"
                    value={task.doneAt ? "false" : "true"}
                  />
                  <button className="secondary">
                    {task.doneAt
                      ? "Reabrir recordatorio"
                      : "Marcar recordatorio resuelto"}
                  </button>
                </ActionForm>
              )}
            </article>
          ))}
        </section>
        {editable && (
          <section className="card">
            <h2>Programar pedido</h2>
            <p>
              Registro libre para proveedores sin ciclos. Para compras con
              calendario, cantidades y recepción, usa el pedido por productos de
              la ficha del proveedor. No envía mensajes ni descuenta dinero o
              stock.
            </p>
            {freeformSuppliers.length ? (
              <ActionForm action={saveCalendarOrder} label="Programar pedido">
                <label>
                  Proveedor
                  <select name="supplierId" required>
                    {freeformSuppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="columns">
                  <label>
                    Fecha de pedido
                    <input
                      name="orderDate"
                      type="date"
                      defaultValue={today}
                      required
                    />
                  </label>
                  <label>
                    Fecha de entrega
                    <input
                      name="date"
                      type="date"
                      defaultValue={today}
                      required
                    />
                  </label>
                </div>
                <label>
                  Productos y cantidades
                  <textarea
                    name="detail"
                    required
                    maxLength={2000}
                    rows={4}
                    placeholder="Descripción del pedido planificado"
                  />
                </label>
                <label>
                  Presupuesto aproximado (CLP)
                  <input
                    name="budget"
                    type="number"
                    min={0}
                    max={1000000000}
                    required
                  />
                </label>
                <button>Guardar pedido</button>
              </ActionForm>
            ) : (
              <p>
                Elige un proveedor en el directorio para preparar un pedido por
                productos.
              </p>
            )}
            <hr />
            <h2>Agregar recordatorio</h2>
            <p>
              Para pedidos flexibles, entregas puntuales o pagos que debas
              revisar. No genera documentos contables.
            </p>
            {!!suppliers.length && (
              <ActionForm action={saveTask} label="Agregar recordatorio">
                <label>
                  Proveedor del recordatorio
                  <select name="supplierId" required>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Tipo de recordatorio
                  <select name="type">
                    <option value="PEDIDO">Realizar pedido</option>
                    <option value="ENTREGA">Entrega programada</option>
                    <option value="PAGO">Pago pendiente por revisar</option>
                  </select>
                </label>
                <label>
                  Fecha del recordatorio
                  <input
                    name="date"
                    type="date"
                    defaultValue={today}
                    required
                  />
                </label>
                <label>
                  Descripción del recordatorio
                  <input
                    name="description"
                    minLength={2}
                    maxLength={500}
                    required
                  />
                </label>
                <label>
                  Monto referencial (CLP)
                  <input
                    name="amount"
                    type="number"
                    min={0}
                    max={1000000000}
                    defaultValue={0}
                    required
                  />
                </label>
                <button className="secondary">Guardar recordatorio</button>
              </ActionForm>
            )}
          </section>
        )}
      </div>
    </>
  );
}

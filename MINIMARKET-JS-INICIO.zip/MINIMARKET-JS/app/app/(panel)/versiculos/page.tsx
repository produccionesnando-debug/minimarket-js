import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { TOPICS } from "@/lib/daily-scripture";
import { scriptureAction } from "@/app/scripture-actions";
import { ActionForm } from "@/components/action-form";
function Fields({
  verse,
}: {
  verse?: {
    id: string;
    text: string;
    reference: string;
    translation: string;
    topic: string;
    rights: string;
    rightsNote: string;
    active: boolean;
  };
}) {
  return (
    <>
      <input type="hidden" name="id" value={verse?.id || ""} />
      <label>
        Texto del versículo
        <textarea
          name="text"
          required
          minLength={3}
          maxLength={1000}
          defaultValue={verse?.text}
        />
      </label>
      <label>
        Referencia bíblica
        <input
          name="reference"
          required
          maxLength={100}
          defaultValue={verse?.reference}
        />
      </label>
      <label>
        Traducción
        <input
          name="translation"
          required
          maxLength={100}
          defaultValue={verse?.translation}
        />
      </label>
      <label>
        Tema
        <select name="topic" defaultValue={verse?.topic}>
          {TOPICS.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </label>
      <label>
        Derechos de reproducción
        <select name="rights" defaultValue={verse?.rights || "PUBLIC_DOMAIN"}>
          <option value="PUBLIC_DOMAIN">Dominio público</option>
          <option value="AUTHORIZED">Tengo autorización</option>
        </select>
      </label>
      <label>
        Fuente o autorización
        <input
          name="rightsNote"
          maxLength={500}
          defaultValue={verse?.rightsNote}
        />
      </label>
      <label>
        <input
          type="checkbox"
          name="active"
          defaultChecked={verse?.active ?? true}
        />
        Publicado
      </label>
      <label>
        <input type="checkbox" required />
        Verifiqué el texto, referencia y permiso de reproducción.
      </label>
      <button>Guardar versículo</button>
    </>
  );
}
export default async function Scriptures() {
  await requireUser(true);
  const verses = await db.scripture.findMany({ orderBy: { id: "asc" } });
  return (
    <>
      <h1>Biblioteca de versículos</h1>
      <p>
        Selección inicial de Reina-Valera 1909, de dominio público. No se carga
        una traducción moderna protegida. El texto elegido hoy queda fijado; las
        ediciones afectan las próximas selecciones.
      </p>
      <details className="card">
        <summary>Agregar versículo autorizado</summary>
        <ActionForm action={scriptureAction}>
          <Fields />
        </ActionForm>
      </details>
      {verses.map((v) => (
        <details key={v.id} className="card">
          <summary>
            {v.reference} · {v.topic} · {v.active ? "Publicado" : "Inactivo"}
          </summary>
          <ActionForm action={scriptureAction}>
            <Fields verse={v} />
          </ActionForm>
        </details>
      ))}
    </>
  );
}

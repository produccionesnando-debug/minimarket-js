import Link from "next/link";
import { LiveRefresh } from "@/components/live-refresh";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { conversationScope, ATTENTION } from "@/lib/client-orders";
import { can } from "@/lib/permissions";
import { clp, METHODS } from "@/lib/money";
import {
  dateOnly,
  validDate,
  isoDay,
  addDays,
  chileDayStart,
} from "@/lib/dates";
import { ActionForm } from "@/components/action-form";
import {
  ClientOrderBuilder,
  ReplyDraft,
} from "@/components/client-order-builder";
import {
  conversationAction,
  attentionAction,
  messageAction,
  orderOperation,
  specialAction,
  templateAction,
  retentionAction,
} from "@/app/client-actions";
const label = (s: string) =>
  ({
    NUEVO: "Nuevo",
    EN_REVISION: "En revisión",
    ESPERANDO_CONFIRMACION: "Esperando confirmación",
    CONFIRMADO: "Confirmado",
    EN_PREPARACION: "En preparación",
    LISTO_RETIRO: "Listo para retiro",
    EN_REPARTO: "En reparto",
    ENTREGADO: "Entregado",
    CANCELADO: "Cancelado",
  })[s] || s;
export default async function Inbox({
  searchParams,
}: {
  searchParams: Promise<{
    id?: string;
    q?: string;
    estado?: string;
    fecha?: string;
    vista?: string;
  }>;
}) {
  const actor = await requireUser(),
    p = await searchParams,
    scope = conversationScope(actor);
  const [conversations, templates, workers, settings, customers] =
    await Promise.all([
      db.clientConversation.findMany({
        where: {
          ...scope,
          ...(p.q
            ? {
                OR: [
                  { name: { contains: p.q, mode: "insensitive" } },
                  { phone: { contains: p.q } },
                ],
              }
            : {}),
          ...(ATTENTION.includes(p.estado as (typeof ATTENTION)[number])
            ? { status: p.estado }
            : {}),
          ...(p.fecha && validDate(p.fecha)
            ? {
                createdAt: {
                  gte: chileDayStart(p.fecha),
                  lt: chileDayStart(isoDay(addDays(dateOnly(p.fecha), 1))),
                },
              }
            : {}),
        },
        include: {
          messages: { orderBy: { createdAt: "desc" }, take: 1 },
          orders: { select: { id: true, status: true } },
        },
        orderBy: { updatedAt: "desc" },
        take: 100,
      }),
      db.quickReply.findMany(),
      db.user.findMany({
        where: { active: true },
        select: { id: true, name: true },
      }),
      db.messagingSettings.findUnique({ where: { id: "global" } }),
      db.customer.findMany({
        where: { active: true },
        select: { id: true, name: true, demo: true },
        take: 500,
      }),
    ]);
  const selectedId = p.id || conversations[0]?.id;
  const c = selectedId
    ? await db.clientConversation.findFirst({
        where: { id: selectedId, ...scope },
        include: {
          messages: { orderBy: { createdAt: "asc" }, take: 300 },
          orders: { include: { items: true }, orderBy: { createdAt: "desc" } },
        },
      })
    : null;
  const [products, suppliers, shift] = await Promise.all([
    db.product.findMany({
      where: { demo: c?.demo || false },
      select: { id: true, name: true, price: true, stock: true },
      orderBy: { name: "asc" },
      take: 1000,
    }),
    db.supplier.findMany({
      where: { demo: c?.demo || false, active: true },
      select: { id: true, name: true },
    }),
    db.shift.findFirst({ where: { userId: actor.id, closedAt: null } }),
  ]);
  const payments = c
    ? await db.collection.findMany({
        where: { orderId: { in: c.orders.map((o) => o.id) } },
      })
    : [];
  const specialRequests = await db.clientOrderItem.findMany({
    where: {
      order: {
        conversation: scope,
        status: { notIn: ["CANCELADO", "ENTREGADO"] },
      },
      OR: [
        { productId: null },
        { procurement: "PROPUESTA_COMPRA" },
        { procurement: "RECIBIDO" },
      ],
    },
    include: { order: { select: { conversationId: true } } },
    take: 100,
  });
  const view = p.vista || "mensajes";
  return (
    <>
      <LiveRefresh />
      <div className="page-heading">
        <div>
          <p className="eyebrow">ATENCIÓN DE CLIENTES</p>
          <h1>WhatsApp — Pedidos y encargos</h1>
          <p>
            {conversations.filter((c) => c.status === "NUEVO").length} nuevos ·{" "}
            {conversations.reduce(
              (a, c) =>
                a +
                c.orders.filter(
                  (o) => !["ENTREGADO", "CANCELADO"].includes(o.status),
                ).length,
              0,
            )}{" "}
            encargos pendientes en los resultados
          </p>
        </div>
        <span className="badge warning">
          Ingreso manual / demostración · sin envío automático
        </span>
      </div>
      <p className="help">
        Conexión oficial{" "}
        {settings?.inboundEnabled
          ? "habilitada por el administrador; requiere webhook y credenciales Meta verificadas"
          : "desactivada"}
        . Los mensajes manuales no provienen de una conexión WhatsApp activa.
      </p>
      <details className="card">
        <summary>Nueva conversación / encargo manual</summary>
        <ActionForm action={conversationAction}>
          <input type="hidden" name="requestKey" value={randomUUID()} />
          <label>
            Nombre del cliente
            <input name="name" required minLength={2} maxLength={150} />
          </label>
          <label>
            Teléfono internacional
            <input
              name="phone"
              required
              placeholder="+56…"
              pattern="\+[1-9][0-9]{7,14}"
            />
          </label>
          <label>
            Cliente existente (opcional)
            <select name="customerId">
              <option value="">Sin asociar</option>
              {customers.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                  {x.demo ? " · DEMO" : ""}
                </option>
              ))}
            </select>
          </label>
          <label>
            Mensaje recibido o solicitud
            <textarea name="body" required maxLength={4000} />
          </label>
          <label>
            <input type="checkbox" name="demo" value="true" />
            Conversación ficticia de demostración
          </label>
          <button>Registrar conversación</button>
        </ActionForm>
      </details>
      <details className="card">
        <summary>
          Encargos especiales y propuestas de compra ({specialRequests.length})
        </summary>
        {specialRequests.map((i) => (
          <p key={i.id}>
            <Link
              href={"/whatsapp?id=" + i.order.conversationId + "&vista=pedido"}
            >
              {i.quantity} × {i.description}
            </Link>{" "}
            · {i.procurement} · Compromiso:{" "}
            {i.committedAt?.toISOString().slice(0, 10) || "Por definir"}
          </p>
        ))}
        {!specialRequests.length && <p>Sin encargos especiales pendientes.</p>}
      </details>
      <nav className="inbox-tabs">
        <Link
          href={
            "/whatsapp?id=" + encodeURIComponent(c?.id || "") + "&vista=lista"
          }
        >
          Conversaciones
        </Link>
        <Link
          href={
            "/whatsapp?id=" +
            encodeURIComponent(c?.id || "") +
            "&vista=mensajes"
          }
        >
          Mensajes
        </Link>
        <Link
          href={
            "/whatsapp?id=" + encodeURIComponent(c?.id || "") + "&vista=pedido"
          }
        >
          Cliente y pedidos
        </Link>
      </nav>
      <div className={"inbox-layout inbox-view-" + view}>
        <section className="card inbox-list">
          <h2>Bandeja de entrada</h2>
          <form>
            <label>
              Buscar cliente o teléfono
              <input name="q" defaultValue={p.q} />
            </label>
            <label>
              Estado
              <select name="estado">
                <option value="">Todos</option>
                {ATTENTION.map((s) => (
                  <option key={s} value={s}>
                    {label(s)}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Fecha de recepción
              <input type="date" name="fecha" defaultValue={p.fecha} />
            </label>
            <button>Buscar</button>
          </form>
          {conversations.map((x) => (
            <Link
              className={
                "conversation-row " + (x.id === c?.id ? "selected" : "")
              }
              key={x.id}
              href={"/whatsapp?id=" + x.id}
            >
              <strong>{x.name}</strong>
              <small>
                {x.phone} · {x.source}
              </small>
              <span>
                {x.messages[0]?.body.slice(0, 100) ||
                  "Mensajes eliminados por conservación"}
              </span>
              <small>
                {label(x.status)} ·{" "}
                {workers.find((w) => w.id === x.assignedId)?.name} ·{" "}
                {x.updatedAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}
              </small>
              <small>{x.orders.length} pedidos asociados</small>
            </Link>
          ))}
          {!conversations.length && (
            <p>No hay conversaciones para estos filtros.</p>
          )}
        </section>
        <section className="card inbox-messages">
          <h2>{c?.name || "Selecciona una conversación"}</h2>
          {c && (
            <>
              <p>
                {c.phone} · {c.source}
                {c.demo ? " · DEMOSTRACIÓN" : ""}
              </p>
              <div className="message-thread">
                {c.messages.map((m) => (
                  <article
                    className={
                      "message-bubble " +
                      (m.direction === "INTERNA" ? "internal" : "")
                    }
                    key={m.id}
                  >
                    <small>
                      {m.direction === "INTERNA"
                        ? "Aviso interno"
                        : "Mensaje registrado"}{" "}
                      ·{" "}
                      {m.createdAt.toLocaleString("es-CL", {
                        timeZone: "America/Santiago",
                      })}
                    </small>
                    <p>{m.body}</p>
                  </article>
                ))}
              </div>
              <ActionForm action={messageAction}>
                <input type="hidden" name="conversationId" value={c.id} />
                <input type="hidden" name="requestKey" value={randomUUID()} />
                <label>
                  Agregar mensaje recibido o nota manual
                  <textarea name="body" required maxLength={4000} />
                </label>
                <button>Guardar sin enviar</button>
              </ActionForm>
              <ReplyDraft templates={templates} />
            </>
          )}
        </section>
        <section className="card inbox-orders">
          <h2>Cliente y pedido</h2>
          {c && (
            <>
              <p>
                {c.name} · {c.phone}
              </p>
              <ActionForm action={attentionAction}>
                <input type="hidden" name="conversationId" value={c.id} />
                <label>
                  Estado de atención
                  <select name="status" defaultValue={c.status}>
                    {ATTENTION.filter((s) => s !== "ENTREGADO").map((s) => (
                      <option key={s} value={s}>
                        {label(s)}
                      </option>
                    ))}
                  </select>
                </label>
                {can(actor.role, "shifts:manage") && (
                  <label>
                    Responsable
                    <select name="assignedId" defaultValue={c.assignedId}>
                      {workers.map((w) => (
                        <option key={w.id} value={w.id}>
                          {w.name}
                        </option>
                      ))}
                    </select>
                  </label>
                )}
                <button>Actualizar atención</button>
              </ActionForm>
              {c.orders.map((o) => {
                const paid = payments
                    .filter((x) => x.orderId === o.id)
                    .reduce((a, x) => a + x.amount, 0),
                  total = o.items.reduce(
                    (a, i) => a + (i.price || 0) * i.quantity,
                    0,
                  );
                return (
                  <section className="client-order" key={o.id}>
                    <h3>
                      Pedido {o.id.slice(-8)} · {o.status}
                    </h3>
                    <p>
                      {o.mode === "RETIRO" ? "Retiro en local" : "Despacho"} ·{" "}
                      {o.requestedAt?.toISOString().slice(0, 10) || "Sin fecha"}{" "}
                      · {o.notes}
                    </p>
                    {o.items.map((i) => (
                      <div key={i.id}>
                        <p>
                          <strong>
                            {i.quantity} × {i.description}
                          </strong>{" "}
                          · {i.price === null ? "Sin cotizar" : clp(i.price)} ·{" "}
                          {i.reserved ? "Stock reservado" : "Sin reserva"}
                        </p>
                        {o.status === "SOLICITADO" && (
                          <details>
                            <summary>Encargo / propuesta de compra</summary>
                            <ActionForm action={specialAction}>
                              <input type="hidden" name="itemId" value={i.id} />
                              <label>
                                Producto recibido del catálogo
                                <select
                                  name="productId"
                                  defaultValue={i.productId || ""}
                                >
                                  <option value="">
                                    Encargo especial sin precio
                                  </option>
                                  {products.map((x) => (
                                    <option key={x.id} value={x.id}>
                                      {x.name} · {clp(x.price)}
                                    </option>
                                  ))}
                                </select>
                              </label>
                              <label>
                                Proveedor sugerido
                                <select
                                  name="supplierId"
                                  defaultValue={i.supplierId || ""}
                                >
                                  <option value="">Sin definir</option>
                                  {suppliers.map((x) => (
                                    <option key={x.id} value={x.id}>
                                      {x.name}
                                    </option>
                                  ))}
                                </select>
                              </label>
                              <label>
                                Fecha comprometida
                                <input
                                  type="date"
                                  name="committedDate"
                                  defaultValue={i.committedAt
                                    ?.toISOString()
                                    .slice(0, 10)}
                                />
                              </label>
                              <label>
                                Gestión de compra
                                <select
                                  name="procurement"
                                  defaultValue={i.procurement}
                                >
                                  <option value="PENDIENTE">Pendiente</option>
                                  <option value="PROPUESTA_COMPRA">
                                    Agregar a propuesta de compra interna
                                  </option>
                                  <option value="RECIBIDO">
                                    Recibido · avisar al responsable
                                  </option>
                                </select>
                              </label>
                              <button>Actualizar encargo</button>
                              <p className="help">
                                No ejecuta compras ni agrega stock. Registra
                                antes la recepción real en inventario.
                              </p>
                            </ActionForm>
                          </details>
                        )}
                      </div>
                    ))}
                    <p>
                      Total estimado {clp(total)}
                      {o.items.some((i) => i.price === null)
                        ? " + productos sin cotizar"
                        : ""}{" "}
                      · Anticipos {clp(paid)} · Saldo {o.items.some(i=>i.price===null)?"Por cotizar":clp(total-paid)}
                    </p>
                    {o.saleId ? (
                      <>
                        <Link
                          className="button secondary"
                          href={"/ventas/" + o.saleId}
                        >
                          Ver venta y pagos
                        </Link>
                        {o.status !== "ENTREGADO" && (
                          <ActionForm action={orderOperation}>
                            <input type="hidden" name="orderId" value={o.id} />
                            <button name="op" value="deliver">
                              Marcar entregado
                            </button>
                          </ActionForm>
                        )}
                      </>
                    ) : (
                      o.status !== "CANCELADO" && (
                        <>
                          <ActionForm action={orderOperation}>
                            <input type="hidden" name="orderId" value={o.id} />
                            {o.status === "SOLICITADO" && (
                              <button name="op" value="confirm">
                                Confirmar y reservar stock
                              </button>
                            )}
                            <button
                              name="op"
                              value="cancel"
                              className="secondary"
                            >
                              Cancelar y liberar reserva
                            </button>
                          </ActionForm>
                          {shift && shift.demo === o.demo && (
                            <>
                              <ActionForm action={orderOperation}>
                                <input
                                  type="hidden"
                                  name="requestKey"
                                  value={randomUUID()}
                                />
                                <input
                                  type="hidden"
                                  name="orderId"
                                  value={o.id}
                                />
                                <input
                                  type="hidden"
                                  name="shiftId"
                                  value={shift.id}
                                />
                                <label>
                                  Monto anticipo / reembolso
                                  <input
                                    name="amount"
                                    type="number"
                                    required
                                    min={1}
                                  />
                                </label>
                                <label>
                                  Medio de pago
                                  <select name="method">
                                    {METHODS.map((m) => (
                                      <option key={m}>{m}</option>
                                    ))}
                                  </select>
                                </label>
                                <button name="op" value="advance">
                                  Registrar anticipo
                                </button>
                                {can(actor.role, "returns:approve") && (
                                  <button
                                    name="op"
                                    value="refund"
                                    className="secondary"
                                  >
                                    Reembolsar anticipo
                                  </button>
                                )}
                              </ActionForm>
                              {o.status === "CONFIRMADO" && (
                                <ActionForm action={orderOperation}>
                                  <input
                                    type="hidden"
                                    name="requestKey"
                                    value={randomUUID()}
                                  />
                                  <input
                                    type="hidden"
                                    name="orderId"
                                    value={o.id}
                                  />
                                  <input
                                    type="hidden"
                                    name="shiftId"
                                    value={shift.id}
                                  />
                                  <label>
                                    Cobrar saldo con
                                    <select name="method">
                                      {METHODS.map((m) => (
                                        <option key={m}>{m}</option>
                                      ))}
                                    </select>
                                  </label>
                                  <label>
                                    Efectivo recibido (si corresponde)
                                    <input
                                      name="tendered"
                                      type="number"
                                      min={0}
                                      defaultValue={Math.max(0, total - paid)}
                                    />
                                  </label>
                                  <label>
                                    <input type="checkbox" required />
                                    Revisé el pedido y el saldo a cobrar.
                                  </label>
                                  <button name="op" value="sell">
                                    Completar venta en caja
                                  </button>
                                </ActionForm>
                              )}
                            </>
                          )}
                          {!shift && (
                            <Link href="/caja">Abrir caja para cobrar</Link>
                          )}
                        </>
                      )
                    )}
                  </section>
                );
              })}
              <details>
                <summary>Crear pedido interno desde estos mensajes</summary>
                <ClientOrderBuilder
                  conversationId={c.id}
                  requestKey={randomUUID()}
                  products={products}
                />
              </details>
            </>
          )}
        </section>
      </div>
      {actor.role === "ADMIN" && (
        <details className="card">
          <summary>Plantillas y privacidad</summary>
          {templates.map((t) => (
            <ActionForm key={t.id} action={templateAction}>
              <input type="hidden" name="id" value={t.id} />
              <label>
                Título
                <input name="title" defaultValue={t.title} required />
              </label>
              <label>
                Mensaje
                <textarea name="body" defaultValue={t.body} required />
              </label>
              <button>Guardar plantilla</button>
            </ActionForm>
          ))}
          <ActionForm action={retentionAction}>
            <label>
              Conservar mensajes (días)
              <input
                type="number"
                name="retentionDays"
                min={1}
                max={3650}
                defaultValue={settings?.retentionDays || 365}
                required
              />
            </label>
            <label>
              Responsable para nuevos webhooks
              <select
                name="assignedId"
                defaultValue={settings?.assignedId || ""}
              >
                <option value="">Sin asignar · recepción bloqueada</option>
                {workers.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <input
                name="inboundEnabled"
                type="checkbox"
                defaultChecked={settings?.inboundEnabled}
              />
              Habilitar recepción oficial con credenciales verificadas
            </label>
            <label>
              Confirmar eliminación antigua (opcional)
              <input name="purge" placeholder="Escribe ELIMINAR" />
            </label>
            <button>
              Guardar conservación / ejecutar eliminación confirmada
            </button>
            <p className="help">
              Solo elimina textos antiguos, conserva comprobantes y
              trazabilidad. Los mensajes no se usan para campañas.
            </p>
          </ActionForm>
        </details>
      )}
    </>
  );
}

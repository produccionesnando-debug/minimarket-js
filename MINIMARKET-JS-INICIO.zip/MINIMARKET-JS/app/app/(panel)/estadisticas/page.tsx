import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { getReport, reportInput } from "@/lib/reports";
import { clp } from "@/lib/money";
import { ReportCharts } from "@/components/report-charts";
export default async function Reports({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const user = await requireUser();
  if (!can(user.role, "stats:read"))
    return (
      <section className="card">
        <h1>Acceso restringido</h1>
        <p>
          Los informes financieros están reservados a administración y
          supervisión.
        </p>
      </section>
    );
  let input;
  try {
    input = reportInput(await searchParams);
  } catch {
    return (
      <section className="card">
        <h1>Período inválido</h1>
        <p>Selecciona fechas ordenadas y un rango de hasta tres años.</p>
        <Link href="/estadisticas">Volver a filtros</Link>
      </section>
    );
  }
  const r = await getReport(input);
  const query = new URLSearchParams({
    desde: input.from,
    hasta: input.to,
    grupo: input.group,
    demo: input.demo ? "1" : "0",
  });
  return (
    <>
      <p className="eyebrow">DATOS PERSISTIDOS · HORARIO DE CHILE</p>
      <h1>Estadísticas e informes</h1>
      {input.demo && (
        <p className="alert">
          DEMOSTRACIÓN · Operaciones ficticias separadas de los datos reales.
        </p>
      )}
      <form className="filters">
        <label>
          Desde
          <input name="desde" type="date" defaultValue={input.from} required />
        </label>
        <label>
          Hasta
          <input name="hasta" type="date" defaultValue={input.to} required />
        </label>
        <label>
          Agrupar por
          <select name="grupo" defaultValue={input.group}>
            <option value="dia">Día</option>
            <option value="semana">Semana</option>
            <option value="mes">Mes</option>
            <option value="ano">Año</option>
          </select>
        </label>
        <label>
          Datos
          <select name="demo" defaultValue={input.demo ? "1" : "0"}>
            <option value="0">Negocio real</option>
            <option value="1">Demostración identificada</option>
          </select>
        </label>
        <button>Actualizar informe</button>
      </form>
      <div className="toolbar">
        <a
          className="button secondary"
          href={`/api/informes?${query}&formato=csv`}
        >
          Exportar CSV
        </a>
        <a
          className="button secondary"
          href={`/api/informes?${query}&formato=xlsx`}
        >
          Exportar Excel
        </a>
        <a
          className="button secondary"
          href={`/api/informes?${query}&formato=pdf`}
        >
          Exportar PDF
        </a>
      </div>
      {!r.hasData && (
        <p className="alert">
          Todavía no hay información de operaciones suficiente para este
          período. Los saldos pendientes y el stock, si existen, se muestran por
          separado como situación actual.
        </p>
      )}
      <div className="stats">
        {[
          ["Ventas registradas", clp(r.totals.sales)],
          ["Gastos operativos", clp(r.totals.operatingExpenses)],
          ["Compras facturadas", clp(r.totals.purchases)],
          ["Pagos a proveedores", clp(r.totals.payments)],
          [
            "Margen bruto estimado",
            r.totals.grossMargin === null
              ? "Datos insuficientes"
              : clp(r.totals.grossMargin),
          ],
          [
            "Resultado operativo estimado",
            r.totals.estimatedOperatingResult === null
              ? "Datos insuficientes"
              : clp(r.totals.estimatedOperatingResult),
          ],
        ].map(([k, v]) => (
          <article key={k}>
            <small>{k}</small>
            <strong>{v}</strong>
          </article>
        ))}
      </div>
      <section className="card">
        <h2>Comparación con período anterior equivalente</h2>
        <p>
          {r.previous.from} a {r.previous.to}: {clp(r.previous.sales)} ·{" "}
          {r.previous.count} ventas. Variación:{" "}
          {r.previous.variation === null
            ? "Sin base comparable"
            : `${r.previous.variation}%`}
          .
        </p>
        <p>
          El margen usa costos guardados al vender; no se reconstruye con
          precios actuales. Si falta algún costo histórico se indica información
          insuficiente. Las ventas no equivalen a utilidad ni a abonos bancarios
          confirmados. No es un informe tributario.
        </p>
        <p>
          Ingresos por ventas registrados: {clp(r.totals.sales)}. Egresos
          registrados:{" "}
          {clp(
            r.totals.operatingExpenses +
              r.totals.payments +
              r.totals.withdrawals,
          )}{" "}
          (gastos + pagos + retiros, sin sumar nuevamente las compras).
        </p>
      </section>
      <ReportCharts report={r} />
      <section className="card table-wrap">
        <h2>Cuentas por pagar · situación actual</h2>
        <strong>{clp(r.totals.payable)}</strong>
        <table>
          <thead>
            <tr>
              <th>Proveedor</th>
              <th>Documento</th>
              <th>Saldo</th>
              <th>Vencimiento</th>
            </tr>
          </thead>
          <tbody>
            {r.payables.map((i, n) => (
              <tr key={n}>
                <td>{i.label}</td>
                <td>{i.reference}</td>
                <td>{clp(i.balance)}</td>
                <td>{i.dueDate || "Por confirmar"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <section className="card table-wrap">
        <h2>Stock actual y rotación del período</h2>
        <p>
          La rotación se estima como unidades vendidas / stock promedio entre
          apertura y cierre del período. Se necesita un movimiento de inventario
          anterior al período para disponer de una base; no se inventa stock
          histórico.
        </p>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Stock actual</th>
              <th>Vendido</th>
              <th>Inicio período</th>
              <th>Cierre período</th>
              <th>Rotación</th>
            </tr>
          </thead>
          <tbody>
            {r.stock.map((s) => (
              <tr key={s.id}>
                <td>{s.label}</td>
                <td>{s.stock}</td>
                <td>{s.sold}</td>
                <td>{s.opening ?? "Sin base"}</td>
                <td>{s.closing ?? "Sin base"}</td>
                <td>{s.rotation ?? "Insuficiente"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}

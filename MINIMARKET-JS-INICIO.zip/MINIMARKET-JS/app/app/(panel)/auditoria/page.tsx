import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import {
  validDate,
  dateOnly,
  addDays,
  chileDayStart,
  isoDay,
} from "@/lib/dates";
export default async function Audit({
  searchParams,
}: {
  searchParams: Promise<{ desde?: string; hasta?: string; pagina?: string }>;
}) {
  const user = await requireUser();
  if (!can(user.role, "audit:read"))
    return (
      <section className="card">
        <h1>Acceso restringido</h1>
        <p>La auditoría está reservada al administrador.</p>
      </section>
    );
  const p = await searchParams;
  const page = Math.min(100000, Math.max(1, Number(p.pagina) || 1));
  const from = validDate(p.desde || "") ? p.desde! : "";
  const until = validDate(p.hasta || "") ? p.hasta! : "";
  const where = {
    ...(from || until
      ? {
          createdAt: {
            ...(from ? { gte: chileDayStart(from) } : {}),
            ...(until
              ? { lt: chileDayStart(isoDay(addDays(dateOnly(until), 1))) }
              : {}),
          },
        }
      : {}),
  };
  const [logs, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      skip: (page - 1) * 50,
      take: 50,
    }),
    db.auditLog.count({ where }),
  ]);
  return (
    <>
      <p className="eyebrow">TRAZABILIDAD</p>
      <h1>Registro de auditoría</h1>
      <p>
        Actores, fechas y cambios de acceso, proveedores, contactos y agenda.
        Las contraseñas y tokens nunca se registran.
      </p>
      <form className="filters">
        <label>
          Desde (fecha Chile)
          <input name="desde" type="date" defaultValue={from} />
        </label>
        <label>
          Hasta (fecha Chile)
          <input name="hasta" type="date" defaultValue={until} />
        </label>
        <button className="secondary">Filtrar</button>
      </form>
      <section className="card table-wrap">
        <p>
          {total} eventos · página {page}
        </p>
        <table>
          <thead>
            <tr>
              <th>Fecha Chile</th>
              <th>Responsable</th>
              <th>Acción</th>
              <th>Registro</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id}>
                <td>
                  {l.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                </td>
                <td>{l.actorName}</td>
                <td>{l.action.replaceAll("_", " ").toLowerCase()}</td>
                <td>
                  {l.entity}
                  <small>{l.entityId}</small>
                </td>
                <td>
                  <details>
                    <summary>Ver cambios</summary>
                    <pre>{JSON.stringify(l.details, null, 2)}</pre>
                  </details>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!logs.length && <p>No hay eventos para estas fechas.</p>}
        <div className="toolbar">
          {page > 1 && (
            <Link href={`?pagina=${page - 1}&desde=${from}&hasta=${until}`}>
              ← Anterior
            </Link>
          )}
          {page * 50 < total && (
            <Link href={`?pagina=${page + 1}&desde=${from}&hasta=${until}`}>
              Siguiente →
            </Link>
          )}
        </div>
      </section>
    </>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { todayChile, validDate } from "@/lib/dates";
import { clp } from "@/lib/money";
import { STATUS_LABELS, ORDER_STATUSES } from "@/lib/order-status";
import { OrderEditor } from "@/components/order-editor";
import { ActionForm } from "@/components/action-form";
import { changeOrderStatus } from "@/app/phase1-actions";
import { receive } from "@/app/purchase-actions";
import { orderMessage } from "@/lib/whatsapp";
export default async function OrderDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{
    proveedor?: string;
    ciclo?: string;
    fecha?: string;
    copiar?: string;
  }>;
}) {
  const u = await requireUser();
  const { id } = await params;
  const p = await searchParams;
  const edit = can(u.role, "purchases:write");
  if (id === "nuevo") {
    const supplier = p.proveedor
      ? await db.supplier.findFirst({
          where: { id: p.proveedor, active: true },
          include: { cycles: { where: { active: true } } },
        })
      : null;
    if (!supplier)
      return (
        <section className="card">
          <h1>Nuevo pedido</h1>
          <p>
            Selecciona un proveedor activo en el{" "}
            <Link href="/proveedores">directorio</Link>.
          </p>
        </section>
      );
    if (!edit)
      return <p className="alert">No tienes permisos para crear pedidos.</p>;
    const source = p.copiar
      ? await db.supplierOrder.findFirst({
          where: {
            id: p.copiar,
            supplierId: supplier.id,
            structured: true,
            OR: [{ status: "CONFIRMADO" }, { status: "RECIBIDO" }],
          },
          include: { lines: true },
        })
      : null;
    const products = await db.product.findMany({
      where: supplier.demo ? {} : { demo: false },
      include: {
        movements: {
          where: { type: "RECEPCION", unitCost: { not: null } },
          orderBy: { createdAt: "desc" },
          take: 1,
        },
      },
      orderBy: { name: "asc" },
    });
    return (
      <>
        <Link href={`/proveedores/${supplier.id}`}>← {supplier.name}</Link>
        <h1>
          {source
            ? "Reutilizar pedido confirmado"
            : "Nuevo pedido por productos"}
        </h1>
        <section className="card">
          <OrderEditor
            supplierId={supplier.id}
            today={todayChile()}
            date={validDate(p.fecha || "") ? p.fecha : undefined}
            cycleId={p.ciclo}
            cycles={supplier.cycles}
            products={products.map((product) => ({
              ...product,
              cost: product.movements[0]?.unitCost ?? product.cost,
            }))}
            initial={source?.lines.map((l) => ({
              productId: l.productId,
              quantity: l.quantity,
              cost: l.receivedCost ?? l.estimatedCost,
            }))}
          />
        </section>
      </>
    );
  }
  const order = await db.supplierOrder.findUnique({
    where: { id },
    include: {
      supplier: {
        include: { contacts: true, cycles: { where: { active: true } } },
      },
      lines: true,
      invoice: true,
    },
  });
  if (!order) notFound();
  const history = await db.stockMovement.findMany({
    where: {
      productId: { in: order.lines.map((l) => l.productId) },
      unitCost: { not: null },
      type: "RECEPCION",
    },
    include: { product: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  const message = order.structured
    ? orderMessage(
        order.supplier.name,
        (order.orderDate ?? order.date).toLocaleDateString("es-CL", {
          timeZone: "UTC",
        }),
        order.lines,
      )
    : null;
  const destinations = [
    ...(order.supplier.whatsapp
      ? [{ name: order.supplier.name, whatsapp: order.supplier.whatsapp }]
      : []),
    ...order.supplier.contacts.filter(
      (c) => c.role === "VENDEDOR" && c.whatsapp,
    ),
  ];
  const editable =
    edit &&
    order.structured &&
    ["BORRADOR", "PENDIENTE", "PREPARADO"].includes(order.status);
  const products = editable
    ? await db.product.findMany({
        where: order.supplier.demo ? {} : { demo: false },
        orderBy: { name: "asc" },
      })
    : [];
  return (
    <>
      <Link href={`/proveedores/${order.supplierId}`}>
        ← {order.supplier.name}
      </Link>
      <div className="page-heading">
        <div>
          <h1>Detalle del pedido</h1>
          <p>
            {order.supplier.name} · {STATUS_LABELS[order.status]}
          </p>
        </div>
        <span className="badge">
          {order.structured ? "Por productos" : "Registro antiguo"}
        </span>
      </div>
      <section className="card">
        <h2>Productos y presupuesto</h2>
        <small>
          Pedido:{" "}
          {order.orderDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
            "Sin fecha"}{" "}
          · Entrega:{" "}
          {order.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
        </small>
        <p className="pre">{order.detail}</p>
        <strong>
          {clp(order.budget)} estimados
          {order.structured && !order.estimatedComplete
            ? " · Costos por confirmar"
            : ""}
        </strong>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Estimado unitario</th>
                <th>Costo recibido</th>
              </tr>
            </thead>
            <tbody>
              {order.lines.map((l) => (
                <tr key={l.id}>
                  <td>
                    {l.name}
                    <small>
                      {l.brand} · {l.presentation}
                    </small>
                  </td>
                  <td>{l.quantity}</td>
                  <td>
                    {l.estimatedCost === null
                      ? "Pendiente"
                      : clp(l.estimatedCost)}
                  </td>
                  <td>
                    {l.receivedCost === null
                      ? "No registrado"
                      : clp(l.receivedCost)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {edit && (
          <>
            <ActionForm action={changeOrderStatus}>
              <input type="hidden" name="id" value={order.id} />
              <input type="hidden" name="version" value={order.version} />
              <label>
                Estado del pedido
                <select name="status" defaultValue={order.status}>
                  {ORDER_STATUSES.filter((s) => s !== "RECIBIDO").map((s) => (
                    <option key={s} value={s}>
                      {STATUS_LABELS[s]}
                    </option>
                  ))}
                </select>
              </label>
              <button>Actualizar estado</button>
            </ActionForm>
            {["CONFIRMADO", "RECIBIDO"].includes(order.status) &&
              order.structured && (
                <Link
                  className="button"
                  href={`/pedidos/nuevo?proveedor=${order.supplierId}&copiar=${order.id}`}
                >
                  Copiar este pedido confirmado
                </Link>
              )}
          </>
        )}
      </section>
      {editable && (
        <section className="card">
          <h2>Editar productos y cantidades</h2>
          <OrderEditor
            supplierId={order.supplierId}
            products={products}
            cycles={order.supplier.cycles}
            cycleId={order.cycleId || ""}
            today={todayChile()}
            initial={order.lines.map((l) => ({
              productId: l.productId,
              quantity: l.quantity,
              cost: l.estimatedCost,
            }))}
            order={{
              id: order.id,
              version: order.version,
              orderDate:
                order.orderDate?.toISOString().slice(0, 10) || todayChile(),
              date: order.date.toISOString().slice(0, 10),
              status: order.status,
            }}
          />
        </section>
      )}
      {edit && order.structured && order.status !== "CANCELADO" && (
        <section className="card">
          <h2>Compartir por WhatsApp</h2>
          <p>
            Abrir WhatsApp no envía el mensaje ni cambia el estado del pedido.
            Revisa el contenido antes de enviarlo.
          </p>
          {message ? (
            <>
              <pre>{message}</pre>
              {destinations.length ? (
                destinations.map((d) => (
                  <a
                    key={d.name + d.whatsapp}
                    className="button"
                    target="_blank"
                    rel="noopener noreferrer"
                    href={`https://wa.me/${d.whatsapp}?text=${encodeURIComponent(message)}`}
                  >
                    Abrir WhatsApp · {d.name}
                  </a>
                ))
              ) : (
                <p className="alert">
                  No hay un WhatsApp confirmado. Edita la ficha o un contacto
                  vendedor cuando hayas verificado el número. Los teléfonos
                  importados no se asumen como WhatsApp.
                </p>
              )}
            </>
          ) : (
            <p className="alert">
              Revisa los nombres de productos: no se permiten referencias a
              precios o costos en el mensaje.
            </p>
          )}
        </section>
      )}
      {edit && order.structured && order.status === "CONFIRMADO" && (
        <section className="card">
          <h2>Registrar recepción</h2>
          <p>
            Confirma la recepción completa de las cantidades del pedido. El
            stock aumenta una sola vez. Puedes ingresar los costos efectivamente
            cobrados; dejarlos vacíos no inventa costos.
          </p>
          <ActionForm action={receive}>
            <input name="id" type="hidden" value={order.id} />
            <input name="version" type="hidden" value={order.version} />
            {order.lines.map((l) => (
              <label key={l.id}>
                Costo real unitario · {l.name}
                <input
                  name={`cost-${l.id}`}
                  type="number"
                  min={0}
                  max={1000000000}
                />
              </label>
            ))}
            <label className="check-line">
              <input type="checkbox" required />
              Confirmo que recibí todas las cantidades indicadas.
            </label>
            <button>Recibir y actualizar inventario</button>
          </ActionForm>
        </section>
      )}
      {order.status === "RECIBIDO" && (
        <section className="card">
          <h2>Recepción registrada</h2>
          <p>
            {order.receivedAt?.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            }) || "Recepción histórica sin detalle de inventario."}
          </p>
          {can(u.role, "finance:write") && (
            <Link
              href={
                order.invoice
                  ? "/finanzas"
                  : `/finanzas?proveedor=${order.supplierId}&pedido=${order.id}`
              }
            >
              {order.invoice
                ? "Consultar factura y pagos"
                : "Registrar factura de esta recepción →"}
            </Link>
          )}
        </section>
      )}
      <section className="card table-wrap">
        <h2>Costos históricos de recepciones</h2>
        {!history.length ? (
          <p>No hay costos reales registrados para estos productos.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Fecha Chile</th>
                <th>Costo unitario</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{h.product.name}</td>
                  <td>
                    {h.createdAt.toLocaleDateString("es-CL", {
                      timeZone: "America/Santiago",
                    })}
                  </td>
                  <td>{clp(h.unitCost!)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}

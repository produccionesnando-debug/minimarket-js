import Link from "next/link";
import { HabitualManager } from "@/components/habitual-manager";
import { readHabitualItems } from "@/lib/habitual-lists";
import { randomUUID } from "node:crypto";
import { SupplierPicker } from "@/components/supplier-picker";
import { OrderShare } from "@/components/order-share";
import { homeSummary } from "@/lib/reports";
import { inventoryInsights } from "@/lib/inventory-insights";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { todayChile, validDate } from "@/lib/dates";
import { clp } from "@/lib/money";
import { STATUS_LABELS, ORDER_STATUSES } from "@/lib/order-status";
import { OrderEditor } from "@/components/order-editor";
import { ActionForm } from "@/components/action-form";
import { changeOrderStatus } from "@/app/phase1-actions";
import { receive } from "@/app/purchase-actions";
import { orderMessage } from "@/lib/whatsapp";
export default async function OrderDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{
    proveedor?: string;
    ciclo?: string;
    fecha?: string;
    copiar?: string;
    producto?: string;
    ultimo?: string;
  }>;
}) {
  const u = await requireUser();
  const { id } = await params;
  const p = await searchParams;
  const edit = can(u.role, "purchases:write");
  if (id === "nuevo") {
    const supplier = p.proveedor
      ? await db.supplier.findFirst({
          where: { id: p.proveedor, active: true },
          include: { cycles: { where: { active: true } } },
        })
      : null;
    if (!supplier) {
      if (!edit) return <h1>Acceso restringido</h1>;
      const suppliers = await db.supplier.findMany({
        where: { active: true, demo: false },
        orderBy: { name: "asc" },
      });
      return (
        <section className="card">
          <h1>Nuevo pedido</h1>
          <p>Elige el proveedor para preparar los productos y cantidades.</p>
          <SupplierPicker suppliers={suppliers} />
          {!suppliers.length && (
            <p>
              No hay proveedores activos.{" "}
              <Link href="/proveedores/nuevo">Agregar proveedor</Link>
            </p>
          )}
        </section>
      );
    }
    if (!edit)
      return <p className="alert">No tienes permisos para crear pedidos.</p>;
    const source = await db.supplierOrder.findFirst({
      where: {
        ...(p.copiar ? { id: p.copiar } : {}),
        supplierId: supplier.id,
        structured: true,
        OR: [{ status: "CONFIRMADO" }, { status: "RECIBIDO" }],
      },
      include: { lines: true },
      orderBy: [
        { confirmedAt: { sort: "desc", nulls: "last" } },
        { date: "desc" },
      ],
    });
    const products = await db.product.findMany({
      where: supplier.demo ? {} : { demo: false },
      include: {
        movements: {
          where: { type: "RECEPCION", unitCost: { not: null } },
          orderBy: { createdAt: "desc" },
          take: 1,
        },
      },
      orderBy: { name: "asc" },
    });
    const habitual = await db.supplierHabitualList.findUnique({
      where: { supplierId: supplier.id },
    });
    const habitualItems = readHabitualItems(habitual?.items);
    const activeHabitual = habitualItems.filter((i) => i.active);
    const supplierOptions = await db.supplier.findMany({
      where: { active: true, ...(supplier.demo ? {} : { demo: false }) },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });
    const insights = await inventoryInsights(u, { supplierId: supplier.id });
    const associated = new Set(insights.rows.map((r) => r.product.id));
    const funds = can(u.role, "finance:write") ? await homeSummary(u) : null;
    return (
      <>
        <Link href={`/proveedores/${supplier.id}`}>← {supplier.name}</Link>
        <SupplierPicker
          key={supplier.id}
          suppliers={supplierOptions}
          selectedId={supplier.id}
        />
        <h1>
          {habitual && !p.copiar
            ? "Nuevo pedido · lista habitual"
            : source
              ? "Reutilizar pedido confirmado"
              : "Nuevo pedido por productos"}
        </h1>
        <HabitualManager
          key={supplier.id}
          supplierId={supplier.id}
          version={habitual?.version || 0}
          items={habitualItems}
          products={products}
        />
        <section className="card">
          <p>
            Las cantidades anteriores son una plantilla revisable. Las
            sugerencias consideran stock conocido, mínimos, ventas y compras
            pendientes; no reservan ni compran automáticamente.
          </p>
          <OrderEditor
            key={supplier.id}
            habitualVersion={habitual?.version || 0}
            habitualExists={habitualItems.length > 0}
            creationKeyBase={randomUUID()}
            availableBudget={funds?.available ?? null}
            actorId={u.id}
            supplierId={supplier.id}
            today={todayChile()}
            date={validDate(p.fecha || "") ? p.fecha : undefined}
            cycleId={p.ciclo}
            cycles={supplier.cycles}
            products={products.map((product) => ({
              ...product,
              cost:
                product.movements[0]?.unitCost ??
                (product.costKnown ? product.cost : null),
              stock: product.stock,
              stockKnown: product.stockKnown,
              minimum: product.minimum,
              name:
                activeHabitual.find((i) => i.productId === product.id)?.name ||
                product.name,
              presentation:
                activeHabitual.find((i) => i.productId === product.id)
                  ?.presentation ?? product.presentation,
              purchaseUnit:
                activeHabitual.find((i) => i.productId === product.id)?.unit ||
                "unidad",
              purchaseCode:
                activeHabitual.find((i) => i.productId === product.id)?.code ||
                "",
              previousQuantity:
                source?.lines.find((l) => l.productId === product.id)
                  ?.quantity ?? null,
              suggestedQuantity:
                insights.rows.find((r) => r.product.id === product.id)
                  ?.recommend ?? null,
            }))}
            notes={source?.notes || ""}
            initial={
              habitual && !p.copiar
                ? activeHabitual
                    .filter((i) => products.some((p) => p.id === i.productId))
                    .map((i) => ({
                      productId: i.productId,
                      quantity: i.quantity,
                      cost: products.find((p) => p.id === i.productId)
                        ?.costKnown
                        ? products.find((p) => p.id === i.productId)!.cost
                        : null,
                      name: i.name,
                      presentation: i.presentation,
                      purchaseUnit: i.unit,
                      purchaseCode: i.code,
                    }))
                : [
                    ...(source?.lines.map((l) => ({
                      productId: l.productId,
                      quantity: l.quantity,
                      cost: l.receivedCost ?? l.estimatedCost,
                      name: l.name,
                      presentation: l.presentation,
                      purchaseUnit: l.purchaseUnit,
                      purchaseCode: l.purchaseCode,
                    })) || []),
                    ...products
                      .filter(
                        (product) =>
                          (product.id === p.producto ||
                            associated.has(product.id)) &&
                          !source?.lines.some(
                            (l) => l.productId === product.id,
                          ) &&
                          product.unitType !== "PESO",
                      )
                      .map((product) => ({
                        productId: product.id,
                        quantity: Math.ceil(
                          insights.rows.find((r) => r.product.id === product.id)
                            ?.recommend || 0,
                        ),
                        cost:
                          product.movements[0]?.unitCost ??
                          (product.costKnown ? product.cost : null),
                      })),
                  ]
            }
          />
        </section>
      </>
    );
  }
  const order = await db.supplierOrder.findUnique({
    where: { id },
    include: {
      supplier: {
        include: { contacts: true, cycles: { where: { active: true } } },
      },
      lines: true,
      invoice: true,
    },
  });
  if (!order) notFound();
  const orderHabitual = await db.supplierHabitualList.findUnique({
    where: { supplierId: order.supplierId },
  });
  const history = await db.stockMovement.findMany({
    where: {
      productId: { in: order.lines.map((l) => l.productId) },
      unitCost: { not: null },
      type: "RECEPCION",
    },
    include: { product: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  const message = order.structured
    ? orderMessage(
        order.supplier.name,
        (order.orderDate ?? order.date).toLocaleDateString("es-CL", {
          timeZone: "UTC",
        }),
        order.lines,
        order.notes,
      )
    : null;
  const destinations = [
    ...(order.supplier.whatsapp
      ? [
          {
            id: "supplier",
            name: order.supplier.name,
            whatsapp: order.supplier.whatsapp,
          },
        ]
      : []),
    ...order.supplier.contacts.filter(
      (c) => c.role === "VENDEDOR" && c.whatsapp,
    ),
  ];
  const editable =
    edit &&
    order.structured &&
    ["BORRADOR", "PENDIENTE", "PREPARADO"].includes(order.status);
  const products = editable
    ? await db.product.findMany({
        where: order.supplier.demo ? {} : { demo: false },
        orderBy: { name: "asc" },
      })
    : [];
  return (
    <>
      <Link href={`/proveedores/${order.supplierId}`}>
        ← {order.supplier.name}
      </Link>
      <div className="page-heading">
        <div>
          <h1>Detalle del pedido</h1>
          <p>
            {order.supplier.name} · {STATUS_LABELS[order.status]}
          </p>
        </div>
        <span className="badge">
          {order.structured ? "Por productos" : "Registro antiguo"}
        </span>
      </div>
      <section className="card">
        <h2>Productos y presupuesto</h2>
        <small>
          Pedido:{" "}
          {order.orderDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
            "Sin fecha"}{" "}
          · Entrega:{" "}
          {order.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
        </small>
        <p className="pre">{order.detail}</p>
        <strong>
          {clp(order.budget)} estimados
          {order.structured && !order.estimatedComplete
            ? " · Costos por confirmar"
            : ""}
        </strong>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Estimado unitario</th>
                <th>Costo recibido</th>
              </tr>
            </thead>
            <tbody>
              {order.lines.map((l) => (
                <tr key={l.id}>
                  <td>
                    {l.name}
                    <small>
                      {l.brand} · {l.presentation}
                    </small>
                  </td>
                  <td>
                    {l.quantity} {l.purchaseUnit}
                  </td>
                  <td>
                    {l.estimatedCost === null
                      ? "Pendiente"
                      : clp(l.estimatedCost)}
                  </td>
                  <td>
                    {l.receivedCost === null
                      ? "No registrado"
                      : clp(l.receivedCost)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {edit && (
          <>
            <ActionForm action={changeOrderStatus}>
              <input type="hidden" name="id" value={order.id} />
              <input type="hidden" name="version" value={order.version} />
              <label>
                Estado del pedido
                <select name="status" defaultValue={order.status}>
                  {ORDER_STATUSES.filter((s) => s !== "RECIBIDO").map((s) => (
                    <option key={s} value={s}>
                      {STATUS_LABELS[s]}
                    </option>
                  ))}
                </select>
              </label>
              <button>Actualizar estado</button>
            </ActionForm>
            {["CONFIRMADO", "RECIBIDO"].includes(order.status) &&
              order.structured && (
                <Link
                  className="button"
                  href={`/pedidos/nuevo?proveedor=${order.supplierId}&copiar=${order.id}`}
                >
                  Copiar este pedido confirmado
                </Link>
              )}
          </>
        )}
      </section>
      {editable && (
        <section className="card">
          <h2>Editar productos y cantidades</h2>
          <OrderEditor
            creationKeyBase={randomUUID()}
            habitualVersion={orderHabitual?.version || 0}
            habitualExists={readHabitualItems(orderHabitual?.items).length > 0}
            actorId={u.id}
            supplierId={order.supplierId}
            products={products.map((p) => ({
              ...p,
              name:
                order.lines.find((l) => l.productId === p.id)?.name || p.name,
              presentation:
                order.lines.find((l) => l.productId === p.id)?.presentation ??
                p.presentation,
              purchaseUnit:
                order.lines.find((l) => l.productId === p.id)?.purchaseUnit ||
                "unidad",
              purchaseCode:
                order.lines.find((l) => l.productId === p.id)?.purchaseCode ||
                "",
              cost: p.costKnown ? p.cost : null,
            }))}
            cycles={order.supplier.cycles}
            cycleId={order.cycleId || ""}
            today={todayChile()}
            initial={order.lines.map((l) => ({
              productId: l.productId,
              quantity: l.quantity,
              cost: l.estimatedCost,
              name: l.name,
              presentation: l.presentation,
              purchaseUnit: l.purchaseUnit,
              purchaseCode: l.purchaseCode,
            }))}
            order={{
              id: order.id,
              version: order.version,
              orderDate:
                order.orderDate?.toISOString().slice(0, 10) || todayChile(),
              date: order.date.toISOString().slice(0, 10),
              status: order.status,
              notes: order.notes,
            }}
          />
        </section>
      )}
      {edit &&
        order.structured &&
        !["CANCELADO", "RECIBIDO"].includes(order.status) &&
        message && (
          <OrderShare
            id={order.id}
            version={order.version}
            status={order.status}
            message={message}
            contacts={destinations.map((d) => ({ id: d.id, name: d.name }))}
          />
        )}
      {!message && order.structured && (
        <p className="alert">
          Revisa nombres y observaciones: no se pueden compartir precios ni
          costos por WhatsApp.
        </p>
      )}
      <section className="card">
        <h2>Observaciones del pedido</h2>
        <p>{order.notes || "Sin observaciones"}</p>
      </section>
      <OrderHistory id={order.id} />
      {edit && order.structured && order.status === "CONFIRMADO" && (
        <section className="card">
          <h2>Registrar recepción</h2>
          <p>
            Confirma la recepción completa de las cantidades del pedido. El
            stock aumenta una sola vez. Puedes ingresar los costos efectivamente
            cobrados; dejarlos vacíos no inventa costos.
          </p>
          <ActionForm action={receive}>
            <input name="id" type="hidden" value={order.id} />
            <input name="version" type="hidden" value={order.version} />
            {order.lines.map((l) => (
              <label key={l.id}>
                Costo real unitario · {l.name}
                <input
                  name={`cost-${l.id}`}
                  type="number"
                  min={0}
                  max={1000000000}
                />
              </label>
            ))}
            <label className="check-line">
              <input type="checkbox" required />
              Confirmo que recibí todas las cantidades indicadas.
            </label>
            <button>Recibir y actualizar inventario</button>
          </ActionForm>
        </section>
      )}
      {order.status === "RECIBIDO" && (
        <section className="card">
          <h2>Recepción registrada</h2>
          <p>
            {order.receivedAt?.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            }) || "Recepción histórica sin detalle de inventario."}
          </p>
          {can(u.role, "finance:write") && (
            <Link
              href={
                order.invoice
                  ? "/finanzas"
                  : `/finanzas?proveedor=${order.supplierId}&pedido=${order.id}`
              }
            >
              {order.invoice
                ? "Consultar factura y pagos"
                : "Registrar factura de esta recepción →"}
            </Link>
          )}
        </section>
      )}
      <section className="card table-wrap">
        <h2>Costos históricos de recepciones</h2>
        {!history.length ? (
          <p>No hay costos reales registrados para estos productos.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Fecha Chile</th>
                <th>Costo unitario</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{h.product.name}</td>
                  <td>
                    {h.createdAt.toLocaleDateString("es-CL", {
                      timeZone: "America/Santiago",
                    })}
                  </td>
                  <td>{clp(h.unitCost!)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}

async function OrderHistory({ id }: { id: string }) {
  const history = await db.auditLog.findMany({
    where: { entity: "Pedido", entityId: id },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <section className="card">
      <h2>Historial de modificaciones</h2>
      {history.map((h) => (
        <details key={h.id}>
          <summary>
            {h.createdAt.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            })}{" "}
            · {h.actorName} · {h.action.replaceAll("_", " ")}
          </summary>
          <pre>{JSON.stringify(h.details, null, 2)}</pre>
        </details>
      ))}
    </section>
  );
}

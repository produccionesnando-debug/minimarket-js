import { StatusBadge } from "@/components/ui";
import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import {
  STATUS_LABELS,
  ORDER_STATUSES,
  OPEN_STATUSES,
} from "@/lib/order-status";
import { clp } from "@/lib/money";
import { todayChile, validDate, dateOnly, isoDay } from "@/lib/dates";
import { getCalendarData } from "@/lib/calendar";
export default async function Orders({
  searchParams,
}: {
  searchParams: Promise<{
    proveedor?: string;
    estado?: string;
    fecha?: string;
  }>;
}) {
  const actor = await requireUser(),
    p = await searchParams,
    day = validDate(p.fecha || "") ? p.fecha! : todayChile(),
    calendar = await getCalendarData(actor, {
      vista: "dia",
      fecha: day,
      proveedor: p.proveedor,
    });
  const [orders, suppliers] = await Promise.all([
    db.supplierOrder.findMany({
      where: {
        supplier: { demo: false },
        ...(p.proveedor ? { supplierId: p.proveedor } : {}),
        ...(ORDER_STATUSES.includes(p.estado as never)
          ? { status: p.estado }
          : {}),
      },
      include: { supplier: true, lines: true },
      orderBy: { orderDate: "desc" },
      take: 100,
    }),
    db.supplier.findMany({
      where: {
        demo: false,
        active: true,
        ...(p.proveedor ? { id: p.proveedor } : {}),
      },
      orderBy: { name: "asc" },
    }),
  ]);
  const dayOrders = orders.filter((o) => isoDay(o.orderDate || o.date) === day),
    deliveries = orders.filter(
      (o) => isoDay(o.date) === day && o.status !== "CANCELADO",
    ),
    pending = orders.filter(
      (o) =>
        OPEN_STATUSES.includes(o.status as never) &&
        isoDay(o.orderDate || o.date) <= day,
    ),
    events = calendar.events.filter((e) => e.date === day);
  const cards = suppliers
    .map((s) => ({
      supplier: s,
      orders: dayOrders.filter((o) => o.supplierId === s.id),
      events: events.filter(
        (e) =>
          e.href.includes(s.id) ||
          orders.some(
            (o) => o.supplierId === s.id && e.href === "/pedidos/" + o.id,
          ),
      ),
    }))
    .filter((c) => c.orders.length || c.events.length || p.proveedor);
  const editable = can(actor.role, "purchases:write");
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">COMPRAS · FECHA Y PROVEEDOR</p>
          <h1>Pedidos a proveedores</h1>
        </div>
        {editable && (
          <Link
            className="button mobile-create-order"
            href={"/pedidos/nuevo?fecha=" + day}
          >
            + Crear pedido
          </Link>
        )}
      </div>
      <form
        className="filters"
        aria-label="Filtrar pedidos por día y proveedor"
      >
        <label>
          Día del pedido
          <input name="fecha" type="date" defaultValue={day} />
        </label>
        <label>
          Proveedor
          <select
            aria-label="Proveedor"
            name="proveedor"
            defaultValue={p.proveedor || ""}
          >
            <option value="">Todos</option>
            {calendar.suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Estado
          <select name="estado" defaultValue={p.estado || ""}>
            <option value="">Todos</option>
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>
                {STATUS_LABELS[s]}
              </option>
            ))}
          </select>
        </label>
        <button>Filtrar pedidos</button>
      </form>
      <section className="mobile-orders-screen">
        <div className="mobile-order-summary">
          <article>
            <small>Pedidos del día</small>
            <strong>{dayOrders.length}</strong>
          </article>
          <article>
            <small>Entregas del día</small>
            <strong>{deliveries.length}</strong>
          </article>
          <article>
            <small>Pagos próximos</small>
            <strong>{events.filter((e) => e.kind === "pago").length}</strong>
          </article>
          <article>
            <small>Pedidos pendientes</small>
            <strong>{pending.length}</strong>
          </article>
        </div>
        <h2>
          {dateOnly(day).toLocaleDateString("es-CL", {
            timeZone: "UTC",
            weekday: "long",
            day: "numeric",
            month: "long",
          })}
        </h2>
        {cards.map((c) => (
          <details key={c.supplier.id} className="card mobile-supplier-card">
            <summary>
              <strong>{c.supplier.name}</strong>
              <span className="badge">
                {c.orders.length
                  ? STATUS_LABELS[c.orders[0].status]
                  : "Por preparar"}
              </span>
            </summary>
            {c.events.map((e) => (
              <p key={e.id}>{e.label}</p>
            ))}
            {c.orders.map((o) => (
              <div key={o.id}>
                <p>
                  Entrega estimada:{" "}
                  {o.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
                </p>
                {o.lines.map((l) => (
                  <p key={l.id}>
                    {l.name} · {l.quantity}
                  </p>
                ))}
                <p>
                  Total estimado interno {clp(o.budget)}
                  {!o.estimatedComplete ? " + costos pendientes" : ""}
                </p>
                <Link className="button secondary" href={"/pedidos/" + o.id}>
                  Abrir y editar pedido
                </Link>
              </div>
            ))}
            {!c.orders.length && (
              <>
                <p>
                  Recordatorio del calendario. Todavía no hay un pedido guardado
                  para esta fecha.
                </p>
                {editable && (
                  <Link
                    className="button"
                    href={`/pedidos/nuevo?proveedor=${c.supplier.id}&fecha=${day}&ultimo=1`}
                  >
                    Preparar pedido
                  </Link>
                )}
              </>
            )}
          </details>
        ))}
        {!cards.length && (
          <section className="card">
            <p>
              No hay pedidos ni recordatorios para esta fecha. Cambia el día o
              elige un proveedor para preparar uno.
            </p>
          </section>
        )}
        <details className="card">
          <summary>Pendientes y pagos próximos</summary>
          {pending.map((o) => (
            <p key={o.id}>
              <Link href={"/pedidos/" + o.id}>
                {o.supplier.name} · {STATUS_LABELS[o.status]}
              </Link>
            </p>
          ))}
          {events
            .filter((e) => e.kind === "pago")
            .map((e) => (
              <p key={e.id}>
                <Link href={e.href}>{e.label}</Link>
              </p>
            ))}
        </details>
      </section>
      <section className="card table-wrap desktop-order-history">
        <h2>Historial de pedidos</h2>
        <p>Últimos 100 pedidos; la fecha permite revisar un día concreto.</p>
        <table>
          <thead>
            <tr>
              <th>Proveedor</th>
              <th>Entrega</th>
              <th>Estado</th>
              <th>Estimado</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {(p.fecha ? dayOrders : orders).map((o) => (
              <tr key={o.id}>
                <td>{o.supplier.name}</td>
                <td>
                  {o.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
                </td>
                <td>
                  <StatusBadge status={o.status} />
                </td>
                <td>
                  {clp(o.budget)}
                  {o.structured && !o.estimatedComplete ? " + pendientes" : ""}
                </td>
                <td>
                  <Link href={"/pedidos/" + o.id}>Abrir pedido →</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!orders.length && <p>Aún no hay pedidos.</p>}
      </section>
    </>
  );
}

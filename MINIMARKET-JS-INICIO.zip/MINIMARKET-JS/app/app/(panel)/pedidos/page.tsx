import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { STATUS_LABELS, ORDER_STATUSES } from "@/lib/order-status";
import { clp } from "@/lib/money";
export default async function Orders({
  searchParams,
}: {
  searchParams: Promise<{ proveedor?: string; estado?: string }>;
}) {
  await requireUser();
  const p = await searchParams;
  const [orders, suppliers] = await Promise.all([
    db.supplierOrder.findMany({
      where: {
        supplier: { demo: false },
        ...(p.proveedor ? { supplierId: p.proveedor } : {}),
        ...(ORDER_STATUSES.includes(p.estado as (typeof ORDER_STATUSES)[number])
          ? { status: p.estado }
          : {}),
      },
      include: { supplier: true },
      orderBy: { orderDate: "desc" },
      take: 100,
    }),
    db.supplier.findMany({ where: { demo: false }, orderBy: { name: "asc" } }),
  ]);
  return (
    <>
      <h1>Pedidos a proveedores</h1>
      <p>
        Últimos 100 pedidos. Abre la ficha para consultar líneas, copiar,
        compartir o recibir.
      </p>
      <form className="filters">
        <label>
          Proveedor
          <select name="proveedor" defaultValue={p.proveedor}>
            <option value="">Todos</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Estado
          <select name="estado" defaultValue={p.estado}>
            <option value="">Todos</option>
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>
                {STATUS_LABELS[s]}
              </option>
            ))}
          </select>
        </label>
        <button>Filtrar</button>
      </form>
      <section className="card table-wrap">
        <table>
          <thead>
            <tr>
              <th>Proveedor</th>
              <th>Entrega</th>
              <th>Estado</th>
              <th>Estimado</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{o.supplier.name}</td>
                <td>
                  {o.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
                </td>
                <td>{STATUS_LABELS[o.status]}</td>
                <td>
                  {clp(o.budget)}
                  {o.structured && !o.estimatedComplete ? " + pendientes" : ""}
                </td>
                <td>
                  <Link href={`/pedidos/${o.id}`}>Abrir pedido →</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!orders.length && <p>Aún no hay pedidos.</p>}
      </section>
    </>
  );
}

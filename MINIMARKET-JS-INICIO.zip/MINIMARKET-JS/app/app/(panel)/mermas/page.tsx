import { kilograms, itemCost, weightBased } from "@/lib/weight";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { clp } from "@/lib/money";
import { todayChile } from "@/lib/dates";
import { ActionForm } from "@/components/action-form";
import { ReceiptInput } from "@/components/receipt-input";
import { lossAction, lossReasonAction } from "@/app/catalog-actions";
export default async function Losses({
  searchParams,
}: {
  searchParams: Promise<{ demo?: string }>;
}) {
  const actor = await requireUser();
  const demo = (await searchParams).demo === "1";
  const all = can(actor.role, "expenses:readAll");
  const [products, reasons, losses, users] = await Promise.all([
    db.product.findMany({ where: { demo }, orderBy: { name: "asc" } }),
    db.lossReason.findMany({ orderBy: { name: "asc" } }),
    db.stockLoss.findMany({
      where: { demo, ...(all ? {} : { responsibleId: actor.id }) },
      include: { product: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.user.findMany({
      where: {
        active: true,
        ...(!can(actor.role, "inventory:adjust") ? { id: actor.id } : {}),
      },
      select: { id: true, name: true },
    }),
  ]);
  return (
    <>
      <p className="eyebrow">PÉRDIDAS Y TRAZABILIDAD</p>
      <h1>Mermas</h1>
      <p>
        Descuentan unidades sin crear ventas ni movimientos de dinero. Los
        productos devueltos no aptos se identifican para evitar descontar stock
        dos veces.
      </p>
      <form className="filters">
        <label>
          Modo del catálogo
          <select name="demo" defaultValue={demo ? "1" : "0"}>
            <option value="0">
              {process.env.DEMO_INSTANCE === "1"
                ? "Esta demostración"
                : "Negocio real"}
            </option>
            <option value="1">Demostración separada</option>
          </select>
        </label>
        <button>Ver mermas</button>
      </form>
      <section className="card">
        <h2>Registrar merma</h2>
        <ActionForm action={lossAction} label="Registrar merma">
          <input type="hidden" name="requestKey" value={randomUUID()} />
          <div className="form-grid">
            <label>
              Producto de la merma
              <select name="productId" required>
                <option value="">Seleccionar producto</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} · stock{" "}
                    {p.stockKnown
                      ? weightBased(p)
                        ? kilograms(p.stockGrams)
                        : p.stock
                      : "sin registrar"}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Cantidad perdida
              <input name="quantity" type="number" min={1} required />
            </label>
            <label>
              Fecha de la merma
              <input
                name="date"
                type="date"
                defaultValue={todayChile()}
                max={todayChile()}
                required
              />
            </label>
            <label>
              Motivo de la merma
              <select name="reasonId" required>
                {reasons
                  .filter(
                    (r) =>
                      r.active &&
                      (can(actor.role, "inventory:adjust") ||
                        r.name !== "Diferencia de inventario"),
                  )
                  .map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
              </select>
            </label>
            <label>
              Trabajador responsable
              <select name="responsibleId" defaultValue={actor.id}>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <label>
            Observaciones de la merma
            <textarea name="notes" maxLength={1000} />
          </label>
          <label>
            Fotografía opcional
            <input
              type="file"
              name="files"
              accept="image/jpeg,image/png,image/webp"
              capture="environment"
            />
          </label>
          <label className="check-line">
            <input type="checkbox" required />
            Confirmo la pérdida y el descuento de inventario
          </label>
          <button>Guardar merma y descontar stock</button>
          <p className="help">
            Se utiliza el costo vigente del producto, guardado en el historial.
            No se registra una salida de caja.
          </p>
        </ActionForm>
      </section>
      <section className="card table-wrap">
        <h2>Historial de mermas</h2>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Fecha</th>
              <th>Unidades</th>
              <th>Motivo</th>
              <th>Costo</th>
              <th>Stock</th>
              <th>Respaldo</th>
            </tr>
          </thead>
          <tbody>
            {losses.map((l) => (
              <tr key={l.id}>
                <td>
                  {l.product.name}
                  <small>{l.notes}</small>
                </td>
                <td>
                  {l.occurredAt.toLocaleDateString("es-CL", {
                    timeZone: "UTC",
                  })}
                </td>
                <td>
                  {l.weightGrams ? kilograms(l.weightGrams) : l.quantity}
                  {l.estimatedWeightGrams ? (
                    <small>{kilograms(l.estimatedWeightGrams)} estimados</small>
                  ) : null}
                </td>
                <td>{l.reason}</td>
                <td>
                  {l.unitCost === null
                    ? "Costo insuficiente"
                    : clp(itemCost(l))}
                </td>
                <td>
                  {l.deducted ? "Descontado" : "Devolución · no vuelve a stock"}
                </td>
                <td>
                  {l.photo ? (
                    <a href={"/api/mermas/" + l.id + "/foto"} target="_blank">
                      Ver fotografía privada
                    </a>
                  ) : (
                    "Sin fotografía"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!losses.length && <p>No hay mermas registradas en esta consulta.</p>}
      </section>
      {actor.role === "ADMIN" && (
        <section className="card">
          <h2>Motivos configurables</h2>
          <ActionForm action={lossReasonAction}>
            <label>
              Nuevo motivo
              <input name="name" required minLength={2} />
            </label>
            <button>Agregar motivo</button>
          </ActionForm>
          {reasons.map((r) => (
            <details key={r.id} className="order">
              <summary>
                {r.name} · {r.active ? "Activo" : "Inactivo"}
              </summary>
              <ActionForm action={lossReasonAction}>
                <input type="hidden" name="id" value={r.id} />
                <label>
                  Nombre del motivo
                  <input name="name" defaultValue={r.name} required />
                </label>
                <label>
                  Estado
                  <select name="active" defaultValue={String(r.active)}>
                    <option value="true">Activo</option>
                    <option value="false">Inactivo</option>
                  </select>
                </label>
                <button>Guardar motivo</button>
              </ActionForm>
            </details>
          ))}
        </section>
      )}
    </>
  );
}

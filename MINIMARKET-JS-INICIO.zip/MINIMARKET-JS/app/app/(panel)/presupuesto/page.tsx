import Link from "next/link";
import { Wallet, Landmark, Receipt, ShieldCheck } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { homeSummary } from "@/lib/reports";
import { clp } from "@/lib/money";
import { Metric, Card } from "@/components/ui";
export default async function Budget() {
  const u = await requireUser();
  if (!can(u.role, "finance:write")) return <h1>Acceso restringido</h1>;
  const s = await homeSummary(u);
  return (
    <>
      <p className="eyebrow">PLANIFICACIÓN DE COMPRAS</p>
      <h1>Presupuesto disponible</h1>
      <p>Estimación basada en los fondos y obligaciones que registraste.</p>
      <div className="metric-grid">
        <Metric
          label="Disponible para compras"
          value={s.available === null ? "Por configurar" : clp(s.available)}
          hint="Fondos menos deuda y reservas"
          icon={Wallet}
          tone="teal"
        />
        <Metric
          label="Efectivo en cajas abiertas"
          value={clp(s.cash)}
          hint="Efectivo esperado registrado"
          icon={Landmark}
        />
        <Metric
          label="Cuentas por pagar"
          value={clp(s.payable || 0)}
          hint="Saldo actual de proveedores"
          icon={Receipt}
          tone="purple"
        />
        <Metric
          label="Reservas activas"
          value={clp(s.reserves)}
          hint="Obligaciones reservadas manualmente"
          icon={ShieldCheck}
          tone="orange"
        />
      </div>
      <Card title="Base del cálculo">
        <p>
          Se consideran cajas reales abiertas, saldos bancarios declarados,
          deuda a proveedores y reservas activas. Para calcular el disponible,
          deben estar confirmados los fondos y reservas, con saldos conocidos y
          pagos no efectivos asignados a sus cuentas.
        </p>
        <p>
          Las ventas con tarjeta o transferencia no se consideran
          automáticamente dinero abonado al banco. Las reservas no son gastos
          pagados. Este cálculo no es utilidad ni conciliación bancaria.
        </p>
        {u.role === "ADMIN" && (
          <Link className="button" href="/configuracion">
            Configurar cuentas y reservas
          </Link>
        )}
        <Link className="button secondary" href="/finanzas">
          Revisar facturas y pagos
        </Link>
      </Card>
    </>
  );
}

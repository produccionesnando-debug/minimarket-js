import Link from "next/link";
import { Package, Truck } from "lucide-react";
import { Card, EmptyState } from "@/components/ui";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { ActionForm } from "@/components/action-form";
import { channelDemo } from "@/app/operations-actions";
import { clp } from "@/lib/money";
export default async function Channel() {
  const user = await requireUser();
  const orders = await db.channelOrder.findMany({
    where: { demo: true },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  const stock = await db.product.findMany({
    where: { demo: false },
    select: { id: true, name: true, stock: true, minimum: true },
    orderBy: { stock: "asc" },
    take: 20,
  });
  return (
    <>
      <p className="eyebrow">INTEGRACIÓN FUTURA</p>
      <div className="delivery-title">
        <span className="delivery-logo">P</span>
        <h1>PedidosYa</h1>
        <span className="demo-pill">Modo demostración</span>
      </div>
      <p className="alert">
        MODO DEMOSTRACIÓN · Sin conexión real con PedidosYa. No recibe pedidos
        externos, no realiza cobros y no modifica inventario del negocio.
      </p>
      {can(user.role, "shifts:manage") && (
        <ActionForm action={channelDemo}>
          <button>Crear pedido ficticio de prueba</button>
        </ActionForm>
      )}
      {orders.map((o) => (
        <section className="card" key={o.id}>
          <h2>{o.customerLabel}</h2>
          <span className="badge">{o.status} · DEMO</span>
          <p>Total ficticio {clp(o.total)}</p>
          <ul>
            {(o.lines as { name: string; quantity: number }[]).map((l, i) => (
              <li key={i}>
                {l.quantity} × {l.name}
              </li>
            ))}
          </ul>
          {can(user.role, "shifts:manage") &&
            !["ENTREGADO", "CANCELADO", "RECHAZADO"].includes(o.status) && (
              <ActionForm action={channelDemo}>
                <input name="id" type="hidden" value={o.id} />
                <input name="version" type="hidden" value={o.version} />
                <label>
                  Siguiente estado
                  <select name="status">
                    {(
                      {
                        RECIBIDO: ["ACEPTADO", "RECHAZADO", "CANCELADO"],
                        ACEPTADO: ["PREPARANDO", "CANCELADO"],
                        PREPARANDO: ["LISTO", "CANCELADO"],
                        LISTO: ["ENTREGADO", "CANCELADO"],
                      } as Record<string, string[]>
                    )[o.status]?.map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </label>
                <button>Actualizar pedido de prueba</button>
              </ActionForm>
            )}
        </section>
      ))}
      <Card
        title="Inventario para delivery"
        icon={Package}
        action={
          <Link className="small-link" href="/inventario">
            Ver inventario
          </Link>
        }
      >
        <p className="help">
          Consulta de existencias registradas. Reservar y descontar stock
          automáticamente está pendiente de una integración oficial autorizada;
          estos pedidos de prueba no alteran el inventario.
        </p>
        {stock.map((p) => (
          <div className="stock-row" key={p.id}>
            <strong>{p.name}</strong>
            <span className={p.stock <= p.minimum ? "badge warning" : "badge"}>
              {p.stock} unidades ·{" "}
              {p.stock === 0
                ? "Agotado"
                : p.stock <= p.minimum
                  ? "Stock bajo"
                  : "Disponible"}
            </span>
          </div>
        ))}
        {!stock.length && (
          <EmptyState
            title="Sin productos reales para consultar"
            description="El catálogo ficticio de pruebas no se mezcla con el inventario del negocio."
          />
        )}
      </Card>
      {!orders.length && (
        <section className="card">
          <p>
            No hay pedidos de demostración. Administración o supervisión pueden
            crear uno para probar estados.
          </p>
        </section>
      )}
    </>
  );
}

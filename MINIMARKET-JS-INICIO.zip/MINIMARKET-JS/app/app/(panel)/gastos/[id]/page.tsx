import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { expenseScope } from "@/lib/expenses";
import { clp } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import { ReceiptInput } from "@/components/receipt-input";
import {
  attach,
  proposeExpense,
  approveExpense,
} from "@/app/operations-actions";
export default async function ExpenseDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const user = await requireUser();
  const { id } = await params;
  const expense = await db.expense.findFirst({
    where: { id, ...expenseScope(user) },
    include: {
      attachments: true,
      revisions: { orderBy: { createdAt: "desc" } },
      shift: { include: { user: true } },
      bankAccount: true,
      responsible: true,
    },
  });
  if (!expense) notFound();
  return (
    <>
      <Link href="/gastos">← Gastos y comprobantes</Link>
      <h1>{expense.description}</h1>
      {expense.demo && (
        <p className="alert">COMPROBANTE Y GASTO FICTICIOS DE DEMOSTRACIÓN</p>
      )}
      <section className="card">
        <h2>
          {clp(expense.amount)} · {expense.status}
        </h2>
        <dl className="profile-details">
          {[
            [
              "Fecha",
              expense.occurredAt.toLocaleDateString("es-CL", {
                timeZone: "UTC",
              }),
            ],
            ["Categoría", expense.category],
            ["Medio", expense.method],
            ["Tipo", expense.kind],
            [
              "Responsable",
              expense.responsible?.name ||
                expense.shift?.user.name ||
                "Histórico",
            ],
            [
              "Origen",
              expense.bankAccount?.name ||
                expense.shiftId ||
                "Sin cuenta registrada",
            ],
            ["Beneficiario", expense.beneficiary || "Sin registrar"],
            ["Observaciones", expense.notes || "Sin observaciones"],
          ].map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
        {expense.paymentId && (
          <p>
            Salida vinculada a un pago de factura. No se vuelve a registrar como
            gasto operativo. <Link href="/finanzas">Consultar pagos</Link>
          </p>
        )}
        {user.role === "ADMIN" && expense.status === "PENDIENTE" && (
          <ActionForm action={approveExpense}>
            <input name="id" type="hidden" value={id} />
            <button>Aprobar gasto registrado</button>
          </ActionForm>
        )}
      </section>
      <section className="card">
        <h2>Comprobantes privados</h2>
        <div className="receipt-gallery">
          {expense.attachments.map((a) => (
            <article key={a.id}>
              {a.mime.startsWith("image/") && (
                <a
                  href={`/api/comprobantes/${a.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <img
                    src={`/api/comprobantes/${a.id}`}
                    alt={`Comprobante ${a.originalName}`}
                    width={240}
                    height={180}
                  />
                </a>
              )}
              <Link href={`/api/comprobantes/${a.id}`}>{a.originalName}</Link>
              <small>
                {Math.ceil(a.bytes / 1024)} KB · {a.mime}
              </small>
            </article>
          ))}
        </div>
        {!expense.attachments.length && <p>No hay comprobantes adjuntos.</p>}
        <ActionForm action={attach}>
          <input name="id" type="hidden" value={id} />
          <ReceiptInput />
          <button>Guardar archivos adjuntos</button>
        </ActionForm>
      </section>
      {expense.kind === "OPERATIVO" && expense.status !== "ANULADO" && (
        <section className="card">
          <h2>Solicitar corrección o anulación</h2>
          <p>
            Conserva el original y registra una solicitud. Solo administración
            puede aprobarla. Una caja cerrada no admite modificaciones
            monetarias retroactivas.
          </p>
          <ActionForm action={proposeExpense}>
            <input name="id" type="hidden" value={id} />
            <div className="form-grid">
              <label>
                Tipo de solicitud
                <select name="type">
                  <option value="CORRECCION">Corrección</option>
                  <option value="ANULACION">Anulación</option>
                </select>
              </label>
              <label>
                Descripción corregida
                <input
                  name="description"
                  required
                  defaultValue={expense.description}
                />
              </label>
              <label>
                Categoría corregida
                <input
                  name="category"
                  required
                  defaultValue={expense.category}
                />
              </label>
              <label>
                Monto corregido CLP
                <input
                  name="amount"
                  type="number"
                  min={1}
                  required
                  defaultValue={expense.amount}
                />
              </label>
              <label>
                Beneficiario corregido
                <input name="beneficiary" defaultValue={expense.beneficiary} />
              </label>
            </div>
            <label>
              Observaciones corregidas
              <textarea name="notes" defaultValue={expense.notes} />
            </label>
            <label>
              Motivo de la solicitud
              <textarea name="reason" required minLength={3} />
            </label>
            <button>Enviar solicitud de revisión</button>
          </ActionForm>
        </section>
      )}
      <section className="card">
        <h2>Historial de revisiones</h2>
        {expense.revisions.map((r) => (
          <article className="order" key={r.id}>
            <h3>
              {r.type} · {r.status}
            </h3>
            <p>{r.reason}</p>
            <small>
              {r.createdAt.toLocaleString("es-CL", {
                timeZone: "America/Santiago",
              })}
            </small>
            <dl className="profile-details">
              {Object.entries(r.changes as Record<string, unknown>)
                .filter(([key]) => key !== "baseVersion")
                .map(([key, value]) => (
                  <div key={key}>
                    <dt>
                      {(
                        {
                          description: "Descripción",
                          category: "Categoría",
                          amount: "Monto CLP",
                          beneficiary: "Beneficiario",
                          notes: "Observaciones",
                        } as Record<string, string>
                      )[key] || key}
                    </dt>
                    <dd>
                      {key === "amount"
                        ? clp(Number(value))
                        : String(value || "Sin registrar")}
                    </dd>
                  </div>
                ))}
            </dl>
            {user.role === "ADMIN" && r.status === "PENDIENTE" && (
              <ActionForm action={approveExpense}>
                <input name="id" type="hidden" value={id} />
                <input name="revisionId" type="hidden" value={r.id} />
                <label>
                  Decisión
                  <select name="approve">
                    <option value="true">Aprobar solicitud</option>
                    <option value="false">Rechazar solicitud</option>
                  </select>
                </label>
                <button>Registrar decisión administrativa</button>
              </ActionForm>
            )}
          </article>
        ))}
        {!expense.revisions.length && <p>No hay solicitudes de corrección.</p>}
      </section>
    </>
  );
}

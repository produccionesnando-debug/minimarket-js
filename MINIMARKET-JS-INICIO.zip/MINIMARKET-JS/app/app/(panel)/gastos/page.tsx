import Link from "next/link";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { expenseScope } from "@/lib/expenses";
import { todayChile } from "@/lib/dates";
import { clp, METHODS } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import { ReceiptInput } from "@/components/receipt-input";
import { saveExpense } from "@/app/operations-actions";
export default async function Expenses({
  searchParams,
}: {
  searchParams: Promise<{ demo?: string }>;
}) {
  const user = await requireUser();
  const p = await searchParams;
  const demo = p.demo === "1" && can(user.role, "expenses:readAll");
  const [expenses, shifts, banks, users] = await Promise.all([
    db.expense.findMany({
      where: { ...expenseScope(user), demo },
      include: {
        responsible: true,
        attachments: { select: { id: true } },
        shift: { include: { user: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.shift.findMany({
      where: {
        closedAt: null,
        ...(can(user.role, "shifts:manage") ? {} : { userId: user.id }),
      },
      include: { user: true },
    }),
    db.bankAccount.findMany({ where: { active: true, demo: false } }),
    db.user.findMany({
      where: { active: true },
      select: { id: true, name: true },
    }),
  ]);
  return (
    <>
      <p className="eyebrow">SALIDAS Y RESPALDOS PRIVADOS</p>
      <h1>Gastos y comprobantes</h1>
      <p>
        Un gasto se registra una sola vez. Aprobarlo no vuelve a descontar
        dinero. Los pagos de facturas y retiros aparecen identificados y se
        excluyen del gasto operativo.
      </p>
      {can(user.role, "expenses:readAll") && (
        <div className="toolbar">
          <Link href="/gastos">Datos reales</Link>
          <Link href="/gastos?demo=1">Demostración</Link>
        </div>
      )}
      {demo && (
        <p className="alert">
          DEMOSTRACIÓN · Datos ficticios separados del negocio.
        </p>
      )}
      <section className="card">
        <h2>Registrar gasto</h2>
        <ActionForm action={saveExpense} label="Gasto con comprobantes">
          <input name="requestKey" type="hidden" value={randomUUID()} />
          <input name="kind" type="hidden" value="OPERATIVO" />
          <div className="form-grid">
            <label>
              Fecha del gasto
              <input
                name="date"
                type="date"
                defaultValue={todayChile()}
                required
              />
            </label>
            <label>
              Descripción del gasto
              <input name="description" required maxLength={1000} />
            </label>
            <label>
              Categoría del gasto
              <input
                name="category"
                required
                maxLength={100}
                placeholder="Ej.: servicios, transporte, insumos"
              />
            </label>
            <label>
              Monto del gasto CLP
              <input
                name="amount"
                type="number"
                min={1}
                max={1000000000}
                required
              />
            </label>
            <label>
              Medio de pago del gasto
              <select name="method">
                {METHODS.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </label>
            <label>
              Caja utilizada (efectivo)
              <select name="shiftId">
                <option value="">Mi caja abierta</option>
                {shifts.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.user.name} · {s.id.slice(-6)}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Cuenta utilizada (otros medios)
              <select name="bankAccountId">
                <option value="">Seleccionar cuenta</option>
                {banks.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Trabajador responsable
              <select name="responsibleId" defaultValue={user.id}>
                {(can(user.role, "shifts:manage") ? users : [user]).map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Proveedor o beneficiario
              <input name="beneficiary" maxLength={200} />
            </label>
          </div>
          <label>
            Observaciones
            <textarea name="notes" maxLength={2000} />
          </label>
          <ReceiptInput />
          <button>Guardar gasto con comprobantes</button>
        </ActionForm>
      </section>
      <section className="card table-wrap">
        <h2>Historial de gastos y salidas</h2>
        <p>Últimos 100 registros autorizados.</p>
        <table>
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Descripción</th>
              <th>Responsable</th>
              <th>Tipo</th>
              <th>Monto</th>
              <th>Estado</th>
              <th>Respaldo</th>
            </tr>
          </thead>
          <tbody>
            {expenses.map((e) => (
              <tr key={e.id}>
                <td>
                  {e.occurredAt.toLocaleDateString("es-CL", {
                    timeZone: "UTC",
                  })}
                </td>
                <td>
                  <Link href={`/gastos/${e.id}`}>{e.description}</Link>
                  <small>
                    {e.category} · {e.method}
                  </small>
                </td>
                <td>
                  {e.responsible?.name || e.shift?.user.name || "Histórico"}
                </td>
                <td>{e.kind}</td>
                <td>{clp(e.amount)}</td>
                <td>{e.status}</td>
                <td>{e.attachments.length} archivos</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!expenses.length && <p>No hay registros para este modo y usuario.</p>}
      </section>
    </>
  );
}

import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { can, ROLE_LABELS } from "@/lib/permissions";
import { logout } from "@/app/actions";
export default async function Panel({
  children,
}: {
  children: React.ReactNode;
}) {
  const u = await requireUser();
  return (
    <div className="shell">
      <aside>
        <Link className="wordmark" href="/calendario">
          <span className="logo">JS</span>
          <span>
            MINIMARKET<small>ADMINISTRACIÓN</small>
          </span>
        </Link>
        <nav>
          <Link href="/calendario">▦ Calendario</Link>
          <Link href="/proveedores">▧ Proveedores</Link>
          <Link href="/pedidos">▤ Pedidos</Link>
          {can(u.role, "finance:write") && (
            <Link href="/finanzas">$ Finanzas de proveedores</Link>
          )}
          <Link href="/caja">▣ Caja y ventas</Link>
          <Link href="/gastos">▧ Gastos y comprobantes</Link>
          {can(u.role, "stats:read") && (
            <Link href="/estadisticas">▥ Estadísticas e informes</Link>
          )}
          <Link href="/pedidosya">▣ PedidosYa · Demo</Link>
          {u.role === "ADMIN" && (
            <Link href="/configuracion">⚙ Cuentas y reservas</Link>
          )}
          <Link href="/inventario">▤ Inventario</Link>
          {can(u.role, "users:write") && (
            <Link href="/usuarios">♙ Usuarios</Link>
          )}
          {can(u.role, "audit:read") && (
            <Link href="/auditoria">≡ Auditoría</Link>
          )}
          <Link href="/mi-cuenta">⚙ Mi cuenta</Link>
        </nav>
        <div className="profile">
          <strong>{u.name}</strong>
          <small>{ROLE_LABELS[u.role]}</small>
          <form action={logout}>
            <button className="secondary">Cerrar sesión</button>
          </form>
        </div>
      </aside>
      <div className="workspace">
        <header>
          <span>Panel de gestión</span>
          <span>Chile · CLP</span>
        </header>
        <main>{children}</main>
        <footer>MINIMARKET JS · Gestión simple, decisiones claras.</footer>
      </div>
    </div>
  );
}

import Link from "next/link";
import { welcomeData } from "@/lib/daily-scripture";
import { DailyWelcome } from "@/components/daily-welcome";
import { getBrand } from "@/lib/brand";
import { BrandLogo } from "@/components/brand-logo";
import { Bell, UserRound, ChevronRight } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { can, ROLE_LABELS } from "@/lib/permissions";
import { Navigation, GlobalSearch } from "@/components/navigation";
import { db } from "@/lib/db";
import { expenseScope } from "@/lib/expenses";
export default async function Panel({
  children,
}: {
  children: React.ReactNode;
}) {
  const u = await requireUser();
  const brand = await getBrand();
  const welcome = await welcomeData(u.id);
  const [stock, expenses] = await Promise.all([
    db.product.findMany({
      where: {
        demo: false,
        active: true,
        stockKnown: true,
        stock: { lte: db.product.fields.minimum },
      },
    }),
    db.expense.count({
      where: {
        ...expenseScope(u),
        demo: false,
        status: "PENDIENTE",
        kind: "OPERATIVO",
      },
    }),
  ]);
  const stockCount = stock.filter(
    (p) =>
      (["PESO", "VARIABLE"].includes(p.unitType)
        ? p.stockGrams / 1000
        : p.stock) <= p.minimum,
  ).length;
  const count = stockCount + expenses;
  return (
    <div className="shell">
      <a className="skip-link" href="#contenido">
        Saltar al contenido
      </a>
      <Navigation user={{ name: u.name, role: u.role }} brand={brand} />
      <div className="workspace">
        <header className="topbar">
          <Link
            href="/inicio"
            className="header-brand"
            aria-label="Inicio de MiniMarket JS"
          >
            <BrandLogo brand={brand} variant="header" />
          </Link>
          <GlobalSearch />
          <div className="topbar-right">
            <details className="notifications">
              <summary aria-label={`Alertas: ${count}`}>
                <Bell size={21} aria-hidden="true" />
                {count > 0 && (
                  <span className="notification-count">{count}</span>
                )}
              </summary>
              <div className="notification-panel">
                <strong>Alertas del negocio</strong>
                <Link href="/inventario">
                  {stockCount} productos con stock bajo
                  <ChevronRight size={15} />
                </Link>
                <Link href="/gastos">
                  {expenses} gastos pendientes de aprobación
                  <ChevronRight size={15} />
                </Link>
                {!count && <p>No hay alertas registradas.</p>}
              </div>
            </details>
            <Link href="/mi-cuenta" className="user-link">
              <span className="avatar">
                <UserRound size={19} aria-hidden="true" />
              </span>
              <span>
                <strong>{ROLE_LABELS[u.role]}</strong>
                <small>{u.name}</small>
              </span>
            </Link>
          </div>
        </header>
        <main id="contenido">
          {process.env.DEMO_INSTANCE === "1" && (
            <p className="demo-banner">
              Entorno de demostración · Todos los datos de esta instancia son
              ficticios.
            </p>
          )}
          <DailyWelcome name={u.name} data={welcome} />
          {children}
        </main>
        <footer>
          Minimarket JS <span>Tu negocio en orden · Chile · CLP</span>
        </footer>
      </div>
    </div>
  );
}

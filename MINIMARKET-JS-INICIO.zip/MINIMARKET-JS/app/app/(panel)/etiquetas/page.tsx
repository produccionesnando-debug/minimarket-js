import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { PrintButton } from "@/components/print-button";
import { clp } from "@/lib/money";
export default async function Labels({
  searchParams,
}: {
  searchParams: Promise<{ producto?: string; copias?: string }>;
}) {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write")) return <h1>Acceso restringido</h1>;
  const query = await searchParams;
  const products = await db.product.findMany({
    where: { internalCode: { not: null } },
    orderBy: { name: "asc" },
    take: 200,
  });
  const product = products.find((p) => p.id === query.producto);
  const copies = Math.min(50, Math.max(1, Number(query.copias) || 1));
  return (
    <>
      <h1>Etiquetas de productos</h1>
      <p className="no-print">
        Code 128 para códigos internos. Selecciona la impresora en el diálogo
        del navegador; ajusta el tamaño a tu papel. No se ha certificado un
        modelo físico.
      </p>
      <form className="toolbar no-print">
        <label>
          Producto
          <select name="producto" defaultValue={query.producto}>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} · {p.internalCode}
              </option>
            ))}
          </select>
        </label>
        <label>
          Copias
          <input
            name="copias"
            type="number"
            min={1}
            max={50}
            defaultValue={copies}
          />
        </label>
        <button>Preparar etiquetas</button>
      </form>
      {product && (
        <>
          <PrintButton label="Imprimir etiquetas" />
          <section className="product-labels">
            {Array.from({ length: copies }, (_, i) => (
              <article className="product-label" key={i}>
                <strong>{product.name}</strong>
                <p>
                  {clp(product.price)}
                  {product.unitType === "PESO" ? " / kg" : ""}
                </p>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={"/api/productos/" + product.id + "/etiqueta"}
                  alt={"Código interno " + product.internalCode}
                />
                <small>Código interno MiniMarket JS · no es GTIN</small>
              </article>
            ))}
          </section>
        </>
      )}
    </>
  );
}

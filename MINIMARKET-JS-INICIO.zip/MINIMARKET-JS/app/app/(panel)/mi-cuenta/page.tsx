import { requireUser } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/permissions";
import { ActionForm } from "@/components/action-form";
import { changePassword } from "@/app/phase1-actions";
export default async function Account() {
  const u = await requireUser();
  return (
    <>
      <p className="eyebrow">SEGURIDAD PERSONAL</p>
      <h1>Mi cuenta</h1>
      <section className="card">
        <h2>{u.name}</h2>
        <p>
          {u.email} · {ROLE_LABELS[u.role]}
        </p>
        <h2>Cambiar contraseña</h2>
        <ActionForm action={changePassword}>
          <label>
            Contraseña actual
            <input
              name="currentPassword"
              type="password"
              maxLength={100}
              required
              autoComplete="current-password"
            />
          </label>
          <label>
            Nueva contraseña
            <input
              name="password"
              type="password"
              minLength={12}
              maxLength={72}
              required
              autoComplete="new-password"
            />
          </label>
          <label>
            Confirmar nueva contraseña
            <input
              name="confirmation"
              type="password"
              minLength={12}
              maxLength={72}
              required
              autoComplete="new-password"
            />
          </label>
          <button>Cambiar contraseña y cerrar sesiones</button>
        </ActionForm>
        <p>
          Al cambiarla se cierran todas tus sesiones. Vuelve a iniciar sesión
          con la nueva contraseña.
        </p>
      </section>
    </>
  );
}

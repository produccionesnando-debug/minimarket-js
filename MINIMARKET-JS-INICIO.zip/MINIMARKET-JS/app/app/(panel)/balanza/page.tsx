import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { ActionForm } from "@/components/action-form";
import { scalePatternAction } from "@/app/scale-actions";
export default async function Scale() {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write")) return <h1>Acceso restringido</h1>;
  const p = await db.scalePattern.findUnique({ where: { id: "global" } });
  return (
    <>
      <h1>Balanza etiquetadora</h1>
      <p className="alert">
        Preparación desactivada: no se asume un formato universal. Falta conocer
        el modelo, verificar etiquetas reales y mapear los productos antes de
        habilitar lecturas en caja.
      </p>
      <ActionForm action={scalePatternAction} label="Patrón de balanza">
        <div className="form-grid">
          <label>
            Modelo de balanza
            <input name="model" defaultValue={p?.model} required />
          </label>
          <label>
            Prefijo del código
            <input name="prefix" defaultValue={p?.prefix} required />
          </label>
          {(
            [
              ["codeLength", "Longitud del código", 13],
              ["productStart", "Inicio del producto (desde 0)", 2],
              ["productLength", "Largo del producto", 5],
              ["valueStart", "Inicio del valor (desde 0)", 7],
              ["valueLength", "Largo del valor", 5],
              ["decimals", "Decimales del valor", 3],
            ] as const
          ).map(([name, label, value]) => (
            <label key={name}>
              {label}
              <input
                name={name}
                type="number"
                min={0}
                max={name === "decimals" ? 3 : 40}
                required
                defaultValue={p?.[name] ?? value}
              />
            </label>
          ))}
          <label>
            Contenido del valor
            <select name="kind" defaultValue={p?.kind || "WEIGHT"}>
              <option value="WEIGHT">Peso en kilogramos</option>
              <option value="AMOUNT">Importe en pesos</option>
            </select>
          </label>
        </div>
        <button>Guardar preparación desactivada</button>
      </ActionForm>
    </>
  );
}

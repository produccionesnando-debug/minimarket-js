import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { googleReady } from "@/lib/google";
import { accessAction } from "@/app/client-actions";
import { ActionForm } from "@/components/action-form";
export default async function Access() {
  await requireUser(true);
  const users = await db.user.findMany({
      select: { id: true, name: true, email: true, role: true, active: true },
      orderBy: { name: "asc" },
    }),
    accounts = await db.googleAccount.findMany(),
    grants = await db.googleGrant.findMany();
  return (
    <>
      <h1>Acceso con Google</h1>
      <p className="alert">
        {googleReady()
          ? "Configuración presente; requiere validación con una cuenta autorizada."
          : "Pendiente de credenciales Google Cloud. El acceso tradicional continúa disponible."}
      </p>
      <p>
        Autoriza una cuenta Google para un usuario existente. La vinculación
        exige correo Google verificado y una invitación vigente de 7 días;
        conserva su rol. No se crean usuarios automáticamente.
      </p>
      {users.map((u) => (
        <section className="card" key={u.id}>
          <h2>
            {u.name} · {u.role}
          </h2>
          <p>
            {u.email} · {u.active ? "Activo" : "Inactivo"}
          </p>
          <p>
            Google:{" "}
            {accounts.find((a) => a.userId === u.id)?.email || "Sin vincular"} ·
            Invitación:{" "}
            {grants.find((g) => g.userId === u.id)?.email || "Ninguna"}
          </p>
          <ActionForm action={accessAction}>
            <input type="hidden" name="userId" value={u.id} />
            <label>
              Correo Google autorizado
              <input name="email" type="email" />
            </label>
            <button name="op" value="invite">
              Autorizar vinculación
            </button>
            <button className="secondary" name="op" value="revoke">
              Revocar Google y sesiones
            </button>
            <label>
              <input required type="checkbox" />
              Verifiqué la identidad del trabajador y esta cuenta.
            </label>
          </ActionForm>
        </section>
      ))}
    </>
  );
}

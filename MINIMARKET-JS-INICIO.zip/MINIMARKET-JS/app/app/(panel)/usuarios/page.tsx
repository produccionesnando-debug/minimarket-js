import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { can, ROLE_LABELS } from "@/lib/permissions";
import { saveUser } from "@/app/phase1-actions";
import { ActionForm } from "@/components/action-form";
import { UserFields } from "@/components/user-fields";
export default async function Users() {
  const actor = await requireUser();
  if (!can(actor.role, "users:write"))
    return (
      <section className="card">
        <h1>Acceso restringido</h1>
        <p>La gestión de usuarios está reservada al administrador.</p>
      </section>
    );
  const users = await db.user.findMany({
    select: { id: true, name: true, email: true, role: true, active: true },
    orderBy: { name: "asc" },
  });
  return (
    <>
      <p className="eyebrow">EQUIPO Y ACCESOS</p>
      <h1>Usuarios y permisos</h1>
      <section className="card">
        <h2>Permisos por rol</h2>
        <div className="role-cards">
          <article>
            <h3>Administrador</h3>
            <p>Acceso completo, usuarios y auditoría.</p>
          </article>
          <article>
            <h3>Supervisor</h3>
            <p>
              Gestiona proveedores, contactos, agenda y estados de pedidos.
              Consulta todos los cierres; opera su propia caja. No modifica
              usuarios ni productos.
            </p>
          </article>
          <article>
            <h3>Trabajador</h3>
            <p>
              Consulta calendario, proveedores e inventario y opera solamente su
              propia caja.
            </p>
          </article>
        </div>
      </section>
      <section className="card">
        <h2>Personal autorizado</h2>
        {users.map((u) => (
          <article className="contact-card" key={u.id}>
            <div className="section-heading">
              <div>
                <h3>{u.name}</h3>
                <small>{u.email}</small>
              </div>
              <span className="badge">
                {ROLE_LABELS[u.role]} · {u.active ? "Activo" : "Inactivo"}
              </span>
            </div>
            <details>
              <summary>Editar usuario</summary>
              <ActionForm action={saveUser} label={`Editar usuario ${u.email}`}>
                <UserFields user={u} />
              </ActionForm>
            </details>
          </article>
        ))}
      </section>
      <section className="card">
        <h2>Crear usuario</h2>
        <ActionForm action={saveUser} label="Crear usuario">
          <UserFields />
        </ActionForm>
        <p>
          Los cambios de rol, correo, contraseña o desactivación revocan las
          sesiones existentes. No puedes desactivar tu propia cuenta ni quitarte
          el rol administrador.
        </p>
      </section>
    </>
  );
}

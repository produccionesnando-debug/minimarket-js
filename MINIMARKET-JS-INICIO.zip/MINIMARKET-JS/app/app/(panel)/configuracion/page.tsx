import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { ActionForm } from "@/components/action-form";
import {
  saveBank,
  saveReserve,
  confirmFinance,
  bankMovement,
} from "@/app/operations-actions";
import { clp } from "@/lib/money";
import { bankBalance, serial } from "@/lib/cash";
import { todayChile } from "@/lib/dates";
export default async function Config() {
  const user = await requireUser();
  if (user.role !== "ADMIN") return <h1>Acceso restringido</h1>;
  const [accounts, reserves, config] = await Promise.all([
    db.bankAccount.findMany({ where: { demo: false, active: true } }),
    db.financeReserve.findMany(),
    db.financeConfig.findUnique({ where: { id: "global" } }),
  ]);
  const balances = await Promise.all(
    accounts.map((a) => serial((tx) => bankBalance(tx, a.id))),
  );
  return (
    <>
      <h1>Cuentas y reservas</h1>
      <p>
        Registra solamente saldos comprobados. No se conectan bancos ni se
        calculan obligaciones fiscales automáticamente.
      </p>
      <section className="card">
        <h2>Registrar cuenta bancaria o de liquidación</h2>
        <ActionForm action={saveBank}>
          <label>
            Nombre de la cuenta
            <input
              name="name"
              required
              placeholder="Etiqueta interna, sin credenciales"
            />
          </label>
          <label>
            Saldo inicial comprobado (opcional)
            <input name="initialBalance" type="number" />
          </label>
          <label>
            Fecha del saldo
            <input name="balanceDate" type="date" />
          </label>
          <button>Guardar cuenta</button>
        </ActionForm>
        {accounts.map((a, index) => (
          <details key={a.id}>
            <summary>
              {a.name} · Saldo registrado actual:{" "}
              {balances[index] === null ? "Pendiente" : clp(balances[index]!)}
            </summary>
            <ActionForm action={saveBank}>
              <input name="id" type="hidden" value={a.id} />
              <label>
                Nombre de la cuenta
                <input name="name" defaultValue={a.name} required />
              </label>
              <label>
                Saldo inicial comprobado
                <input
                  name="initialBalance"
                  type="number"
                  defaultValue={a.initialBalance ?? ""}
                />
              </label>
              <label>
                Fecha del saldo
                <input
                  name="balanceDate"
                  type="date"
                  defaultValue={a.balanceDate?.toISOString().slice(0, 10) || ""}
                />
              </label>
              <button>Actualizar cuenta y saldo inicial</button>
            </ActionForm>
            <p>
              El saldo inicial corresponde al comienzo de la fecha indicada.
              Cambiarlo requiere volver a confirmar la base del presupuesto. Los
              movimientos posteriores se calculan aparte.
            </p>
          </details>
        ))}
      </section>
      <section className="card">
        <h2>Registrar abono o ajuste bancario comprobado</h2>
        <p>
          Usa importes positivos para abonos y negativos para otros egresos. No
          vuelvas a ingresar aquí un gasto o pago de factura ya vinculado a la
          cuenta.
        </p>
        <ActionForm action={bankMovement}>
          <input name="requestKey" type="hidden" value={randomUUID()} />
          <label>
            Cuenta
            <select name="accountId" required>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Fecha
            <input
              name="date"
              type="date"
              defaultValue={todayChile()}
              required
            />
          </label>
          <label>
            Importe firmado CLP
            <input name="amount" type="number" required />
          </label>
          <label>
            Descripción
            <input name="description" required />
          </label>
          <button>Registrar movimiento interno</button>
        </ActionForm>
      </section>
      <section className="card">
        <h2>Reservas de obligaciones</h2>
        <p>
          Por ejemplo: IVA, arriendo, sueldos, contador, cotizaciones o
          servicios. Una reserva no es un gasto pagado.
        </p>
        <ActionForm action={saveReserve}>
          <label>
            Nombre de la reserva
            <input name="name" required />
          </label>
          <label>
            Monto reservado CLP
            <input name="amount" type="number" min={0} required />
          </label>
          <button>Agregar reserva</button>
        </ActionForm>
        {reserves.map((r) => (
          <details key={r.id}>
            <summary>
              {r.name} · {clp(r.amount)} · {r.active ? "Activa" : "Inactiva"}
            </summary>
            <ActionForm action={saveReserve}>
              <input name="id" type="hidden" value={r.id} />
              <label>
                Nombre
                <input name="name" defaultValue={r.name} required />
              </label>
              <label>
                Reserva CLP
                <input
                  name="amount"
                  type="number"
                  min={0}
                  defaultValue={r.amount}
                  required
                />
              </label>
              <label>
                Estado
                <select name="active" defaultValue={String(r.active)}>
                  <option value="true">Activa</option>
                  <option value="false">Inactiva</option>
                </select>
              </label>
              <button>Guardar reserva</button>
            </ActionForm>
          </details>
        ))}
      </section>
      <section className="card">
        <h2>Base del presupuesto de compras</h2>
        <ActionForm action={confirmFinance}>
          <label className="check-line">
            <input
              name="fundsConfirmed"
              type="checkbox"
              defaultChecked={config?.fundsConfirmed}
            />
            Confirmo que registré todas las cuentas y saldos comprobados
            necesarios.
          </label>
          <label className="check-line">
            <input
              name="reservesConfirmed"
              type="checkbox"
              defaultChecked={config?.reservesConfirmed}
            />
            Confirmo que revisé y registré las obligaciones y reservas
            aplicables.
          </label>
          <button>Guardar confirmación</button>
        </ActionForm>
        <p>
          Sin esta confirmación no se presenta un presupuesto disponible como si
          fuera conocido.
        </p>
      </section>
    </>
  );
}

import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { ActionForm } from "@/components/action-form";
import { categoryAction } from "@/app/catalog-actions";
export default async function Categories() {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write")) return <h1>Acceso restringido</h1>;
  const categories = await db.category.findMany({
    include: { parent: true, _count: { select: { products: true } } },
    orderBy: { name: "asc" },
  });
  return (
    <>
      <p className="eyebrow">ORGANIZAR CATÁLOGO</p>
      <h1>Categorías y subcategorías</h1>
      <section className="card">
        <h2>Crear categoría</h2>
        <ActionForm action={categoryAction}>
          <div className="form-grid">
            <label>
              Nombre de la categoría
              <input name="name" required minLength={2} maxLength={100} />
            </label>
            <label>
              Categoría superior
              <select name="parentId">
                <option value="">Ninguna · categoría principal</option>
                {categories
                  .filter((c) => c.active)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </select>
            </label>
            <button>Crear categoría</button>
          </div>
        </ActionForm>
      </section>
      <section className="card">
        <h2>Categorías registradas</h2>
        {categories.map((c) => (
          <article className="contact-card" key={c.id}>
            <h3>
              {c.parent ? c.parent.name + " / " : ""}
              {c.name}{" "}
              <span className="badge">{c.active ? "Activa" : "Inactiva"}</span>
            </h3>
            <small>{c._count.products} productos asociados</small>
            <details>
              <summary>Editar categoría</summary>
              <ActionForm action={categoryAction}>
                <input type="hidden" name="id" value={c.id} />
                <label>
                  Nombre
                  <input name="name" defaultValue={c.name} required />
                </label>
                <label>
                  Categoría superior
                  <select name="parentId" defaultValue={c.parentId || ""}>
                    <option value="">Principal</option>
                    {categories
                      .filter((v) => v.id !== c.id)
                      .map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name}
                        </option>
                      ))}
                  </select>
                </label>
                <label>
                  Estado
                  <select name="active" defaultValue={String(c.active)}>
                    <option value="true">Activa</option>
                    <option value="false">Inactiva</option>
                  </select>
                </label>
                <button>Guardar categoría</button>
              </ActionForm>
            </details>
          </article>
        ))}
        {!categories.length && (
          <p>
            No hay categorías administrables todavía. Puedes crearlas aquí o
            durante una importación. Las categorías de texto de productos
            anteriores se conservan.
          </p>
        )}
      </section>
    </>
  );
}

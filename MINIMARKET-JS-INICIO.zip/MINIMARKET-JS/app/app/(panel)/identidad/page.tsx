import { requireUser } from "@/lib/auth";
import { getBrand } from "@/lib/brand";
import { BrandLogo } from "@/components/brand-logo";
import { ActionForm } from "@/components/action-form";
import { brandAction } from "@/app/brand-actions";
export default async function Identity() {
  await requireUser(true);
  const brand = await getBrand();
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">MINIMARKET JS</p>
          <h1>Identidad del negocio</h1>
          <p>
            El mismo archivo original en toda la aplicación, conservando colores
            y proporciones.
          </p>
        </div>
      </div>
      <div className="columns">
        <section className="card brand-settings">
          <h2>Logo oficial</h2>
          <BrandLogo brand={brand} />
          {!brand.available && (
            <p className="alert">
              Logo original pendiente de carga. Se utiliza únicamente el nombre
              del negocio en texto.
            </p>
          )}
          <ActionForm action={brandAction} label="Cargar logo oficial">
            <label>
              Archivo original del logo
              <input
                type="file"
                name="logo"
                accept="image/png,image/jpeg,image/webp"
                required
              />
            </label>
            <p className="help">
              PNG, JPG o WebP estático, hasta 5 MB. Se conserva el archivo
              exacto. Los tamaños de favicon y PWA se generan con márgenes, sin
              recortar ni deformar. El fondo blanco permite mantenerlo legible
              sobre el menú azul.
            </p>
            <label>
              <input type="checkbox" required />
              Este es el logo oficial de mi negocio.
            </label>
            <button>Guardar identidad visual</button>
          </ActionForm>
        </section>
        <section className="card">
          <h2>Dónde se utiliza</h2>
          <p>
            Inicio de sesión, menú lateral, encabezado, comprobantes internos,
            PDF de informes e iconos de instalación.
          </p>
          <div className="brand-swatches">
            <span>Azul profundo</span>
            <span>Turquesa</span>
            <span>Verde</span>
            <span>Amarillo</span>
          </div>
          <p>
            La versión compacta contiene el logo completo en un panel claro; no
            se redibuja ni se extraen partes de la marca.
          </p>
          {brand.available && (
            <div className="brand-icon-samples">
              {[32, 180, 192, 512].map((size) => (
                <a key={size} href={"/api/identidad/logo?size=" + size}>
                  PNG {size} × {size}
                </a>
              ))}
            </div>
          )}
        </section>
      </div>
    </>
  );
}

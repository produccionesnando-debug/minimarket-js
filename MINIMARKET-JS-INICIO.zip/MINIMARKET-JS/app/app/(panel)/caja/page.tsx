import { closureBreakdown } from "@/lib/closure-breakdown";
import { ServerForm } from "@/components/server-form";
import { ConfirmForm } from "@/components/confirm-form";
import { ProductSelect } from "@/components/product-select";
import Link from "next/link";
import { randomUUID } from "node:crypto";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { openShift, sell, expense, closeShift } from "@/app/actions";
import { saveExpense, reviewShift } from "@/app/operations-actions";
import { ActionForm } from "@/components/action-form";
import { clp, cashExpected, METHODS } from "@/lib/money";
import { todayChile } from "@/lib/dates";
export default async function Cash({
  searchParams,
}: {
  searchParams: Promise<{ trabajador?: string }>;
}) {
  const actor = await requireUser();
  const p = await searchParams;
  const selected =
    can(actor.role, "shifts:manage") && p.trabajador ? p.trabajador : actor.id;
  const [shift, history, users] = await Promise.all([
    db.shift.findFirst({
      where: { userId: selected, closedAt: null },
      include: {
        user: true,
        sales: {
          include: { items: { include: { product: true } } },
          orderBy: { createdAt: "desc" },
        },
        expenses: true,
        collections: true,
      },
    }),
    db.shift.findMany({
      where: {
        ...(can(actor.role, "closures:read") ? {} : { userId: actor.id }),
        closedAt: { not: null },
      },
      include: { user: true },
      orderBy: { closedAt: "desc" },
      take: 30,
    }),
    db.user.findMany({
      where: {
        active: true,
        ...(can(actor.role, "shifts:manage") ? {} : { id: actor.id }),
      },
      select: { id: true, name: true },
    }),
  ]);
  const products = await db.product.findMany({
    where: { stock: { gt: 0 }, demo: shift?.demo ?? false },
    orderBy: { name: "asc" },
  });
  const total = shift?.sales.reduce((a, s) => a + s.total, 0) || 0;
  const cash =
    shift?.sales
      .filter((s) => s.paymentVersion === 0 && s.method === "EFECTIVO")
      .reduce((a, s) => a + s.total, 0) || 0;
  const ledgerCash =
    shift?.collections
      .filter((c) => c.method === "EFECTIVO")
      .reduce((a, c) => a + c.amount, 0) || 0;
  const out =
    shift?.expenses
      .filter((e) => e.method === "EFECTIVO" && e.status !== "ANULADO")
      .reduce((a, e) => a + e.amount, 0) || 0;
  const breakdown = shift ? await closureBreakdown(db, shift.id) : null;
  return (
    <>
      <p className="eyebrow">CONTROL DE TURNO Y RESPONSABILIDAD</p>
      <div className="page-heading">
        <h1>Caja y ventas</h1>
        <Link className="button" href="/ventas">
          Abrir punto de venta
        </Link>
      </div>
      <p>
        Cada operación conserva identificador, fecha y actor. Los gastos y pagos
        a proveedores se descuentan desde el mismo registro, una sola vez.
      </p>
      {can(actor.role, "shifts:manage") && (
        <form className="filters">
          <label>
            Trabajador responsable
            <select name="trabajador" defaultValue={selected}>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          </label>
          <button className="secondary">Ver caja del trabajador</button>
        </form>
      )}
      {!shift ? (
        <section className="card">
          <h2 id="abrir-caja">Abrir caja</h2>
          <ServerForm action={openShift}>
            <input name="userId" type="hidden" value={selected} />
            <label>
              Caja utilizada
              <input
                name="register"
                defaultValue="Caja principal"
                required
                maxLength={100}
              />
            </label>
            <label>
              Observaciones de apertura
              <textarea name="openingNotes" maxLength={1000} />
            </label>
            <label>
              Fondo inicial en efectivo (CLP)
              <input type="number" name="opening" min={0} required />
            </label>
            {process.env.DEMO_INSTANCE !== "1" && (
              <label className="check-line">
                <input name="demo" type="checkbox" />
                Turno de demostración, separado de informes reales
              </label>
            )}
            <button>Abrir mi caja</button>
          </ServerForm>
        </section>
      ) : (
        <>
          {shift.demo && (
            <p className="alert">
              CAJA DE DEMOSTRACIÓN · Solo productos ficticios y estadísticas
              demo.
            </p>
          )}
          <h2>Turno de {shift.user.name}</h2>
          <small>
            Abierta{" "}
            {shift.openedAt.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            })}{" "}
            · ID {shift.id}
          </small>
          <div className="stats">
            <article>
              <small>Ventas de la jornada</small>
              <strong>{clp(total)}</strong>
            </article>
            <article>
              <small>Salidas en efectivo</small>
              <strong>{clp(out)}</strong>
            </article>
            <article>
              <small>Efectivo esperado</small>
              <strong>
                {clp(cashExpected(shift.opening, cash + ledgerCash, out))}
              </strong>
            </article>
          </div>
          <div className="columns">
            <section className="card">
              <h2 id="nueva-venta">Registrar venta</h2>
              <ServerForm action={sell}>
                <input name="shiftId" type="hidden" value={shift.id} />
                <input name="requestKey" type="hidden" value={randomUUID()} />
                <ProductSelect
                  products={products.map((p) => ({
                    id: p.id,
                    name: p.name,
                    barcode: p.barcode,
                    price: p.price,
                    stock: p.stock,
                  }))}
                />
                <label>
                  Cantidad
                  <input
                    type="number"
                    name="quantity"
                    min={1}
                    defaultValue={1}
                    required
                  />
                </label>
                <label>
                  Medio de pago
                  <select name="method">
                    {METHODS.map((m) => (
                      <option key={m}>{m}</option>
                    ))}
                  </select>
                </label>
                <label className="check-line">
                  <input type="checkbox" name="bankVerified" />
                  Verifiqué la aprobación bancaria (obligatorio para medios
                  electrónicos)
                </label>
                <button>Registrar venta</button>
              </ServerForm>
            </section>
            <section className="card">
              <h2>Registrar gasto</h2>
              <p>
                Salida rápida sin respaldo. Para adjuntar fotos o PDF utiliza{" "}
                <Link href="/gastos">Gastos y comprobantes</Link>.
              </p>
              <ServerForm action={expense}>
                <input name="shiftId" type="hidden" value={shift.id} />
                <input
                  name="responsibleId"
                  type="hidden"
                  value={shift.userId}
                />
                <input name="requestKey" type="hidden" value={randomUUID()} />
                <label>
                  Descripción
                  <input name="description" maxLength={500} required />
                </label>
                <label>
                  Monto en efectivo (CLP)
                  <input type="number" name="amount" min={1} required />
                </label>
                <button className="secondary">Guardar gasto</button>
              </ServerForm>
              <hr />
              <h2>Retirar efectivo</h2>
              <ActionForm action={saveExpense}>
                <input name="kind" type="hidden" value="RETIRO" />
                <input
                  name="category"
                  type="hidden"
                  value="Retiro de efectivo"
                />
                <input name="method" type="hidden" value="EFECTIVO" />
                <input name="date" type="hidden" value={todayChile()} />
                <input name="shiftId" type="hidden" value={shift.id} />
                <input
                  name="responsibleId"
                  type="hidden"
                  value={shift.userId}
                />
                <input name="requestKey" type="hidden" value={randomUUID()} />
                <label>
                  Motivo del retiro
                  <input name="description" required />
                </label>
                <label>
                  Monto del retiro
                  <input name="amount" type="number" min={1} required />
                </label>
                <button className="secondary">Registrar retiro</button>
              </ActionForm>
            </section>
          </div>
          <section className="card">
            <h2>Cerrar caja</h2>
            {breakdown && (
              <details open>
                <summary>Desglose del turno antes del cierre</summary>
                <dl className="closure-breakdown">
                  {Object.entries(breakdown).map(([label, value]) => (
                    <div key={label}>
                      <dt>{label}</dt>
                      <dd>{clp(value)}</dd>
                    </div>
                  ))}
                </dl>
                <p>
                  Los medios electrónicos y el crédito a clientes no son
                  efectivo físico. La verificación del trabajador no reemplaza
                  la conciliación bancaria.
                </p>
              </details>
            )}
            <ConfirmForm
              action={closeShift}
              title="¿Cerrar esta caja?"
              message="Se guardará el efectivo contado y se calculará la diferencia. Revisa el monto antes de confirmar; este cierre queda en el historial."
            >
              <input name="shiftId" type="hidden" value={shift.id} />
              <label>
                Efectivo contado (CLP)
                <input type="number" name="counted" min={0} required />
              </label>
              <label>
                Observaciones de cierre
                <textarea name="closingNotes" maxLength={1000} />
              </label>
              <button>Cerrar y calcular diferencia</button>
            </ConfirmForm>
            <p>
              Cualquier diferencia solicita autorización administrativa. Los
              cierres conservan el esperado y contado de ese momento; la
              revisión administrativa no los reemplaza.
            </p>
          </section>
          <section className="card">
            <h2>Movimientos de la jornada</h2>
            <div className="payment-grid">
              {METHODS.map((m) => (
                <div key={m}>
                  <small>{m}</small>
                  <strong>
                    {clp(
                      shift.sales
                        .filter((s) => s.paymentVersion === 0 && s.method === m)
                        .reduce((a, s) => a + s.total, 0) +
                        shift.collections
                          .filter((c) => c.method === m)
                          .reduce((a, c) => a + c.amount, 0),
                    )}
                  </strong>
                </div>
              ))}
            </div>
            {shift.collections
              .filter((c) => c.kind !== "VENTA")
              .map((c) => (
                <p key={c.id}>
                  {c.kind} · {c.method} <strong>{clp(c.amount)}</strong>
                </p>
              ))}
            {shift.sales.map((s) => (
              <p key={s.id}>
                {s.items
                  .map((i) => `${i.quantity} × ${i.product.name}`)
                  .join(", ")}{" "}
                · {s.method} <strong>{clp(s.total)}</strong>
                <small>
                  {s.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}{" "}
                  · {s.id}
                </small>
              </p>
            ))}
            {shift.expenses.map((e) => (
              <p key={e.id}>
                <Link href={`/gastos/${e.id}`}>
                  {e.kind === "PROVEEDOR"
                    ? "Pago proveedor:"
                    : e.kind === "RETIRO"
                      ? "Retiro:"
                      : "Gasto:"}{" "}
                  {e.description}
                </Link>{" "}
                <strong>
                  {e.status === "ANULADO" ? "Anulado" : `−${clp(e.amount)}`}
                </strong>
                <small>
                  {e.status} · {e.id}
                </small>
              </p>
            ))}
          </section>
        </>
      )}
      <div className="toolbar">
        <Link href="/gastos">Gastos y comprobantes →</Link>
        {can(actor.role, "finance:write") && (
          <Link href="/finanzas">
            Registrar pago a proveedor desde su factura →
          </Link>
        )}
      </div>
      <section className="card table-wrap">
        <h2>Historial de cierres</h2>
        <table>
          <thead>
            <tr>
              <th>Trabajador</th>
              <th>Cierre</th>
              <th>Esperado</th>
              <th>Contado</th>
              <th>Diferencia</th>
              <th>Revisión</th>
            </tr>
          </thead>
          <tbody>
            {history.map((s) => (
              <tr key={s.id}>
                <td>
                  {s.user.name}
                  {s.demo && <small>DEMOSTRACIÓN</small>}
                </td>
                <td>
                  {s.closedAt?.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                </td>
                <td>{clp(s.expected || 0)}</td>
                <td>{clp(s.counted || 0)}</td>
                <td>
                  {clp(s.difference || 0)}
                  {s.differenceAuthorizationRequired && (
                    <small>Requiere autorización administrativa</small>
                  )}
                  {s.closureSnapshot && (
                    <details>
                      <summary>Desglose guardado del cierre</summary>
                      <dl>
                        {Object.entries(
                          s.closureSnapshot as Record<string, number>,
                        ).map(([label, value]) => (
                          <div key={label}>
                            <dt>{label}</dt>
                            <dd>{clp(value)}</dd>
                          </div>
                        ))}
                      </dl>
                    </details>
                  )}
                </td>
                <td>
                  <span className="badge">{s.reviewStatus}</span>
                  <small>{s.reviewNotes}</small>
                  {actor.role === "ADMIN" && (
                    <details>
                      <summary>Revisar cierre</summary>
                      <ActionForm action={reviewShift}>
                        <input name="id" type="hidden" value={s.id} />
                        <label>
                          Resultado de revisión
                          <select name="status">
                            <option value="APROBADO">Aprobado</option>
                            <option value="OBSERVADO">Observado</option>
                          </select>
                        </label>
                        <label>
                          Notas de revisión
                          <textarea name="notes" required />
                        </label>
                        <button>Guardar revisión del cierre</button>
                      </ActionForm>
                    </details>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!history.length && <p>Aún no hay cierres registrados.</p>}
      </section>
    </>
  );
}

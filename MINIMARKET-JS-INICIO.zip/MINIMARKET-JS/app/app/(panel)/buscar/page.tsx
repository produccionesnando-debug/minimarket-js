import Link from "next/link";
import { Search, Package, Truck, ClipboardList } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { Card, EmptyState } from "@/components/ui";
import { clp } from "@/lib/money";
export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  await requireUser();
  const p = await searchParams;
  const q = String(p.q || "")
    .trim()
    .slice(0, 120);
  const [products, suppliers, orders] = q
    ? await Promise.all([
        db.product.findMany({
          where: {
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { barcode: { contains: q, mode: "insensitive" } },
              { brand: { contains: q, mode: "insensitive" } },
            ],
          },
          take: 20,
          orderBy: { name: "asc" },
        }),
        db.supplier.findMany({
          where: {
            demo: false,
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { category: { contains: q, mode: "insensitive" } },
            ],
          },
          take: 20,
          orderBy: { name: "asc" },
        }),
        db.supplierOrder.findMany({
          where: {
            supplier: { demo: false },
            OR: [
              { id: { contains: q, mode: "insensitive" } },
              { supplier: { name: { contains: q, mode: "insensitive" } } },
            ],
          },
          include: { supplier: true },
          take: 20,
          orderBy: { date: "desc" },
        }),
      ])
    : [[], [], []];
  return (
    <>
      <p className="eyebrow">BUSCADOR DEL NEGOCIO</p>
      <h1>Resultados de búsqueda</h1>
      <form className="filters">
        <label>
          Nombre, código de barras o número de pedido
          <input name="q" required defaultValue={q} maxLength={120} />
        </label>
        <button>
          <Search size={17} />
          Buscar
        </button>
      </form>
      <p>Hasta 20 coincidencias por sección.</p>
      {!products.length && !suppliers.length && !orders.length ? (
        <EmptyState
          title="Sin resultados"
          description="Prueba otro nombre o código registrado."
        />
      ) : (
        <div className="search-results">
          <Card title="Productos" icon={Package}>
            {products.map((p) => (
              <Link
                className="result-row"
                key={p.id}
                href={`/inventario?q=${encodeURIComponent(p.barcode)}`}
              >
                <strong>
                  {p.name}
                  {p.demo ? " · DEMO" : ""}
                </strong>
                <small>
                  {p.barcode} · Stock {p.stock} · {clp(p.price)}
                </small>
              </Link>
            ))}
          </Card>
          <Card title="Proveedores" icon={Truck}>
            {suppliers.map((s) => (
              <Link
                className="result-row"
                key={s.id}
                href={`/proveedores/${s.id}`}
              >
                <strong>{s.name}</strong>
                <small>{s.category || "Sin categoría"}</small>
              </Link>
            ))}
          </Card>
          <Card title="Pedidos" icon={ClipboardList}>
            {orders.map((o) => (
              <Link className="result-row" key={o.id} href={`/pedidos/${o.id}`}>
                <strong>{o.supplier.name}</strong>
                <small>
                  N.º {o.id} · {o.status}
                </small>
              </Link>
            ))}
          </Card>
        </div>
      )}
    </>
  );
}

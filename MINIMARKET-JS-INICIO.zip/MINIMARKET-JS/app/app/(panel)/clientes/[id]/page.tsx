import Link from "next/link";
import { Prisma } from "@prisma/client";
import {
  ensureCustomerVouchers,
  voucherState,
  voucherNumber,
  receiptNumber,
} from "@/lib/credit-vouchers";
import { VoucherCollection } from "@/components/voucher-collection";
import { notFound } from "next/navigation";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { outstanding } from "@/lib/pos";
import { clp, METHODS } from "@/lib/money";
import { dateOnly, todayChile } from "@/lib/dates";
import { ActionForm } from "@/components/action-form";
import { customerAction } from "@/app/catalog-actions";
import { customerPaymentAction } from "@/app/pos-actions";
import { PrintButton } from "@/components/print-button";
export default async function Customer({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ desde?: string; hasta?: string; estado?: string }>;
}) {
  const actor = await requireUser();
  const { id } = await params;
  const filter = await searchParams;
  await ensureCustomerVouchers(id, actor);
  const data = await db.$transaction(
    async (tx) => {
      const c = await tx.customer.findUnique({
        where: { id },
        include: {
          sales: {
            include: {
              items: true,
              shift: { include: { user: true } },
              returns: true,
              customerPayments: { include: { collection: true } },
            },
            orderBy: { createdAt: "desc" },
          },
        },
      });
      if (!c) return null;
      const shift = await tx.shift.findFirst({
        where: { userId: actor.id, closedAt: null, demo: c.demo },
      });
      const vouchers = await tx.creditVoucher.findMany({
        where: { customerId: id },
        orderBy: { createdAt: "desc" },
      });
      const allocations = await tx.creditAllocation.findMany({
        where: { voucherId: { in: vouchers.map((v) => v.id) } },
      });
      const receipts = await tx.creditReceipt.findMany({
        where: { customerId: id },
        orderBy: { createdAt: "desc" },
      });
      const workers = await tx.user.findMany({
        where: { id: { in: receipts.map((r) => r.actorId) } },
        select: { id: true, name: true },
      });
      return { c, shift, vouchers, allocations, receipts, workers };
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.RepeatableRead },
  );
  if (!data) notFound();
  const { c, shift, vouchers, allocations, receipts, workers } = data;
  const visibleSales = c.sales.filter((s) => {
    const day = todayChile(s.createdAt);
    return (
      (!filter.desde || day >= filter.desde) &&
      (!filter.hasta || day <= filter.hasta) &&
      (!filter.estado ||
        (s.creditAmount > 0 && voucherState(s) === filter.estado))
    );
  });
  const filteredVouchers = vouchers.filter((v) => {
    const sale = c.sales.find((s) => s.id === v.saleId)!;
    const day = sale.createdAt.toLocaleDateString("en-CA", {
      timeZone: "America/Santiago",
    });
    return (
      (!filter.desde || day >= filter.desde) &&
      (!filter.hasta || day <= filter.hasta) &&
      (!filter.estado || voucherState(sale) === filter.estado)
    );
  });
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">
            FICHA Y ESTADO DE CUENTA
            {c.demo || process.env.DEMO_INSTANCE === "1" ? " · DEMO" : ""}
          </p>
          <h1>{c.name}</h1>
        </div>
        <div className="toolbar no-print">
          <Link className="button secondary" href="/clientes">
            Volver a clientes
          </Link>
          <PrintButton />
          <a className="button secondary" href={"/api/clientes/" + c.id}>
            Exportar estado CSV
          </a>
        </div>
      </div>
      <section className="card">
        <div className="profile-details">
          <div>
            <small>Teléfono</small>
            {c.phone || "No registrado"}
          </div>
          <div>
            <small>Dirección</small>
            {c.address || "No registrada"}
          </div>
          <div>
            <small>Registrado</small>
            {c.createdAt.toLocaleDateString("es-CL", {
              timeZone: "America/Santiago",
            })}
          </div>
          <div>
            <small>Límite de crédito</small>
            {c.creditLimit === null ? "No configurado" : clp(c.creditLimit)}
          </div>
        </div>
        <p>{c.notes}</p>
        <div className="pos-total">
          <small>Saldo pendiente actual</small>
          <strong>
            {clp(c.sales.reduce((a, s) => a + outstanding(s), 0))}
          </strong>
        </div>
      </section>
      {can(actor.role, "credits:authorize") && (
        <details className="card no-print">
          <summary>Editar ficha y límite</summary>
          <ActionForm action={customerAction}>
            <input type="hidden" name="id" value={c.id} />
            <label>
              Nombre
              <input name="name" required defaultValue={c.name} />
            </label>
            <label>
              Teléfono
              <input name="phone" defaultValue={c.phone} />
            </label>
            <label>
              Dirección
              <input name="address" defaultValue={c.address} />
            </label>
            <label>
              Límite de crédito
              <input
                name="creditLimit"
                type="number"
                min={0}
                defaultValue={c.creditLimit ?? ""}
              />
            </label>
            <label>
              Observaciones
              <textarea name="notes" defaultValue={c.notes} />
            </label>
            <label>
              Estado
              <select name="active" defaultValue={String(c.active)}>
                <option value="true">Activo</option>
                <option value="false">Inactivo</option>
              </select>
            </label>
            <button>Actualizar cliente</button>
          </ActionForm>
        </details>
      )}
      <form className="filters no-print">
        <label>
          Compras desde
          <input name="desde" type="date" defaultValue={filter.desde} />
        </label>
        <label>
          Compras hasta
          <input name="hasta" type="date" defaultValue={filter.hasta} />
        </label>
        <label>
          Estado del voucher
          <select name="estado" defaultValue={filter.estado}>
            <option value="">Todos</option>
            {["PENDIENTE", "PAGO PARCIAL", "PAGADO", "ANULADO"].map((v) => (
              <option key={v}>{v}</option>
            ))}
          </select>
        </label>
        <button>Filtrar vouchers</button>
      </form>
      <VoucherCollection
        customerId={c.id}
        shiftId={shift?.id}
        vouchers={filteredVouchers.map((v) => {
          const sale = c.sales.find((s) => s.id === v.saleId)!;
          return {
            id: v.id,
            number: voucherNumber(v.number),
            original: sale.creditAmount,
            balance: outstanding(sale),
            state: voucherState(sale),
            date: sale.createdAt.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            }),
            due:
              sale.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
              "",
          };
        })}
      />
      <section className="card" id="pagos-fiados">
        <h2>Historial de pagos y recibos</h2>
        {receipts
          .filter((r) =>
            allocations.some(
              (a) =>
                a.receiptId === r.id &&
                filteredVouchers.some((v) => v.id === a.voucherId),
            ),
          )
          .map((r) => (
            <article className="order" key={r.id}>
              <h3>
                <Link href={"/fiados/recibos/" + r.id}>
                  {receiptNumber(r.number)}
                </Link>{" "}
                · {clp(r.amount)}
              </h3>
              <p>
                {r.createdAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}{" "}
                · Recibió{" "}
                {workers.find((w) => w.id === r.actorId)?.name || r.actorId} ·{" "}
                {r.reference}
              </p>
              {allocations
                .filter((a) => a.receiptId === r.id)
                .map((a) => {
                  const payment = c.sales
                      .flatMap((s) => s.customerPayments)
                      .find((p) => p.id === a.customerPaymentId),
                    v = vouchers.find((v) => v.id === a.voucherId);
                  return (
                    <p key={a.id}>
                      {v ? voucherNumber(v.number) : a.voucherId} ·{" "}
                      {payment?.collection?.method} {clp(payment?.amount || 0)}
                      <small>
                        Saldo anterior {clp(a.balanceBefore)} → Saldo posterior{" "}
                        {clp(a.balanceAfter)}
                      </small>
                    </p>
                  );
                })}
            </article>
          ))}
        {!receipts.length && (
          <p>
            Sin recibos agrupados. Los abonos anteriores se conservan en su
            voucher y en el historial individual.
          </p>
        )}
      </section>
      <details className="card">
        <summary>Compras y abonos individuales</summary>
        <h2>Historial completo de compras y pagos</h2>
        {visibleSales.map((s) => {
          const balance = outstanding(s),
            late =
              balance > 0 && s.dueDate && s.dueDate < dateOnly(todayChile());
          return (
            <section className="card" key={s.id}>
              <div className="section-heading">
                <h3>Venta {s.id.slice(-8).toUpperCase()}</h3>
                <span
                  className={
                    late
                      ? "status-badge status-red"
                      : balance
                        ? "status-badge status-orange"
                        : "status-badge status-green"
                  }
                >
                  {late
                    ? "Crédito vencido"
                    : balance
                      ? "Crédito pendiente"
                      : "Sin saldo pendiente"}
                </span>
              </div>
              <p>
                {s.createdAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}{" "}
                · Trabajador {s.shift.user.name} · Autorización de crédito{" "}
                {s.creditAuthorizedById || "No aplica"}
              </p>
              <ul>
                {s.items.map((i) => (
                  <li key={i.id}>
                    {i.quantity} × {i.productName || i.productId} ·{" "}
                    {clp(i.lineTotal ?? i.unitPrice * i.quantity)}
                  </li>
                ))}
              </ul>
              <p>
                Venta {clp(s.total)} · Crédito original {clp(s.creditAmount)} ·
                Saldo {clp(balance)} · Vence{" "}
                {s.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
                  "No aplica"}
              </p>
              <Link href={"/ventas/" + s.id}>Comprobante y detalle</Link>
              {s.customerPayments.map((p) => (
                <div className="order" key={p.id}>
                  Abono {clp(p.amount)} · {p.collection?.method} ·{" "}
                  {p.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                  <small>
                    Recibió {p.actorId} · {p.reference}
                  </small>
                </div>
              ))}
              {balance > 0 &&
                (shift ? (
                  <div className="no-print">
                    <h3>Registrar abono parcial o total</h3>
                    <ActionForm
                      action={customerPaymentAction}
                      label={"Abonar " + s.id}
                    >
                      <input
                        type="hidden"
                        name="requestKey"
                        value={randomUUID()}
                      />
                      <input type="hidden" name="saleId" value={s.id} />
                      <input type="hidden" name="shiftId" value={shift.id} />
                      <div className="form-grid">
                        <label>
                          Monto del abono
                          <input
                            name="amount"
                            type="number"
                            min={1}
                            max={balance}
                            required
                          />
                        </label>
                        <label>
                          Medio del abono
                          <select name="method">
                            {METHODS.map((m) => (
                              <option key={m}>{m}</option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Referencia del abono
                          <input name="reference" maxLength={200} />
                        </label>
                      </div>
                      <label className="check-line">
                        <input type="checkbox" required />
                        Confirmo que recibí este abono
                      </label>
                      <label className="check-line">
                        <input type="checkbox" name="bankVerified" />
                        Verifiqué la aprobación bancaria (para abonos
                        electrónicos)
                      </label>
                      <button>Registrar abono recibido</button>
                    </ActionForm>
                  </div>
                ) : (
                  <p>
                    Abre tu caja en el mismo modo real/demo para recibir un
                    abono.
                  </p>
                ))}
            </section>
          );
        })}
        {!visibleSales.length && (
          <section className="card">
            <p>No hay compras con estos filtros.</p>
          </section>
        )}
      </details>
    </>
  );
}

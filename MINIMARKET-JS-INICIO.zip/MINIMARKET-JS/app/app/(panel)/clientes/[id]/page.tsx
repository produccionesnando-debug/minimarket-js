import Link from "next/link";
import { notFound } from "next/navigation";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { outstanding } from "@/lib/pos";
import { clp, METHODS } from "@/lib/money";
import { dateOnly, todayChile } from "@/lib/dates";
import { ActionForm } from "@/components/action-form";
import { customerAction } from "@/app/catalog-actions";
import { customerPaymentAction } from "@/app/pos-actions";
import { PrintButton } from "@/components/print-button";
export default async function Customer({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const actor = await requireUser();
  const { id } = await params;
  const c = await db.customer.findUnique({
    where: { id },
    include: {
      sales: {
        include: {
          items: true,
          shift: { include: { user: true } },
          returns: true,
          customerPayments: { include: { collection: true } },
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });
  if (!c) notFound();
  const shift = await db.shift.findFirst({
    where: { userId: actor.id, closedAt: null, demo: c.demo },
  });
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">
            FICHA Y ESTADO DE CUENTA
            {c.demo || process.env.DEMO_INSTANCE === "1" ? " · DEMO" : ""}
          </p>
          <h1>{c.name}</h1>
        </div>
        <div className="toolbar no-print">
          <Link className="button secondary" href="/clientes">
            Volver a clientes
          </Link>
          <PrintButton />
          <a className="button secondary" href={"/api/clientes/" + c.id}>
            Exportar estado CSV
          </a>
        </div>
      </div>
      <section className="card">
        <div className="profile-details">
          <div>
            <small>Teléfono</small>
            {c.phone || "No registrado"}
          </div>
          <div>
            <small>Dirección</small>
            {c.address || "No registrada"}
          </div>
          <div>
            <small>Registrado</small>
            {c.createdAt.toLocaleDateString("es-CL", {
              timeZone: "America/Santiago",
            })}
          </div>
          <div>
            <small>Límite de crédito</small>
            {c.creditLimit === null ? "No configurado" : clp(c.creditLimit)}
          </div>
        </div>
        <p>{c.notes}</p>
        <div className="pos-total">
          <small>Saldo pendiente actual</small>
          <strong>
            {clp(c.sales.reduce((a, s) => a + outstanding(s), 0))}
          </strong>
        </div>
      </section>
      {can(actor.role, "credits:authorize") && (
        <details className="card no-print">
          <summary>Editar ficha y límite</summary>
          <ActionForm action={customerAction}>
            <input type="hidden" name="id" value={c.id} />
            <label>
              Nombre
              <input name="name" required defaultValue={c.name} />
            </label>
            <label>
              Teléfono
              <input name="phone" defaultValue={c.phone} />
            </label>
            <label>
              Dirección
              <input name="address" defaultValue={c.address} />
            </label>
            <label>
              Límite de crédito
              <input
                name="creditLimit"
                type="number"
                min={0}
                defaultValue={c.creditLimit ?? ""}
              />
            </label>
            <label>
              Observaciones
              <textarea name="notes" defaultValue={c.notes} />
            </label>
            <label>
              Estado
              <select name="active" defaultValue={String(c.active)}>
                <option value="true">Activo</option>
                <option value="false">Inactivo</option>
              </select>
            </label>
            <button>Actualizar cliente</button>
          </ActionForm>
        </details>
      )}
      <h2>Historial completo de compras y pagos</h2>
      {c.sales.map((s) => {
        const balance = outstanding(s),
          late = balance > 0 && s.dueDate && s.dueDate < dateOnly(todayChile());
        return (
          <section className="card" key={s.id}>
            <div className="section-heading">
              <h3>Venta {s.id.slice(-8).toUpperCase()}</h3>
              <span
                className={
                  late
                    ? "status-badge status-red"
                    : balance
                      ? "status-badge status-orange"
                      : "status-badge status-green"
                }
              >
                {late
                  ? "Crédito vencido"
                  : balance
                    ? "Crédito pendiente"
                    : "Sin saldo pendiente"}
              </span>
            </div>
            <p>
              {s.createdAt.toLocaleString("es-CL", {
                timeZone: "America/Santiago",
              })}{" "}
              · Trabajador {s.shift.user.name} · Autorización de crédito{" "}
              {s.creditAuthorizedById || "No aplica"}
            </p>
            <ul>
              {s.items.map((i) => (
                <li key={i.id}>
                  {i.quantity} × {i.productName || i.productId} ·{" "}
                  {clp(i.lineTotal ?? i.unitPrice * i.quantity)}
                </li>
              ))}
            </ul>
            <p>
              Venta {clp(s.total)} · Crédito original {clp(s.creditAmount)} ·
              Saldo {clp(balance)} · Vence{" "}
              {s.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
                "No aplica"}
            </p>
            <Link href={"/ventas/" + s.id}>Comprobante y detalle</Link>
            {s.customerPayments.map((p) => (
              <div className="order" key={p.id}>
                Abono {clp(p.amount)} · {p.collection?.method} ·{" "}
                {p.createdAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}
                <small>
                  Recibió {p.actorId} · {p.reference}
                </small>
              </div>
            ))}
            {balance > 0 &&
              (shift ? (
                <div className="no-print">
                  <h3>Registrar abono parcial o total</h3>
                  <ActionForm
                    action={customerPaymentAction}
                    label={"Abonar " + s.id}
                  >
                    <input
                      type="hidden"
                      name="requestKey"
                      value={randomUUID()}
                    />
                    <input type="hidden" name="saleId" value={s.id} />
                    <input type="hidden" name="shiftId" value={shift.id} />
                    <div className="form-grid">
                      <label>
                        Monto del abono
                        <input
                          name="amount"
                          type="number"
                          min={1}
                          max={balance}
                          required
                        />
                      </label>
                      <label>
                        Medio del abono
                        <select name="method">
                          {METHODS.map((m) => (
                            <option key={m}>{m}</option>
                          ))}
                        </select>
                      </label>
                      <label>
                        Referencia del abono
                        <input name="reference" maxLength={200} />
                      </label>
                    </div>
                    <label className="check-line">
                      <input type="checkbox" required />
                      Confirmo que recibí este abono
                    </label>
                    <button>Registrar abono recibido</button>
                  </ActionForm>
                </div>
              ) : (
                <p>
                  Abre tu caja en el mismo modo real/demo para recibir un abono.
                </p>
              ))}
          </section>
        );
      })}
      {!c.sales.length && (
        <section className="card">
          <p>Este cliente aún no tiene compras registradas.</p>
        </section>
      )}
    </>
  );
}

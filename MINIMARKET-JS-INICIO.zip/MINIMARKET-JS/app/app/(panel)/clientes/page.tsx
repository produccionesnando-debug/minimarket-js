import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { outstanding } from "@/lib/pos";
import { clp } from "@/lib/money";
import { dateOnly, todayChile } from "@/lib/dates";
import { ActionForm } from "@/components/action-form";
import { customerAction } from "@/app/catalog-actions";
import { PrintButton } from "@/components/print-button";
export default async function Customers({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; demo?: string }>;
}) {
  const actor = await requireUser();
  const p = await searchParams;
  const demo = p.demo === "1";
  const customers = await db.customer.findMany({
    where: {
      demo,
      ...(p.q
        ? { name: { contains: p.q.slice(0, 120), mode: "insensitive" } }
        : {}),
    },
    include: { sales: { include: { returns: true, customerPayments: true } } },
    orderBy: { name: "asc" },
  });
  const balance = customers.reduce(
    (a, c) => a + c.sales.reduce((a, s) => a + outstanding(s), 0),
    0,
  );
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">CRÉDITO PROPIO DEL MINIMARKET</p>
          <h1>Clientes y créditos</h1>
          <p>
            Los abonos reducen deuda y registran cobros, sin crear otra venta.
          </p>
        </div>
        <PrintButton />
      </div>
      <div className="stats">
        <article>
          <small>Clientes en esta consulta</small>
          <strong>{customers.length}</strong>
        </article>
        <article>
          <small>Cuenta por cobrar actual</small>
          <strong>{clp(balance)}</strong>
        </article>
        <article>
          <small>Créditos vencidos</small>
          <strong>
            {customers.reduce(
              (a, c) =>
                a +
                c.sales.filter(
                  (s) =>
                    outstanding(s) > 0 &&
                    s.dueDate &&
                    s.dueDate < dateOnly(todayChile()),
                ).length,
              0,
            )}
          </strong>
        </article>
      </div>
      <form className="filters no-print">
        <label>
          Buscar cliente
          <input name="q" defaultValue={p.q} />
        </label>
        <label>
          Catálogo
          <select name="demo" defaultValue={demo ? "1" : "0"}>
            <option value="0">
              {process.env.DEMO_INSTANCE === "1"
                ? "Esta demostración"
                : "Negocio real"}
            </option>
            <option value="1">Demostración separada</option>
          </select>
        </label>
        <button>Buscar clientes</button>
      </form>
      <section className="card table-wrap">
        <h2>Clientes registrados y saldos</h2>
        <table>
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Límite</th>
              <th>Saldo pendiente</th>
              <th>Estado</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id}>
                <td>
                  {c.name}
                  <small>{c.phone}</small>
                </td>
                <td>
                  {c.creditLimit === null
                    ? "Sin límite configurado"
                    : clp(c.creditLimit)}
                </td>
                <td>{clp(c.sales.reduce((a, s) => a + outstanding(s), 0))}</td>
                <td>{c.active ? "Activo" : "Inactivo"}</td>
                <td>
                  <Link href={"/clientes/" + c.id}>
                    Ficha y estado de cuenta
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!customers.length && <p>No hay clientes en esta consulta.</p>}
      </section>
      {can(actor.role, "credits:authorize") && (
        <section className="card no-print">
          <h2>Registrar cliente</h2>
          <ActionForm action={customerAction} label="Registrar cliente">
            <div className="form-grid">
              <label>
                Nombre del cliente
                <input name="name" required minLength={2} />
              </label>
              <label>
                Teléfono opcional
                <input name="phone" type="tel" />
              </label>
              <label>
                Dirección opcional
                <input name="address" />
              </label>
              <label>
                Límite de crédito CLP · opcional
                <input name="creditLimit" type="number" min={0} />
              </label>
            </div>
            <label>
              Observaciones del cliente
              <textarea name="notes" />
            </label>
            {process.env.DEMO_INSTANCE !== "1" && (
              <label className="check-line">
                <input type="checkbox" name="demo" defaultChecked={demo} />
                Cliente de demostración
              </label>
            )}
            <button>Guardar cliente</button>
          </ActionForm>
        </section>
      )}
    </>
  );
}

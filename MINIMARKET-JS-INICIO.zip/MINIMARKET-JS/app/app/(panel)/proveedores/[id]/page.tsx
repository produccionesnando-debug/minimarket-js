import { CycleForm } from "@/components/cycle-form";
import { savePaymentRule } from "@/app/purchase-actions";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { CONTACT_ROLES, SCHEDULE_LABELS } from "@/lib/supplier-validation";
import { STATUS_LABELS } from "@/lib/order-status";
import { clp } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import { SupplierFields } from "@/components/supplier-fields";
import { ContactFields } from "@/components/contact-fields";
import {
  saveSupplierProfile,
  toggleSupplier,
  saveContact,
  deleteContact,
} from "@/app/phase1-actions";
export default async function SupplierDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ creado?: string }>;
}) {
  const user = await requireUser();
  const { id } = await params;
  const query = await searchParams;
  const editable = can(user.role, "suppliers:write");
  const products = await db.product.findMany({
    select: { id: true, name: true, brand: true, stock: true, minimum: true },
    orderBy: { name: "asc" },
  });
  if (id === "nuevo")
    return (
      <>
        <Link href="/proveedores">← Proveedores</Link>
        <h1>Agregar proveedor</h1>
        {editable ? (
          <section className="card">
            <ActionForm
              action={saveSupplierProfile}
              label="Ficha del proveedor"
            >
              <SupplierFields products={products} />
            </ActionForm>
          </section>
        ) : (
          <p role="alert" className="alert">
            No tienes permisos para agregar proveedores.
          </p>
        )}
      </>
    );
  const supplier = await db.supplier.findUnique({
    where: { id },
    include: {
      products: true,
      contacts: { orderBy: { name: "asc" } },
      cycles: { orderBy: { label: "asc" } },
      orders: { orderBy: { date: "desc" }, take: 30 },
    },
  });
  if (!supplier) notFound();
  const lastConfirmed = await db.supplierOrder.findFirst({
    where: {
      supplierId: supplier.id,
      structured: true,
      status: { in: ["CONFIRMADO", "RECIBIDO"] },
    },
    orderBy: [{ confirmedAt: "desc" }, { date: "desc" }],
  });
  return (
    <>
      <Link href="/proveedores">← Proveedores</Link>
      <div className="page-heading">
        <div>
          <h1>{supplier.name}</h1>
          <p>
            {supplier.category || "Sin categoría"} ·{" "}
            {SCHEDULE_LABELS[supplier.scheduleMode]}
          </p>
        </div>
        <span className={supplier.active ? "badge" : "badge warning"}>
          {supplier.active ? "Activo" : "Inactivo"}
        </span>
      </div>
      {query.creado && (
        <p role="status" className="success">
          Proveedor creado. Puedes agregar sus contactos a continuación.
        </p>
      )}
      {!supplier.active && (
        <p className="alert">
          Proveedor inactivo. Sus pedidos y contactos históricos se conservan;
          no se generan recordatorios recurrentes ni se pueden crear pedidos
          nuevos.
        </p>
      )}
      <section className="card">
        <h2>Ficha del proveedor</h2>
        {editable && supplier.active ? (
          <ActionForm action={saveSupplierProfile} label="Ficha del proveedor">
            <SupplierFields supplier={supplier} products={products} />
          </ActionForm>
        ) : (
          <dl className="profile-details">
            {[
              ["Teléfono", supplier.phone],
              ["WhatsApp", supplier.whatsapp],
              ["Correo", supplier.email],
              ["Productos", supplier.productsDescription],
              ["Condiciones de pago", supplier.paymentTerms],
              ["Observaciones", supplier.notes],
              [
                "Días de pedido",
                supplier.orderDays
                  .map(
                    (d) =>
                      [
                        "Lunes",
                        "Martes",
                        "Miércoles",
                        "Jueves",
                        "Viernes",
                        "Sábado",
                        "Domingo",
                      ][d - 1],
                  )
                  .join(", "),
              ],
              [
                "Días de entrega",
                supplier.deliveryDays
                  .map(
                    (d) =>
                      [
                        "Lunes",
                        "Martes",
                        "Miércoles",
                        "Jueves",
                        "Viernes",
                        "Sábado",
                        "Domingo",
                      ][d - 1],
                  )
                  .join(", "),
              ],
              [
                "Productos asociados",
                supplier.products.map((p) => p.name).join(", "),
              ],
            ].map(([k, v]) => (
              <div key={k}>
                <dt>{k}</dt>
                <dd>{v || "Sin registrar"}</dd>
              </div>
            ))}
          </dl>
        )}
      </section>
      {editable && supplier.active && (
        <section className="card">
          <h2>Pedidos por productos</h2>
          <Link
            className="button"
            href={`/pedidos/nuevo?proveedor=${supplier.id}`}
          >
            Crear primer pedido o borrador
          </Link>
          {lastConfirmed && (
            <Link
              className="button secondary"
              href={`/pedidos/nuevo?proveedor=${supplier.id}&copiar=${lastConfirmed.id}`}
            >
              Copiar último pedido confirmado
            </Link>
          )}
          <p>
            Consulta el historial para reutilizar un pedido confirmado. Los
            productos, precios y stock reales deben ser ingresados por
            administración.
          </p>
        </section>
      )}
      <section className="card">
        <h2>Ciclos inteligentes</h2>
        <p>
          Los ciclos independientes producen pedidos distintos. Las alternativas
          del mismo ciclo permiten una sola compra por período.
        </p>
        {supplier.cycles?.map((c) => (
          <details key={c.id}>
            <summary>
              {c.label} · {c.active ? "Activo" : "Inactivo"}
            </summary>
            {editable && supplier.active ? (
              <CycleForm cycle={c} supplierId={supplier.id} />
            ) : (
              <p>{c.label}</p>
            )}
          </details>
        ))}
        {editable && supplier.active && (
          <details>
            <summary>+ Agregar ciclo</summary>
            <CycleForm supplierId={supplier.id} />
          </details>
        )}
      </section>
      {editable && supplier.active && (
        <section className="card">
          <h2>Regla de vencimiento y pagos</h2>
          <ActionForm action={savePaymentRule}>
            <input name="supplierId" type="hidden" value={supplier.id} />
            <div className="form-grid">
              <label>
                Regla de pago
                <select name="paymentRule" defaultValue={supplier.paymentRule}>
                  <option value="PENDIENTE">Por confirmar</option>
                  <option value="CONTADO">Contado</option>
                  <option value="DAYS">
                    Días desde recepción y facturación
                  </option>
                  <option value="NEXT_WEEKDAY">
                    Siguiente día semanal acordado
                  </option>
                </select>
              </label>
              <label>
                Plazo en días
                <input
                  name="paymentDays"
                  type="number"
                  min={0}
                  defaultValue={supplier.paymentDays ?? ""}
                />
              </label>
              <label>
                Cómputo del plazo
                <select
                  name="paymentDayCount"
                  defaultValue={supplier.paymentDayCount}
                >
                  <option value="PENDIENTE">Por confirmar</option>
                  <option value="CORRIDOS">Días corridos</option>
                  <option value="HABILES">Lunes a viernes</option>
                </select>
              </label>
              <label>
                Día semanal de pago
                <select
                  name="paymentWeekday"
                  defaultValue={supplier.paymentWeekday ?? ""}
                >
                  <option value="">Sin definir</option>
                  {[
                    "Lunes",
                    "Martes",
                    "Miércoles",
                    "Jueves",
                    "Viernes",
                    "Sábado",
                    "Domingo",
                  ].map((d, i) => (
                    <option key={d} value={i + 1}>
                      {d}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <label className="check-line">
              <input
                name="preferCash"
                type="checkbox"
                defaultChecked={supplier.preferCash}
              />
              Efectivo habitual (no obligatorio)
            </label>
            <button>Guardar regla de pago</button>
          </ActionForm>
          <p>
            Los cambios se aplican a facturas nuevas. No inventan saldos ni
            ejecutan pagos.
          </p>
        </section>
      )}
      <section className="card">
        <h2>Contactos del proveedor</h2>
        <p>
          Separa vendedores, transportistas, cobranza y receptores de
          comprobantes. No se envían mensajes desde esta ficha.
        </p>
        {!supplier.contacts.length && <p>No hay contactos registrados.</p>}
        {supplier.contacts.map((c) => (
          <article className="contact-card" key={c.id}>
            <h3>
              {c.name} <span className="badge">{CONTACT_ROLES[c.role]}</span>
            </h3>
            <p>
              {[c.phone, c.whatsapp, c.email].filter(Boolean).join(" · ") ||
                "Sin datos de contacto"}
            </p>
            {c.notes && <p>{c.notes}</p>}
            {editable && supplier.active && (
              <details>
                <summary>Editar contacto</summary>
                <ActionForm
                  action={saveContact}
                  label={`Editar contacto ${c.name}`}
                >
                  <ContactFields
                    contact={c}
                    supplierId={supplier.id}
                    version={supplier.version}
                  />
                </ActionForm>
                <ActionForm
                  action={deleteContact}
                  label={`Eliminar contacto ${c.name}`}
                >
                  <input type="hidden" name="supplierId" value={supplier.id} />
                  <input
                    type="hidden"
                    name="version"
                    value={supplier.version}
                  />
                  <input type="hidden" name="contactId" value={c.id} />
                  <button className="secondary">Eliminar contacto</button>
                </ActionForm>
              </details>
            )}
          </article>
        ))}
        {editable && supplier.active && (
          <details open>
            <summary>+ Agregar contacto</summary>
            <ActionForm action={saveContact} label="Agregar contacto">
              <ContactFields
                supplierId={supplier.id}
                version={supplier.version}
              />
            </ActionForm>
          </details>
        )}
      </section>
      <section className="card table-wrap">
        <h2>Historial de pedidos</h2>
        <p>
          Últimos 30 pedidos. El historial completo por fecha permanece
          disponible en el calendario.
        </p>
        <table>
          <thead>
            <tr>
              <th>Entrega</th>
              <th>Detalle</th>
              <th>Estimado</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {supplier.orders.map((o) => (
              <tr key={o.id}>
                <td>
                  <Link
                    href={`/calendario?vista=dia&fecha=${o.date.toISOString().slice(0, 10)}#order-${o.id}`}
                  >
                    {o.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
                  </Link>
                </td>
                <td className="wrap-text">
                  <Link href={`/pedidos/${o.id}`}>{o.detail}</Link>
                </td>
                <td>{clp(o.budget)}</td>
                <td>{STATUS_LABELS[o.status] || o.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!supplier.orders.length && <p>Sin pedidos anteriores.</p>}
      </section>
      {editable && (
        <section className="card">
          <h2>Estado del proveedor</h2>
          <p>
            La desactivación conserva los datos y el historial. Puedes reactivar
            al proveedor posteriormente.
          </p>
          <ActionForm action={toggleSupplier}>
            <input name="id" type="hidden" value={supplier.id} />
            <input name="version" type="hidden" value={supplier.version} />
            <label className="check-line">
              <input type="checkbox" required />
              Confirmo que deseo {supplier.active
                ? "desactivar"
                : "reactivar"}{" "}
              este proveedor.
            </label>
            <button className="secondary">
              {supplier.active ? "Desactivar proveedor" : "Reactivar proveedor"}
            </button>
          </ActionForm>
        </section>
      )}
    </>
  );
}

import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { SCHEDULE_LABELS } from "@/lib/supplier-validation";
export default async function Suppliers({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; estado?: string }>;
}) {
  const user = await requireUser();
  const p = await searchParams;
  const q = (p.q || "").slice(0, 150);
  const state = ["todos", "inactivos"].includes(p.estado || "")
    ? p.estado
    : "activos";
  const suppliers = await db.supplier.findMany({
    where: {
      ...(state === "todos" ? {} : { active: state !== "inactivos" }),
      ...(q
        ? {
            OR: [
              { name: { contains: q, mode: "insensitive" as const } },
              { category: { contains: q, mode: "insensitive" as const } },
            ],
          }
        : {}),
    },
    include: { _count: { select: { contacts: true, orders: true } } },
    orderBy: { name: "asc" },
  });
  return (
    <>
      <p className="eyebrow">DIRECTORIO Y PLANIFICACIÓN</p>
      <div className="page-heading">
        <div>
          <h1>Proveedores</h1>
          <p>
            Contactos, calendarios y condiciones de compra, en un solo lugar.
          </p>
        </div>
        {can(user.role, "suppliers:write") && (
          <Link className="button" href="/proveedores/nuevo">
            + Agregar proveedor
          </Link>
        )}
      </div>
      <form className="filters">
        <label>
          Buscar proveedor
          <input name="q" defaultValue={q} placeholder="Nombre o categoría" />
        </label>
        <label>
          Estado
          <select name="estado" defaultValue={state}>
            <option value="activos">Activos</option>
            <option value="inactivos">Inactivos</option>
            <option value="todos">Todos</option>
          </select>
        </label>
        <button className="secondary">Buscar</button>
      </form>
      <section className="card table-wrap">
        <h2>Directorio de proveedores</h2>
        <table>
          <thead>
            <tr>
              <th>Proveedor</th>
              <th>Planificación</th>
              <th>Contactos</th>
              <th>Estado</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {suppliers.map((s) => (
              <tr key={s.id}>
                <td>
                  <strong>{s.name}</strong>
                  <small>{s.category || "Sin categoría"}</small>
                </td>
                <td>{SCHEDULE_LABELS[s.scheduleMode]}</td>
                <td>{s._count.contacts}</td>
                <td>
                  <span className={s.active ? "badge" : "badge warning"}>
                    {s.active ? "Activo" : "Inactivo"}
                  </span>
                </td>
                <td>
                  <Link href={`/proveedores/${s.id}`}>Ver ficha →</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!suppliers.length && <p>No hay proveedores para estos filtros.</p>}
      </section>
    </>
  );
}

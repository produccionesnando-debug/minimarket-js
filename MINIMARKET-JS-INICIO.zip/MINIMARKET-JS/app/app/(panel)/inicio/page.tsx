import Link from "next/link";
import {
  ShoppingCart,
  Wallet,
  Package,
  Receipt,
  NotebookPen,
  ChartPie,
  CalendarDays,
  Plus,
  ChevronLeft,
  ChevronRight,
  Truck,
  ClipboardList,
  PackagePlus,
  UserRoundPlus,
  ChartNoAxesCombined,
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
} from "lucide-react";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { getCalendarData, type CalendarParams } from "@/lib/calendar";
import {
  todayChile,
  dateOnly,
  isoDay,
  calendarRange,
  addDays,
  chileDayStart,
  adjacentDate,
} from "@/lib/dates";
import { clp } from "@/lib/money";
import { ORDER_STATUSES } from "@/lib/order-status";
import { expenseScope } from "@/lib/expenses";
import { Card, Metric, EmptyState, StatusBadge } from "@/components/ui";
import { CalendarBoard } from "@/components/calendar-board";
import { SalesChart, ExpensesChart } from "@/components/dashboard-charts";
export default async function Dashboard({
  searchParams,
}: {
  searchParams: Promise<CalendarParams & { ultimos?: string }>;
}) {
  const user = await requireUser();
  const p = await searchParams;
  const c = await getCalendarData(user, p);
  const manage = can(user.role, "purchases:write"),
    finance = can(user.role, "finance:write");
  const week = calendarRange(c.today, "semana");
  const start = chileDayStart(isoDay(week.from)),
    until = chileDayStart(isoDay(week.until));
  const own = can(user.role, "stats:read")
    ? {}
    : { shift: { userId: user.id } };
  const [sales, prior, expenseGroups, recent, shift] = await Promise.all([
    db.sale.findMany({
      where: { demo: false, createdAt: { gte: start, lt: until }, ...own },
      select: { total: true, createdAt: true },
    }),
    db.sale.aggregate({
      where: {
        demo: false,
        createdAt: {
          gte: chileDayStart(isoDay(addDays(week.from, -7))),
          lt: start,
        },
        ...own,
      },
      _sum: { total: true },
      _count: true,
    }),
    db.expense.groupBy({
      by: ["category"],
      where: {
        demo: false,
        kind: "OPERATIVO",
        status: { not: "ANULADO" },
        occurredAt: {
          gte: dateOnly(c.today.slice(0, 7) + "-01"),
          lt: addDays(dateOnly(c.today), 1),
        },
        ...expenseScope(user),
      },
      _sum: { amount: true },
      orderBy: { _sum: { amount: "desc" } },
    }),
    db.supplierOrder.findMany({
      where: {
        supplier: { demo: false },
        ...(ORDER_STATUSES.includes(
          p.ultimos as (typeof ORDER_STATUSES)[number],
        )
          ? { status: p.ultimos }
          : {}),
      },
      include: { supplier: true },
      orderBy: [
        { orderDate: { sort: "desc", nulls: "last" } },
        { date: "desc" },
        { id: "desc" },
      ],
      take: 5,
    }),
    db.shift.findFirst({
      where: { userId: user.id, closedAt: null },
      select: { id: true },
    }),
  ]);
  const chartSales = week.days.map((d) => ({
    label: d.toLocaleDateString("es-CL", { weekday: "short", timeZone: "UTC" }),
    value: sales
      .filter((s) => todayChile(s.createdAt) === isoDay(d))
      .reduce((a, s) => a + s.total, 0),
    count: sales.filter((s) => todayChile(s.createdAt) === isoDay(d)).length,
  }));
  const chartExpenses = expenseGroups.map((e) => ({
    label: e.category || "Sin categoría",
    value: e._sum.amount || 0,
  }));
  const weekTotal = sales.reduce((s, v) => s + v.total, 0);
  const comparable = sales.length > 0 && prior._count > 0 && !!prior._sum.total;
  const change = comparable
    ? Math.round(((weekTotal - prior._sum.total!) / prior._sum.total!) * 100)
    : null;
  const pending = c.orders.filter(
    (o) => !["RECIBIDO", "CANCELADO"].includes(o.status),
  );
  const estimated = pending.reduce((sum, o) => sum + o.budget, 0);
  const incomplete = pending.some((o) => o.structured && !o.estimatedComplete);
  const url = (day: string, view = c.view) =>
    `/inicio?vista=${view}&fecha=${day}&proveedor=${p.proveedor || ""}&estado=${p.estado || ""}`;
  const quick = [
    {
      label: "Nueva venta",
      href: shift ? "/ventas" : "/caja#abrir-caja",
      icon: ShoppingCart,
      tone: "green",
    },
    {
      label: "Nuevo pedido",
      href: "/pedidos/nuevo",
      icon: ClipboardList,
      tone: "blue",
      hide: !manage,
    },
    {
      label: "Registrar gasto",
      href: "/gastos#registrar-gasto",
      icon: NotebookPen,
      tone: "red",
    },
    {
      label: "+ Agregar proveedor",
      href: "/proveedores/nuevo",
      icon: UserRoundPlus,
      tone: "purple",
      hide: !can(user.role, "suppliers:write"),
    },
    {
      label: "Nuevo producto",
      href: "/inventario#agregar-producto",
      icon: PackagePlus,
      tone: "orange",
      hide: user.role !== "ADMIN",
    },
    {
      label: shift ? "Ver caja abierta" : "Abrir caja",
      href: "/caja",
      icon: Wallet,
      tone: "teal",
    },
  ];
  return (
    <>
      <div className="page-heading dashboard-heading">
        <div>
          <p className="eyebrow">TU NEGOCIO, EN ORDEN</p>
          <h1>Panel principal</h1>
          <p>
            {dateOnly(c.today).toLocaleDateString("es-CL", {
              weekday: "long",
              day: "numeric",
              month: "long",
              year: "numeric",
              timeZone: "UTC",
            })}{" "}
            <span className="heading-divider">·</span> Tu operación de un
            vistazo
          </p>
        </div>
        {manage && (
          <Link href="/pedidos/nuevo" className="button">
            <Plus size={17} />
            Nuevo pedido
          </Link>
        )}
      </div>
      <div className="metric-grid dashboard-metrics">
        <Metric
          label="Ventas del día"
          value={clp(c.summary.sales)}
          hint={
            can(user.role, "stats:read")
              ? "Ventas registradas hoy"
              : "Ventas de tus cajas"
          }
          icon={ShoppingCart}
          tone="green"
        />
        <Metric
          label="Efectivo en caja"
          value={clp(c.summary.cash)}
          hint="Esperado en cajas abiertas"
          icon={Wallet}
        />
        <Metric
          label="Compras programadas"
          value={
            manage
              ? `${clp(estimated)}${incomplete ? " + pendientes" : ""}`
              : "Acceso limitado"
          }
          hint="Pedidos registrados del período"
          icon={Package}
          tone="orange"
        />
        <Metric
          label="Cuentas por pagar"
          value={
            c.summary.payable === null
              ? "Acceso limitado"
              : clp(c.summary.payable)
          }
          hint="Saldo actual con proveedores"
          icon={Receipt}
          tone="purple"
        />
        <Metric
          label="Gastos del día"
          value={clp(c.summary.expenses)}
          hint="Operativos, sin pagos duplicados"
          icon={NotebookPen}
          tone="red"
        />
        <Metric
          label="Presupuesto disponible"
          value={
            c.summary.available === null
              ? "Por configurar"
              : clp(c.summary.available)
          }
          hint="Fondos menos deuda y reservas"
          icon={ChartPie}
          tone="teal"
        />
      </div>
      <div className="dashboard-main">
        <Card
          className="dashboard-calendar"
          title="Calendario de proveedores"
          icon={CalendarDays}
          action={
            <Link className="text-link" href="/calendario">
              Ver calendario
              <ArrowUpRight size={14} />
            </Link>
          }
        >
          <p className="section-subtitle">
            Pedidos, entregas y pagos de tu agenda.
          </p>
          <div className="calendar-toolbar">
            <div className="calendar-period">
              <Link
                className="icon-button"
                aria-label="Período anterior"
                href={url(adjacentDate(c.anchor, c.view, -1))}
              >
                <ChevronLeft size={18} />
              </Link>
              <strong>{c.title}</strong>
              <Link
                className="icon-button"
                aria-label="Período siguiente"
                href={url(adjacentDate(c.anchor, c.view, 1))}
              >
                <ChevronRight size={18} />
              </Link>
              <Link
                className="button secondary small-button"
                href={url(c.today)}
              >
                Hoy
              </Link>
            </div>
            <div className="view-tabs" aria-label="Vista del calendario">
              {(["dia", "semana", "mes"] as const).map((v) => (
                <Link
                  key={v}
                  href={url(c.anchor, v)}
                  aria-current={c.view === v ? "page" : undefined}
                >
                  {v === "dia"
                    ? "Diaria"
                    : v === "semana"
                      ? "Semanal"
                      : "Mensual"}
                </Link>
              ))}
            </div>
          </div>
          <CalendarBoard
            days={c.days.map(isoDay)}
            events={c.events}
            view={c.view}
            today={c.today}
            basePath="/inicio"
            supplier={p.proveedor}
            status={p.estado}
          />
          <div className="legend">
            <span>
              <i className="legend-dot green" />
              Pedidos
            </span>
            <span>
              <i className="legend-dot blue" />
              Entregas
            </span>
            <span>
              <i className="legend-dot orange" />
              Pagos próximos
            </span>
            <span>
              <i className="legend-dot red" />
              Pagos vencidos
            </span>
          </div>
        </Card>
        <div className="dashboard-side">
          <Card title="Acciones rápidas" icon={Plus}>
            <div className="quick-actions">
              {quick
                .filter((a) => !a.hide)
                .map((a) => (
                  <Link
                    className={`quick-action quick-${a.tone}`}
                    href={a.href}
                    key={a.label}
                  >
                    <a.icon size={25} aria-hidden="true" />
                    <span>{a.label}</span>
                  </Link>
                ))}
            </div>
          </Card>
          <Card className="delivery-card">
            <div className="delivery-title">
              <span className="delivery-logo">P</span>
              <h2>PedidosYa</h2>
              <span className="demo-pill">Modo demostración</span>
            </div>
            <p>
              Prueba la preparación y los estados de pedidos con datos
              ficticios.
            </p>
            <Link href="/pedidosya" className="button delivery-button">
              Ver pedidos de prueba
              <ArrowUpRight size={16} />
            </Link>
            <ul>
              <li>
                <CheckCircle2 size={17} />
                Estados y preparación
              </li>
              <li>
                <CheckCircle2 size={17} />
                Cancelaciones auditadas
              </li>
              <li>
                <AlertTriangle size={17} />
                Sin conexión con PedidosYa
              </li>
            </ul>
            <div className="delivery-illustration">
              <Truck size={60} strokeWidth={1.3} aria-hidden="true" />
              <span>Integración oficial pendiente</span>
            </div>
          </Card>
        </div>
      </div>
      <div className="dashboard-bottom">
        <Card
          title="Últimos pedidos"
          icon={ClipboardList}
          action={
            <Link className="small-link" href="/pedidos">
              Ver todos
            </Link>
          }
        >
          <form className="inline-filter">
            <label>
              Filtrar pedidos recientes
              <select name="ultimos" defaultValue={p.ultimos || ""}>
                <option value="">Todos los estados</option>
                {ORDER_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s.toLowerCase()}
                  </option>
                ))}
              </select>
            </label>
            <button className="secondary small-button">Filtrar</button>
          </form>
          {recent.map((o) => (
            <Link key={o.id} href={`/pedidos/${o.id}`} className="recent-order">
              <span className="supplier-initial">
                {o.supplier.name.slice(0, 1)}
              </span>
              <div>
                <strong>{o.supplier.name}</strong>
                <small>Pedido N.º {o.id.slice(-8).toUpperCase()}</small>
                <small>
                  {(o.orderDate || o.date).toLocaleDateString("es-CL", {
                    timeZone: "UTC",
                  })}
                </small>
              </div>
              <div className="order-meta">
                <StatusBadge status={o.status} />
                <small>
                  {o.structured && !o.estimatedComplete
                    ? `${clp(o.budget)} + pendientes`
                    : clp(o.budget)}
                </small>
              </div>
            </Link>
          ))}
          {!recent.length && (
            <EmptyState
              title="Sin pedidos registrados"
              description="Tus pedidos recientes se mostrarán aquí."
            />
          )}
        </Card>
        <Card
          title="Stock bajo"
          icon={AlertTriangle}
          action={
            <Link className="small-link" href="/inventario">
              Ver todos
            </Link>
          }
        >
          {c.lowStock.slice(0, 5).map((product) => (
            <div key={product.id} className="low-stock-item">
              <span
                className={`stock-symbol ${product.stock === 0 ? "urgent" : ""}`}
              >
                <Package size={20} />
              </span>
              <div>
                <strong>{product.name}</strong>
                <small>
                  {product.suppliers.map((s) => s.name).join(", ") ||
                    "Proveedor sin asociar"}
                </small>
                <span
                  className={
                    product.stock === 0 ? "stock-urgent" : "stock-warning"
                  }
                >
                  {product.unitType === "PESO"
                    ? product.stockGrams / 1000
                    : product.stock}{" "}
                  {product.unitType === "PESO" ? "kg" : "unidades"} · mín.{" "}
                  {product.minimum} ·{" "}
                  {product.stock === 0 ? "Agotado" : "Reponer"}
                </span>
                <small>
                  {product.unitType.replaceAll("_", " ")} {product.flavor}{" "}
                  {product.presentation}
                </small>
                {manage &&
                  (product.suppliers[0] ? (
                    <Link
                      href={`/pedidos/nuevo?proveedor=${product.suppliers[0].id}&producto=${product.id}`}
                      className="text-link"
                    >
                      Preparar reposición
                      <ChevronRight size={13} />
                    </Link>
                  ) : (
                    <Link href="/proveedores" className="text-link">
                      Asociar proveedor
                      <ChevronRight size={13} />
                    </Link>
                  ))}
              </div>
            </div>
          ))}
          {!c.lowStock.length && (
            <EmptyState
              title="Sin alertas de stock"
              description="No hay productos reales bajo el mínimo registrado."
            />
          )}
        </Card>
        <Card
          title="Ventas de la semana"
          icon={ChartNoAxesCombined}
          action={
            can(user.role, "stats:read") ? (
              <Link className="small-link" href="/estadisticas#ventas">
                Ver informe
              </Link>
            ) : undefined
          }
        >
          <p className="section-subtitle">
            Semana actual ·{" "}
            {can(user.role, "stats:read") ? "Todo el negocio" : "Tus cajas"}
          </p>
          <SalesChart data={chartSales} />
          <div className="chart-summary">
            <div>
              <small>Total semanal</small>
              <strong>{clp(weekTotal)}</strong>
              {change !== null && (
                <small className={change >= 0 ? "positive" : "negative"}>
                  {change > 0 ? "+" : ""}
                  {change}% vs. semana anterior
                </small>
              )}
            </div>
            <div>
              <small>Promedio diario</small>
              <strong>{clp(Math.round(weekTotal / 7))}</strong>
              <small>7 días calendario</small>
            </div>
          </div>
        </Card>
        <Card
          title="Gastos por categoría"
          icon={ChartPie}
          action={
            can(user.role, "stats:read") ? (
              <Link className="small-link" href="/estadisticas#gastos">
                Ver informe
              </Link>
            ) : undefined
          }
        >
          <p className="section-subtitle">
            Mes actual ·{" "}
            {can(user.role, "expenses:readAll")
              ? "Todo el negocio"
              : "Tus gastos"}
          </p>
          <ExpensesChart data={chartExpenses} />
        </Card>
      </div>
      {c.summary.available === null && finance && (
        <p className="help budget-help">
          <AlertTriangle size={15} />
          El presupuesto requiere fondos y reservas confirmados.{" "}
          <Link href="/presupuesto">Revisar presupuesto</Link>
        </p>
      )}
    </>
  );
}

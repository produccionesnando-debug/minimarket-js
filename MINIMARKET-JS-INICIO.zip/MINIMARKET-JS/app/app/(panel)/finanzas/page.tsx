import Link from "next/link";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { todayChile } from "@/lib/dates";
import { clp, METHODS } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import { invoice, payment } from "@/app/purchase-actions";
export default async function Finance({
  searchParams,
}: {
  searchParams: Promise<{ proveedor?: string; pedido?: string }>;
}) {
  const u = await requireUser();
  if (!can(u.role, "finance:write"))
    return (
      <section className="card">
        <h1>Acceso restringido</h1>
        <p>
          Finanzas de proveedores está reservada a administración y supervisión.
        </p>
      </section>
    );
  const p = await searchParams;
  const [invoices, suppliers, banks, shifts] = await Promise.all([
    db.purchaseInvoice.findMany({
      where: { supplier: { demo: false } },
      include: { supplier: true, payments: true },
      orderBy: { createdAt: "desc" },
    }),
    db.supplier.findMany({ where: { demo: false }, orderBy: { name: "asc" } }),
    db.bankAccount.findMany({ where: { active: true, demo: false } }),
    db.shift.findMany({
      where: { closedAt: null, demo: false },
      include: { user: true },
    }),
  ]);
  const total = invoices.reduce((a, i) => a + i.amount, 0);
  const paid = invoices.reduce(
    (a, i) => a + i.payments.reduce((b, v) => b + v.amount, 0),
    0,
  );
  return (
    <>
      <p className="eyebrow">COMPRAS Y PAGOS REGISTRADOS</p>
      <h1>Finanzas de proveedores</h1>
      <p>
        Registros internos. No ejecuta pagos bancarios ni transferencias. El
        pago de una factura reduce su saldo y nunca crea otra compra.
      </p>
      <div className="stats">
        <article>
          <small>Facturas registradas</small>
          <strong>{clp(total)}</strong>
        </article>
        <article>
          <small>Pagos registrados</small>
          <strong>{clp(paid)}</strong>
        </article>
        <article>
          <small>Saldo pendiente</small>
          <strong>{clp(total - paid)}</strong>
        </article>
      </div>
      <section className="card">
        <h2>Registrar factura o documento de compra</h2>
        <p>
          No crea existencias. Registra primero la recepción del pedido para
          actualizar inventario. El vencimiento se calcula desde la fecha
          posterior entre recepción y facturación cuando la regla está completa.
        </p>
        <ActionForm action={invoice} label="Registrar factura">
          <div className="form-grid">
            <label>
              Proveedor de la factura
              <select name="supplierId" required defaultValue={p.proveedor}>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Número del documento
              <input name="reference" required maxLength={100} />
            </label>
            <label>
              Pedido recibido (opcional)
              <input name="orderId" defaultValue={p.pedido || ""} />
            </label>
            <label>
              Fecha de facturación
              <input
                name="issuedAt"
                type="date"
                defaultValue={todayChile()}
                required
              />
            </label>
            <label>
              Fecha de recepción
              <input
                name="receivedAt"
                type="date"
                defaultValue={todayChile()}
                required
              />
            </label>
            <label>
              Vencimiento acordado (opcional)
              <input name="dueDate" type="date" />
            </label>
            <label>
              Monto total CLP
              <input
                name="amount"
                type="number"
                min={1}
                max={1000000000}
                required
              />
            </label>
          </div>
          <label>
            Observaciones
            <textarea name="notes" maxLength={2000} />
          </label>
          <button>Registrar factura</button>
        </ActionForm>
      </section>
      <h2>Facturas y saldos</h2>
      {!invoices.length && (
        <section className="card">
          <p>
            No hay facturas reales registradas. No se han inventado saldos
            iniciales.
          </p>
        </section>
      )}
      {invoices.map((i) => {
        const balance = i.amount - i.payments.reduce((a, p) => a + p.amount, 0);
        return (
          <section className="card" key={i.id}>
            <div className="section-heading">
              <h2>
                {i.supplier.name} · {i.reference}
              </h2>
              <span className={balance ? "badge warning" : "badge"}>
                {balance ? `Pendiente ${clp(balance)}` : "Saldada"}
              </span>
            </div>
            <p>
              Total {clp(i.amount)} · Vencimiento{" "}
              {i.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
                "Por confirmar"}
            </p>
            {i.orderId && (
              <Link href={`/pedidos/${i.orderId}`}>
                Abrir pedido recibido →
              </Link>
            )}
            <table>
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Medio</th>
                  <th>Monto</th>
                  <th>Referencia</th>
                </tr>
              </thead>
              <tbody>
                {i.payments.map((v) => (
                  <tr key={v.id}>
                    <td>
                      {v.date.toLocaleDateString("es-CL", { timeZone: "UTC" })}
                    </td>
                    <td>{v.method}</td>
                    <td>{clp(v.amount)}</td>
                    <td>{v.reference || "Sin referencia"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {balance > 0 && (
              <details>
                <summary>Registrar pago parcial o total</summary>
                <ActionForm
                  action={payment}
                  label={`Pago factura ${i.reference}`}
                >
                  <input name="invoiceId" type="hidden" value={i.id} />
                  <input name="requestKey" type="hidden" value={randomUUID()} />
                  <div className="form-grid">
                    <label>
                      Monto del pago CLP
                      <input
                        name="amount"
                        type="number"
                        min={1}
                        max={balance}
                        required
                      />
                    </label>
                    <label>
                      Medio de pago
                      <select
                        name="method"
                        defaultValue={
                          i.supplier.preferCash ? "EFECTIVO" : "TRANSFERENCIA"
                        }
                      >
                        {METHODS.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Fecha del pago
                      <input
                        name="date"
                        type="date"
                        defaultValue={todayChile()}
                        required
                      />
                    </label>
                    <label>
                      Caja de origen (efectivo)
                      <select name="shiftId">
                        <option value="">Mi caja abierta</option>
                        {shifts.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.user.name} · {s.id.slice(-6)}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Cuenta de origen (otros medios)
                      <select name="bankAccountId">
                        <option value="">
                          Sin asignar · presupuesto pendiente
                        </option>
                        {banks.map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Referencia o comprobante
                      <input name="reference" maxLength={200} />
                    </label>
                  </div>
                  <label className="check-line">
                    <input type="checkbox" required />
                    Confirmo que este pago ya fue realizado y deseo registrarlo.
                  </label>
                  <button>Registrar pago realizado</button>
                </ActionForm>
                <p>
                  En efectivo se descuenta una sola vez de tu caja abierta.
                  Otros medios se registran sin alterar efectivo. No se vuelve a
                  contabilizar la compra.
                </p>
              </details>
            )}
          </section>
        );
      })}
    </>
  );
}

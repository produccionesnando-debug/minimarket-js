import Link from "next/link";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { ActionForm } from "@/components/action-form";
import { IMPORT_FIELDS, type ImportPlan } from "@/lib/product-import";
import {
  uploadImport,
  previewImport,
  commitImport,
} from "@/app/import-actions";
export default async function Import({
  searchParams,
}: {
  searchParams: Promise<{ id?: string }>;
}) {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write")) return <h1>Acceso restringido</h1>;
  const p = await searchParams;
  const batch = p.id
    ? await db.productImport.findFirst({
        where: { id: p.id, actorId: actor.id },
      })
    : null;
  const headers = (batch?.headers || []) as string[];
  const rows = (batch?.rows || []) as { cells: string[] }[];
  const plan = batch?.plan as unknown as ImportPlan | null;
  function suggest(field: string) {
    const aliases: Record<string, string[]> = {
      barcode: ["codigo de barras", "barcode", "ean"],
      internalCode: ["codigo interno", "sku"],
      name: ["nombre", "nombre del producto", "producto"],
      brand: ["marca"],
      category: ["categoria"],
      presentation: ["presentacion"],
      cost: ["costo", "precio de costo"],
      price: ["precio", "precio de venta"],
      channelPrice: ["precio pedidosya", "precio pedidos ya"],
      stock: ["stock", "existencias"],
      minimum: ["stock minimo", "minimo"],
      supplier: ["proveedor", "proveedor habitual"],
      flavor: ["sabor"],
      unitType: ["tipo de unidad"],
    };
    const index = headers.findIndex((h) =>
      aliases[field]?.includes(
        h
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLowerCase(),
      ),
    );
    return index < 0 ? "" : String(index);
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">CATÁLOGO · IMPORTACIÓN CONTROLADA</p>
          <h1>Importar productos desde Excel</h1>
        </div>
        <Link className="button secondary" href="/inventario">
          Volver al inventario
        </Link>
      </div>
      <section className="card">
        <h2>1. Seleccionar archivo XLSX o CSV</h2>
        <p>
          Hasta 2 MB, 1.000 filas y 60 columnas; primera hoja. Códigos como
          texto para conservar ceros. Formato numérico chileno: 1.200; sin
          fracciones de peso o unidad. No se ejecutan fórmulas. Para crear
          productos indica nombre, precio y costo explícitos.
        </p>
        <ActionForm action={uploadImport} label="Subir catálogo">
          <label>
            Archivo de productos
            <input type="file" name="file" accept=".xlsx,.csv" required />
          </label>
          <button>Subir y revisar columnas</button>
        </ActionForm>
        <p className="help">
          <a href="/api/importaciones/ejemplo">
            Descargar Excel de demostración
          </a>{" "}
          · Usa solo archivos de prueba hasta revisar la correspondencia. Sin
          código de barras se usa un identificador INTERNO: junto al código
          interno; no se inventa un EAN.
        </p>
      </section>
      {batch && (
        <>
          <section className="card">
            <h2>2. Relacionar columnas y elegir tratamiento</h2>
            <p>
              {batch.fileName} · {rows.length} filas.{" "}
              {batch.status === "COMPLETED"
                ? "Esta importación ya terminó."
                : "Todavía no se modifica el catálogo."}
            </p>
            {batch.status !== "COMPLETED" && (
              <ActionForm action={previewImport} label="Relacionar columnas">
                <input type="hidden" name="id" value={batch.id} />
                <div className="form-grid">
                  {Object.entries(IMPORT_FIELDS).map(([field, label]) => (
                    <label key={field}>
                      {label}
                      <select
                        name={field}
                        defaultValue={plan?.mapping?.[field] ?? suggest(field)}
                      >
                        <option value="">No importar este campo</option>
                        {headers.map((h, i) => (
                          <option value={i} key={i}>
                            {i + 1}. {h || "Sin título"}
                          </option>
                        ))}
                      </select>
                    </label>
                  ))}
                </div>
                <label>
                  Tratamiento de productos
                  <select name="mode" defaultValue={plan?.mode || "create"}>
                    <option value="create">
                      Crear nuevos y omitir existentes
                    </option>
                    <option value="update">
                      Crear nuevos y actualizar existentes
                    </option>
                    <option value="skip">Omitir todos · solo revisar</option>
                  </select>
                </label>
                <label className="check-line">
                  <input
                    type="checkbox"
                    name="demo"
                    defaultChecked={
                      plan?.demo ??
                      (process.env.DEMO_INSTANCE !== "1" &&
                        batch.fileName.includes("demostracion"))
                    }
                  />
                  Importar en catálogo de demostración, separado del negocio
                </label>
                <label className="check-line">
                  <input
                    type="checkbox"
                    name="overwritePrices"
                    defaultChecked={plan?.overwritePrices}
                  />
                  Permitir reemplazar precios y costos existentes
                </label>
                <label className="check-line">
                  <input
                    type="checkbox"
                    name="overwriteStock"
                    defaultChecked={plan?.overwriteStock}
                  />
                  Permitir reemplazar stock y mínimo existentes
                </label>
                {plan && (
                  <details>
                    <summary>Elegir acción por fila</summary>
                    <div className="import-row-choices">
                      {plan.rows.map((r) => (
                        <label key={r.row}>
                          Fila {r.row} · {r.values.name || r.values.barcode}
                          <select name={"row-" + r.row} defaultValue={r.action}>
                            <option value="create">Crear</option>
                            <option value="update">Actualizar</option>
                            <option value="skip">Omitir</option>
                          </select>
                        </label>
                      ))}
                    </div>
                  </details>
                )}
                <button>Generar vista previa</button>
              </ActionForm>
            )}
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {headers.map((h, i) => (
                      <th key={i}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 5).map((r, i) => (
                    <tr key={i}>
                      {r.cells.map((v, j) => (
                        <td key={j}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="help">Muestra original de las primeras 5 filas.</p>
          </section>
          {plan && (
            <section className="card">
              <h2>3. Vista previa por fila</h2>
              <p>
                {
                  plan.rows.filter(
                    (r) => !r.errors.length && r.action !== "skip",
                  ).length
                }{" "}
                filas aptas · {plan.rows.filter((r) => r.errors.length).length}{" "}
                con errores. Las filas erróneas se omiten y quedan en el
                informe. Las actualizaciones conservan precios y stock salvo
                permiso y confirmación expresos.
              </p>
              <div className="table-wrap import-preview">
                <table>
                  <thead>
                    <tr>
                      <th>Fila</th>
                      <th>Nombre</th>
                      <th>Código</th>
                      <th>Acción</th>
                      <th>Validación</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.rows.map((r) => (
                      <tr key={r.row}>
                        <td>{r.row}</td>
                        <td>{r.values.name}</td>
                        <td>{r.values.barcode}</td>
                        <td>
                          {r.action === "create"
                            ? "Crear"
                            : r.action === "update"
                              ? "Actualizar"
                              : "Omitir"}
                        </td>
                        <td className="wrap-text">
                          {r.errors.join(" · ") || "Validada"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {batch.status !== "COMPLETED" && (
                <ActionForm action={commitImport} label="Confirmar importación">
                  <input type="hidden" name="id" value={batch.id} />
                  {plan.overwritePrices && (
                    <label className="check-line">
                      <input type="checkbox" name="confirmPrices" required />
                      Confirmo el reemplazo de precios y costos de las filas
                      actualizadas
                    </label>
                  )}
                  {plan.overwriteStock && (
                    <label className="check-line">
                      <input type="checkbox" name="confirmStock" required />
                      Confirmo el reemplazo de existencias y mínimos de las
                      filas actualizadas
                    </label>
                  )}
                  <label className="check-line">
                    <input type="checkbox" required />
                    Revisé las filas y autorizo esta importación
                  </label>
                  <button>Confirmar e importar catálogo</button>
                </ActionForm>
              )}
            </section>
          )}
          {batch.status === "COMPLETED" && (
            <section className="card">
              <h2>Importación completada</h2>
              <a className="button" href={"/api/importaciones/" + batch.id}>
                Descargar informe del resultado CSV
              </a>
              <p className="help">
                Reabrir o confirmar esta importación no duplica productos ni
                movimientos.
              </p>
            </section>
          )}
        </>
      )}
    </>
  );
}

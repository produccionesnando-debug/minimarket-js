import type { Product } from "@prisma/client";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { saveProduct } from "@/app/actions";
import { clp } from "@/lib/money";
function Fields({ p }: { p?: Product }) {
  return (
    <>
      <input type="hidden" name="id" value={p?.id || ""} />
      {[
        ["name", "Producto"],
        ["brand", "Marca"],
        ["barcode", "Código de barras"],
        ["price", "Precio de venta"],
        ["cost", "Costo"],
        ["stock", "Stock"],
        ["minimum", "Stock mínimo"],
      ].map(([key, label], i) => (
        <label key={key}>
          {label}
          <input
            name={key}
            required
            type={i > 2 ? "number" : "text"}
            min={0}
            step={i > 2 ? 1 : undefined}
            defaultValue={String(
              p?.[key as keyof typeof p] ?? (i > 2 ? 0 : ""),
            )}
          />
        </label>
      ))}
      {(
        [
          ["category", "Categoría"],
          ["presentation", "Presentación"],
          ["flavor", "Sabor"],
        ] as const
      ).map(([key, label]) => (
        <label key={key}>
          {label}
          <input name={key} defaultValue={p?.[key]} />
        </label>
      ))}
      <label>
        Tipo de unidad
        <select name="unitType" defaultValue={p?.unitType || "UNIDAD"}>
          <option value="UNIDAD">Unidad normal</option>
          <option value="BIDON_LLENO">Bidón lleno</option>
          <option value="BIDON_VACIO">Bidón vacío</option>
          <option value="BIDON_RETORNABLE">Bidón retornable</option>
        </select>
      </label>
      <button>Guardar producto</button>
    </>
  );
}
export default async function Inventory() {
  const user = await requireUser();
  const products = await db.product.findMany({ orderBy: { name: "asc" } });
  const movements = await db.stockMovement.findMany({
    include: { product: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  const low = products.filter((p) => p.stock <= p.minimum);
  return (
    <>
      <p className="eyebrow">PRODUCTOS Y EXISTENCIAS</p>
      <h1>Inventario</h1>
      <p>
        Precios en pesos chilenos. Registra bidones llenos, vacíos y retornables
        como productos separados con conteos propios; helados por sabor y
        presentación. Los ajustes quedan en el historial.
      </p>
      {products.some((p) => p.demo) && (
        <p className="alert">
          El catálogo y sus indicadores incluyen productos ficticios
          identificados como DEMOSTRACIÓN. Sus existencias y valores no
          representan inventario real del negocio.
        </p>
      )}
      <div className="stats">
        <article>
          <small>Productos</small>
          <strong>{products.length}</strong>
        </article>
        <article>
          <small>Por reponer</small>
          <strong>{low.length}</strong>
        </article>
        <article>
          <small>Valor a costo</small>
          <strong>
            {clp(products.reduce((a, p) => a + p.cost * p.stock, 0))}
          </strong>
        </article>
      </div>
      {low.length > 0 && (
        <p className="alert">
          Reposición sugerida: {low.map((p) => p.name).join(", ")}.
        </p>
      )}
      <section className="card table-wrap">
        <h2>Catálogo de productos</h2>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Código</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Estado</th>
              {user.role === "ADMIN" && <th>Acciones</th>}
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>
                  <strong>{p.name}</strong>
                  <small>
                    {p.brand} · {p.presentation} · {p.flavor}
                    {p.demo ? " · DEMOSTRACIÓN" : ""}
                  </small>
                  <small>{p.unitType.replaceAll("_", " ")}</small>
                </td>
                <td>{p.barcode}</td>
                <td>{clp(p.price)}</td>
                <td>{p.stock}</td>
                <td>
                  <span
                    className={p.stock <= p.minimum ? "badge warning" : "badge"}
                  >
                    {p.stock <= p.minimum ? "Reponer" : "Disponible"}
                  </span>
                </td>
                {user.role === "ADMIN" && (
                  <td>
                    <details>
                      <summary>Editar</summary>
                      <form action={saveProduct}>
                        <Fields p={p} />
                      </form>
                    </details>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {!products.length && <p>No hay productos registrados.</p>}
      </section>
      <section className="card table-wrap">
        <h2>Últimos movimientos de inventario</h2>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Fecha Chile</th>
              <th>Tipo</th>
              <th>Unidades</th>
              <th>Nota</th>
            </tr>
          </thead>
          <tbody>
            {movements.map((m) => (
              <tr key={m.id}>
                <td>{m.product.name}</td>
                <td>
                  {m.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                </td>
                <td>{m.type}</td>
                <td>{m.quantity}</td>
                <td>{m.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!movements.length && (
          <p>No hay movimientos registrados desde esta actualización.</p>
        )}
      </section>
      {user.role === "ADMIN" && (
        <section className="card">
          <h2>Agregar producto</h2>
          <form action={saveProduct} className="form-grid">
            <Fields />
          </form>
        </section>
      )}
    </>
  );
}

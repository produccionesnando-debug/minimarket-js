import { kilograms, weightAmount, weightBased } from "@/lib/weight";
import Link from "next/link";
import type { Product } from "@prisma/client";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { saveProduct } from "@/app/actions";
import { clp } from "@/lib/money";
function Fields({
  p,
  barcode = "",
  categories = [],
  suppliers = [],
}: {
  p?: Product;
  barcode?: string;
  categories?: { id: string; name: string }[];
  suppliers?: { id: string; name: string }[];
}) {
  return (
    <>
      <input type="hidden" name="id" value={p?.id || ""} />
      <input type="hidden" name="version" value={p?.version || 0} />
      <label>
        Código interno
        <input name="internalCode" defaultValue={p?.internalCode || ""} />
      </label>
      {[
        ["name", "Producto"],
        ["brand", "Marca"],
        ["barcode", "Código de barras"],
        ["price", "Precio de venta"],
        ["cost", "Costo"],
        ["stock", "Stock"],
        ["minimum", "Stock mínimo"],
      ].map(([key, label], i) => (
        <label key={key}>
          {label}
          <input
            name={key}
            required={key === "name" || key === "barcode"}
            type={i > 2 ? "number" : "text"}
            min={0}
            step={i > 2 ? 1 : undefined}
            defaultValue={String(
              ((key === "price" && p?.priceKnown === false) ||
              (key === "cost" && p?.costKnown === false) ||
              (key === "stock" && p?.stockKnown === false)
                ? ""
                : p?.[key as keyof typeof p]) ??
                (key === "barcode" ? barcode : i > 2 ? 0 : ""),
            )}
          />
        </label>
      ))}
      {(
        [
          ["category", "Categoría"],
          ["presentation", "Presentación"],
          ["flavor", "Sabor"],
        ] as const
      ).map(([key, label]) => (
        <label key={key}>
          {label}
          <input name={key} defaultValue={p?.[key]} />
        </label>
      ))}
      <label>
        Stock por peso en kg (solo Venta por peso)
        <input
          name="weightKg"
          type="number"
          min={0}
          step={0.001}
          defaultValue={p && p.stockKnown ? p.stockGrams / 1000 : ""}
        />
      </label>
      <label className="check-line">
        <input type="checkbox" name="quickSale" defaultChecked={p?.quickSale} />
        Mostrar en venta rápida
      </label>
      <input type="hidden" name="activePresent" value="1" />
      <label className="check-line">
        <input
          name="active"
          type="checkbox"
          defaultChecked={p?.active ?? true}
        />
        Producto activo
      </label>
      <label>
        Inventario de importes manuales
        <select
          name="manualStockPolicy"
          defaultValue={p?.manualStockPolicy || "PENDING"}
        >
          <option value="PENDING">
            Conciliar después; no descontar estimación
          </option>
          <option value="ESTIMATE">
            Descontar estimación identificada y conciliar
          </option>
        </select>
      </label>
      <label>
        Plazo confirmado de reposición en días (opcional)
        <input
          name="leadTimeDays"
          type="number"
          min={0}
          max={365}
          defaultValue={p?.leadTimeDays ?? ""}
        />
      </label>
      <label>
        Tipo de unidad
        <select name="unitType" defaultValue={p?.unitType || "UNIDAD"}>
          <option value="UNIDAD">Unidad normal</option>
          <option value="PESO">Venta por peso · precios por kg</option>
          <option value="VARIABLE">Peso / importe variable</option>
          <option value="BIDON_LLENO">Bidón lleno</option>
          <option value="BIDON_VACIO">Bidón vacío</option>
          <option value="BIDON_RETORNABLE">Bidón retornable</option>
        </select>
      </label>
      <label>
        Categoría administrable
        <select name="categoryId" defaultValue={p?.categoryId || ""}>
          <option value="">Usar categoría de texto / sin categoría</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>
      <label>
        Proveedor habitual
        <select
          name="defaultSupplierId"
          defaultValue={p?.defaultSupplierId || ""}
        >
          <option value="">Sin asociar</option>
          {suppliers.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </label>
      <button>Guardar producto</button>
    </>
  );
}
export default async function Inventory({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    codigo?: string;
    categoria?: string;
    marca?: string;
    proveedor?: string;
    disponibilidad?: string;
    pagina?: string;
  }>;
}) {
  const filters = await searchParams;
  const q = filters.q?.trim().slice(0, 120) || "";
  const user = await requireUser();
  const [products, categories, suppliers] = await Promise.all([
    db.product.findMany({
      include: { suppliers: { select: { id: true } } },
      orderBy: { name: "asc" },
    }),
    db.category.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    }),
    db.supplier.findMany({
      where: { active: true, demo: false },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    }),
  ]);
  const movements = await db.stockMovement.findMany({
    include: { product: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  const filtered = products.filter(
    (p) =>
      (!filters.categoria || p.category === filters.categoria) &&
      (!filters.marca ||
        p.brand.toLowerCase().includes(filters.marca.toLowerCase())) &&
      (!filters.proveedor ||
        p.suppliers.some((s) => s.id === filters.proveedor)) &&
      (!filters.disponibilidad ||
        (p.active &&
          p.stockKnown &&
          (filters.disponibilidad === "bajo"
            ? (weightBased(p) ? p.stockGrams / 1000 : p.stock) <= p.minimum
            : filters.disponibilidad === "agotado"
              ? (weightBased(p) ? p.stockGrams : p.stock) === 0
              : (weightBased(p) ? p.stockGrams : p.stock) > 0))) &&
      (!q ||
        [
          p.name,
          p.brand,
          p.barcode,
          p.internalCode || "",
          p.flavor,
          p.presentation,
        ].some((v) =>
          v.toLocaleLowerCase("es").includes(q.toLocaleLowerCase("es")),
        )),
  );
  const pageSize = 40,
    pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(
    pages,
    Math.max(1, Math.floor(Number(filters.pagina) || 1)),
  );
  const visible = filtered.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize,
  );
  function pageHref(page: number) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(filters))
      if (value && key !== "pagina") params.set(key, value);
    params.set("pagina", String(page));
    return "/inventario?" + params.toString();
  }
  const low = products.filter(
    (p) =>
      p.active &&
      p.stockKnown &&
      (weightBased(p) ? p.stockGrams / 1000 : p.stock) <= p.minimum,
  );
  return (
    <>
      <p className="eyebrow">PRODUCTOS Y EXISTENCIAS</p>
      <div className="page-heading">
        <h1>Inventario</h1>
        <Link href="/inventario/inteligente">
          Inventario inteligente · vencimientos, sugerencias y conteos
        </Link>
        <Link href="/etiquetas">Imprimir etiquetas internas</Link> ·{" "}
        <Link href="/balanza">Configurar balanza</Link>
        {user.role === "ADMIN" && (
          <div className="toolbar">
            <Link className="button" href="/inventario/importar">
              Importar productos desde Excel
            </Link>
            <Link className="button secondary" href="/precios">
              Precios por canal
            </Link>
          </div>
        )}
      </div>
      <p>
        Precios en pesos chilenos. Registra bidones llenos, vacíos y retornables
        como productos separados con conteos propios; helados por sabor y
        presentación. Los ajustes quedan en el historial.
      </p>
      {products.some((p) => p.demo) && (
        <p className="alert">
          El catálogo y sus indicadores incluyen productos ficticios
          identificados como DEMOSTRACIÓN. Sus existencias y valores no
          representan inventario real del negocio.
        </p>
      )}
      <div className="stats">
        <article>
          <small>Productos</small>
          <strong>{products.length}</strong>
        </article>
        <article>
          <small>Por reponer</small>
          <strong>{low.length}</strong>
        </article>
        <article>
          <small>Valor a costo confirmado (excluye datos desconocidos)</small>
          <strong>
            {clp(
              products.reduce(
                (a, p) =>
                  a +
                  (!p.stockKnown || !p.costKnown
                    ? 0
                    : weightBased(p)
                      ? weightAmount(p.cost, p.stockGrams)
                      : p.cost * p.stock),
                0,
              ),
            )}
          </strong>
        </article>
      </div>
      {low.length > 0 && (
        <p className="alert">
          Reposición sugerida: {low.map((p) => p.name).join(", ")}.
        </p>
      )}
      <section className="card table-wrap">
        <h2>Catálogo de productos</h2>
        <form className="filters">
          <label>
            Buscar producto por nombre o código de barras
            <input
              name="q"
              defaultValue={q}
              placeholder="Nombre, marca o código de barras"
            />
          </label>
          <label>
            Filtrar categoría
            <select name="categoria" defaultValue={filters.categoria || ""}>
              <option value="">Todas</option>
              {Array.from(new Set(products.map((p) => p.category)))
                .filter(Boolean)
                .sort()
                .map((c) => (
                  <option key={c}>{c}</option>
                ))}
            </select>
          </label>
          <label>
            Filtrar marca
            <input name="marca" defaultValue={filters.marca} />
          </label>
          <label>
            Filtrar proveedor
            <select name="proveedor" defaultValue={filters.proveedor || ""}>
              <option value="">Todos</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Disponibilidad
            <select
              name="disponibilidad"
              defaultValue={filters.disponibilidad || ""}
            >
              <option value="">Todas</option>
              <option value="disponible">Con stock</option>
              <option value="agotado">Agotados</option>
              <option value="bajo">Stock bajo</option>
            </select>
          </label>
          <button>Buscar en inventario</button>
          <a href="/inventario">Limpiar búsqueda</a>
        </form>
        <nav aria-label="Páginas del catálogo" className="toolbar">
          <span>
            {filtered.length} productos · Página {currentPage} de {pages}
          </span>
          {currentPage > 1 && (
            <Link className="button secondary" href={pageHref(currentPage - 1)}>
              Página anterior
            </Link>
          )}
          {currentPage < pages && (
            <Link className="button secondary" href={pageHref(currentPage + 1)}>
              Página siguiente
            </Link>
          )}
        </nav>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Código</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Estado</th>
              {user.role === "ADMIN" && <th>Acciones</th>}
            </tr>
          </thead>
          <tbody>
            {visible.map((p) => (
              <tr key={p.id}>
                <td>
                  <strong>{p.name}</strong>
                  <small>
                    {p.brand} · {p.presentation} · {p.flavor}
                    {p.demo ? " · DEMOSTRACIÓN" : ""}
                  </small>
                  <small>{p.unitType.replaceAll("_", " ")}</small>
                </td>
                <td>{p.barcode}</td>
                <td>{p.priceKnown ? clp(p.price) : "Sin precio confirmado"}</td>
                <td>
                  {!p.stockKnown
                    ? "Sin registrar"
                    : weightBased(p)
                      ? kilograms(p.stockGrams)
                      : p.stock}
                </td>
                <td>
                  <span
                    className={
                      (weightBased(p) ? p.stockGrams / 1000 : p.stock) <=
                      p.minimum
                        ? "badge warning"
                        : "badge"
                    }
                  >
                    {!p.active
                      ? "Inactivo"
                      : !p.stockKnown
                        ? "Stock sin registrar"
                        : (weightBased(p) ? p.stockGrams / 1000 : p.stock) <=
                            p.minimum
                          ? "Reponer"
                          : "Disponible"}
                  </span>
                </td>
                {user.role === "ADMIN" && (
                  <td>
                    <details>
                      <summary>Editar</summary>
                      <form action={saveProduct}>
                        <Fields
                          p={p}
                          categories={categories}
                          suppliers={suppliers}
                        />
                      </form>
                    </details>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {!visible.length && (
          <p role="status">No hay productos que coincidan con la búsqueda.</p>
        )}
      </section>
      <section className="card table-wrap">
        <h2>Últimos movimientos de inventario</h2>
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Fecha Chile</th>
              <th>Tipo</th>
              <th>Unidades</th>
              <th>Nota</th>
            </tr>
          </thead>
          <tbody>
            {movements.map((m) => (
              <tr key={m.id}>
                <td>{m.product.name}</td>
                <td>
                  {m.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                </td>
                <td>{m.type}</td>
                <td>{m.weightGrams ? kilograms(m.weightGrams) : m.quantity}</td>
                <td>{m.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!movements.length && (
          <p>No hay movimientos registrados desde esta actualización.</p>
        )}
      </section>
      {user.role === "ADMIN" && (
        <section className="card">
          <h2 id="agregar-producto">Agregar producto</h2>
          <form action={saveProduct} className="form-grid">
            <Fields
              barcode={filters.codigo || ""}
              categories={categories}
              suppliers={suppliers}
            />
          </form>
        </section>
      )}
    </>
  );
}

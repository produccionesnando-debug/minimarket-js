import Link from "next/link";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { dateOnly, isoDay, todayChile } from "@/lib/dates";
import { weightBased, kilograms, weightAmount } from "@/lib/weight";
import { clp } from "@/lib/money";
import { ActionForm } from "@/components/action-form";
import {
  lotAction,
  lotLossAction,
  confirmLotsAction,
} from "@/app/inventory-actions";
export default async function Lots({
  searchParams,
}: {
  searchParams: Promise<{ producto?: string }>;
}) {
  const actor = await requireUser(),
    query = await searchParams,
    admin = can(actor.role, "inventory:adjust"),
    today = todayChile();
  const products = await db.product.findMany({
      where: process.env.DEMO_INSTANCE === "1" ? {} : { demo: false },
      orderBy: { name: "asc" },
    }),
    lots = await db.inventoryLot.findMany({
      where: query.producto ? { productId: query.producto } : {},
      orderBy: { expiresAt: "asc" },
    }),
    settings = await db.inventorySettings.findUniqueOrThrow({
      where: { id: "global" },
    });
  const selected = products.find((p) => p.id === query.producto),
    weighted = selected ? weightBased(selected) : false;
  return (
    <>
      <div className="page-heading">
        <h1>Lotes y vencimientos</h1>
        <div className="toolbar">
          <Link href="/inventario/inteligente">Inventario inteligente</Link>
          <Link href="/inventario/conteos">Conteos físicos</Link>
        </div>
      </div>
      <form className="filters">
        <label>
          Producto del lote
          <select name="producto" defaultValue={query.producto || ""}>
            <option value="">Todos</option>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
        <button>Ver lotes del producto</button>
      </form>
      {admin && selected && (
        <details className="card">
          <summary>Registrar un lote de {selected.name}</summary>
          <ActionForm action={lotAction} label="Registrar lote">
            <input type="hidden" name="requestKey" value={randomUUID()} />
            <input type="hidden" name="productId" value={selected.id} />
            <div className="form-grid">
              <label>
                Identificador del lote
                <input name="code" required maxLength={100} />
              </label>
              <label>
                Fecha de recepción
                <input
                  name="receivedAt"
                  type="date"
                  max={today}
                  defaultValue={today}
                  required
                />
              </label>
              <label>
                Fecha de vencimiento
                <input name="expiresAt" type="date" required />
              </label>
              <label>
                Cantidad del lote en {weighted ? "kg" : "unidades"}
                <input
                  name="quantity"
                  type="number"
                  min={weighted ? 0.001 : 1}
                  step={weighted ? 0.001 : 1}
                  required
                />
              </label>
              <label>
                Costo {weighted ? "por kg" : "unitario"} opcional
                <input name="unitCost" type="number" min={0} step={1} />
              </label>
              <label>
                Cómo registrar las existencias
                <select name="mode" defaultValue="ASSIGN">
                  <option value="ASSIGN">
                    Asignar stock existente al lote (no sumar otra vez)
                  </option>
                  <option value="NEW">
                    Nueva entrada de mercadería (sumar al stock)
                  </option>
                </select>
              </label>
            </div>
            <p className="help">
              Primero confirma el stock con un conteo si está sin registrar.
              Asignar evita duplicar una entrada ya registrada.
            </p>
            <button>Guardar lote</button>
          </ActionForm>
        </details>
      )}
      <div className="table-wrap card">
        <table>
          <thead>
            <tr>
              <th>Producto / lote</th>
              <th>Vencimiento</th>
              <th>Saldo del lote</th>
              <th>Estado</th>
              {admin && <th>Registrar merma</th>}
            </tr>
          </thead>
          <tbody>
            {lots.map((l) => {
              const p = products.find((p) => p.id === l.productId);
              if (!p) return null;
              const w = weightBased(p),
                days = Math.round(
                  (l.expiresAt.getTime() - dateOnly(today).getTime()) /
                    86400000,
                ),
                band = [...settings.expiryAlerts]
                  .sort((a, b) => a - b)
                  .find((n) => days <= n),
                balance = w ? l.grams : l.units;
              return (
                <tr key={l.id}>
                  <td>
                    <strong>{p.name}</strong>
                    <small>
                      Lote {l.code} · recibido {isoDay(l.receivedAt)}
                    </small>
                  </td>
                  <td>
                    {isoDay(l.expiresAt)}
                    <small>
                      {days < 0
                        ? "Vencido hace " + -days + " días"
                        : days === 0
                          ? "Vence hoy"
                          : days + " días restantes"}
                    </small>
                  </td>
                  <td>
                    {w ? kilograms(l.grams) : l.units + " un."}
                    {can(actor.role, "stats:read") && (
                      <small>
                        Costo saldo:{" "}
                        {l.unitCost === null
                          ? "Sin costo confirmado"
                          : clp(
                              w
                                ? weightAmount(l.unitCost, l.grams)
                                : l.unitCost * l.units,
                            )}
                      </small>
                    )}
                  </td>
                  <td>
                    {!l.reconciled
                      ? "Revisar cantidades del lote"
                      : !balance
                        ? "Sin saldo"
                        : days < 0
                          ? "Vencido"
                          : band
                            ? "Alerta de " + band + " días"
                            : "Vigente"}
                  </td>
                  {admin && (
                    <td>
                      {balance > 0 && (
                        <details>
                          <summary>Merma de este lote</summary>
                          <ActionForm
                            action={lotLossAction}
                            label={"Merma lote " + l.code}
                          >
                            <input
                              type="hidden"
                              name="requestKey"
                              value={randomUUID()}
                            />
                            <input type="hidden" name="lotId" value={l.id} />
                            <label>
                              Cantidad a dar de baja en {w ? "kg" : "unidades"}
                              <input
                                name="quantity"
                                type="number"
                                min={w ? 0.001 : 1}
                                max={w ? l.grams / 1000 : l.units}
                                step={w ? 0.001 : 1}
                                required
                              />
                            </label>
                            <label>
                              Motivo de merma
                              <input
                                name="reason"
                                required
                                minLength={3}
                                maxLength={500}
                                defaultValue={days < 0 ? "Vencimiento" : ""}
                              />
                            </label>
                            <button>Confirmar merma y descontar</button>
                          </ActionForm>
                        </details>
                      )}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
        {!lots.length && <p>No hay lotes registrados para este filtro.</p>}
      </div>
      {admin && selected && lots.some((l) => !l.reconciled) && (
        <section className="card">
          <h2>Conciliar saldos físicos por lote</h2>
          <p>
            El conteo confirmó{" "}
            {weighted
              ? kilograms(selected.stockGrams)
              : selected.stock + " unidades"}
            . Distribuye ese stock entre los lotes. Lo no asignado queda sin
            vencimiento conocido.
          </p>
          <ActionForm action={confirmLotsAction} label="Conciliar lotes">
            <input type="hidden" name="productId" value={selected.id} />
            <input type="hidden" name="version" value={selected.version} />
            {lots.map((l) => (
              <label key={l.id}>
                Saldo real del lote {l.code} ({weighted ? "kg" : "unidades"})
                <input
                  name={"lot-" + l.id}
                  type="number"
                  min={0}
                  step={weighted ? 0.001 : 1}
                  required
                  defaultValue={weighted ? l.grams / 1000 : l.units}
                />
              </label>
            ))}
            <button>Confirmar distribución real por lotes</button>
          </ActionForm>
        </section>
      )}
      <p className="help">
        Las ventas descuentan primero los lotes vigentes con vencimiento más
        cercano (FEFO). El stock no asignado a lotes conserva vencimiento
        desconocido. Un conteo con diferencias puede requerir revisar la
        distribución de lotes.
      </p>
    </>
  );
}

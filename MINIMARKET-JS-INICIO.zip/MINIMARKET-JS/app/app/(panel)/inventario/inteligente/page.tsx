import Link from "next/link";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { inventoryInsights } from "@/lib/inventory-insights";
import { isoDay } from "@/lib/dates";
import { kilograms } from "@/lib/weight";
import { ActionForm } from "@/components/action-form";
import {
  inventorySettingsAction,
  reviewRestockAction,
  reconcileStockAction,
} from "@/app/inventory-actions";
export default async function Intelligent({
  searchParams,
}: {
  searchParams: Promise<{
    estado?: string;
    categoria?: string;
    proveedor?: string;
    desde?: string;
    hasta?: string;
  }>;
}) {
  const actor = await requireUser(),
    p = await searchParams,
    data = await inventoryInsights(actor, {
      category: p.categoria,
      supplierId: p.proveedor,
      from: p.desde,
      to: p.hasta,
    }),
    admin = can(actor.role, "inventory:adjust"),
    suppliers = await db.supplier.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });
  const states = [
    ["available", "Disponibles"],
    ["low", "Stock bajo"],
    ["empty", "Agotados"],
    ["expiring", "Próximos a vencer"],
    ["expired", "Vencidos"],
    ["idle", "Sin movimiento"],
    ["fast", "Alta rotación"],
    ["margin", "Margen bajo"],
    ["differences", "Diferencias"],
    ["suggested", "Sugeridos hoy"],
  ];
  const rows = data.rows.filter(
    (r) =>
      !p.estado ||
      (
        {
          available: r.available,
          low: r.low,
          empty: r.empty,
          expiring: !!r.expiring.length,
          expired: !!r.expired.length,
          idle: r.idle,
          fast: r.fast,
          margin: r.lowMargin,
          differences: r.needsReview,
          suggested: r.suggestedToday,
        } as Record<string, boolean>
      )[p.estado],
  );
  const reviews = await db.replenishmentReview.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
  });
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">INVENTARIO · CANTIDADES Y DATOS CONFIRMADOS</p>
          <h1>Inventario inteligente</h1>
        </div>
        <div className="toolbar">
          <Link className="button secondary" href="/inventario">
            Catálogo
          </Link>
          <Link className="button secondary" href="/inventario/lotes">
            Lotes y vencimientos
          </Link>
          <Link className="button secondary" href="/inventario/conteos">
            Conteos físicos
          </Link>
        </div>
      </div>
      <form className="filters">
        <label>
          Estado
          <select name="estado" defaultValue={p.estado || ""}>
            <option value="">Todos</option>
            {states.map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Categoría
          <input name="categoria" defaultValue={p.categoria} />
        </label>
        <label>
          Proveedor
          <select name="proveedor" defaultValue={p.proveedor || ""}>
            <option value="">Todos</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Desde
          <input name="desde" type="date" defaultValue={data.from} />
        </label>
        <label>
          Hasta
          <input name="hasta" type="date" defaultValue={data.to} />
        </label>
        <button>Consultar inventario</button>
      </form>
      <p className="help">
        Fechas de Chile. Peso medido y estimado se distinguen. Sin stock
        confirmado no se inventa una cantidad disponible ni una compra.
      </p>
      <div className="table-wrap card">
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Stock</th>
              <th>Estado</th>
              <th>Vencimientos</th>
              <th>Movimiento / margen</th>
              <th>Reposición sugerida</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.product.id}>
                <td>
                  <strong>{r.product.name}</strong>
                  <small>
                    {r.product.internalCode || r.product.barcode} ·{" "}
                    {r.product.category} ·{" "}
                    {r.product.active ? "Activo" : "Inactivo"}
                  </small>
                </td>
                <td>
                  {r.stock === null
                    ? "Sin registrar"
                    : r.weighted
                      ? kilograms(Math.round(r.stock * 1000))
                      : r.stock + " un."}
                  <small>
                    Mínimo {r.product.minimum} {r.weighted ? "kg" : "un."}
                  </small>
                </td>
                <td>
                  {[
                    r.low ? "Por reponer" : "",
                    r.empty ? "Agotado" : "",
                    r.needsReview ? "Conciliar inventario" : "",
                    r.fast ? "Alta rotación" : "",
                    r.idle ? "Sin movimiento reciente" : "",
                  ]
                    .filter(Boolean)
                    .join(" · ") || "Disponible"}
                  <Link href={"/inventario/conteos"}>Contar</Link>
                </td>
                <td>
                  {r.expired.length} lotes vencidos · {r.expiring.length}{" "}
                  próximos
                  <Link href={"/inventario/lotes?producto=" + r.product.id}>
                    Ver lotes
                  </Link>
                  {r.expiring.map((l) => (
                    <small key={l.id}>
                      {l.code} · {isoDay(l.expiresAt)}
                    </small>
                  ))}
                </td>
                <td>
                  {r.sold.toLocaleString("es-CL")} {r.weighted ? "kg" : "un."}{" "}
                  en el período
                  {r.estimated && (
                    <small>Incluye peso estimado, no medido</small>
                  )}
                  {r.unknownQuantity && (
                    <small>Hay importes sin cantidad conocida</small>
                  )}
                  <small>
                    Último movimiento:{" "}
                    {r.last
                      ? r.last.toLocaleDateString("es-CL", {
                          timeZone: "America/Santiago",
                        })
                      : "Sin historial"}
                  </small>
                  {can(actor.role, "stats:read") && (
                    <small>
                      Margen sobre precio:{" "}
                      {r.margin === null
                        ? "Sin costo/precio confirmado"
                        : r.margin.toFixed(1) + "%"}
                      {r.lowMargin ? " · Bajo" : ""}
                    </small>
                  )}
                </td>
                <td>
                  <strong>
                    {r.recommend === null
                      ? "Falta conteo"
                      : r.recommend.toLocaleString("es-CL") +
                        " " +
                        (r.weighted ? "kg" : "un.")}
                  </strong>
                  <small>
                    {r.preliminary
                      ? "Estimación preliminar"
                      : "Cálculo con historial y plazo/calendario"}
                  </small>
                  <p className="help">{r.why}</p>
                  {r.nextDelivery && (
                    <small>Entrega según calendario: {r.nextDelivery}</small>
                  )}
                  {can(actor.role, "purchases:write") && r.product.active && (
                    <details>
                      <summary>Revisar y confirmar sugerencia</summary>
                      <ActionForm
                        action={reviewRestockAction}
                        label={"Revisar reposición " + r.product.name}
                      >
                        <input
                          type="hidden"
                          name="requestKey"
                          value={randomUUID()}
                        />
                        <input
                          type="hidden"
                          name="productId"
                          value={r.product.id}
                        />
                        <label>
                          Cantidad a revisar ({r.weighted ? "kg" : "unidades"})
                          <input
                            name="quantity"
                            type="number"
                            min={r.weighted ? 0.001 : 1}
                            step={r.weighted ? 0.001 : 1}
                            defaultValue={r.recommend || ""}
                            required
                          />
                        </label>
                        <label>
                          Proveedor de la revisión
                          <select
                            name="supplierId"
                            defaultValue={r.supplier?.id || ""}
                          >
                            <option value="">Sin asignar</option>
                            {suppliers.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Motivo y datos revisados
                          <textarea
                            name="reason"
                            minLength={5}
                            maxLength={1000}
                            defaultValue={r.why}
                            required
                          />
                        </label>
                        <button>Guardar revisión sin enviar pedido</button>
                      </ActionForm>
                    </details>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && (
          <p className="empty-state">No hay productos con este filtro.</p>
        )}
      </div>
      <section className="card">
        <h2>Conciliaciones de importes manuales</h2>
        {data.rows.flatMap((r) =>
          r.unresolved.map((entry) => (
            <article className="inventory-reconcile" key={entry.id}>
              <strong>{r.product.name}</strong>
              <p>
                Importe ${entry.amount.toLocaleString("es-CL")} ·{" "}
                {entry.estimatedGrams
                  ? kilograms(entry.estimatedGrams) + " estimados"
                  : "Sin peso estimado"}{" "}
                · descontados {kilograms(entry.deductedGrams)}.
              </p>
              {admin ? (
                <ActionForm
                  action={reconcileStockAction}
                  label={"Conciliar importe " + entry.id}
                >
                  <input type="hidden" name="id" value={entry.id} />
                  <label>
                    Peso manual realmente medido en kg
                    <input name="actualKg" type="number" min={0} step={0.001} />
                  </label>
                  <label className="check-line">
                    <input name="noTracking" type="checkbox" />
                    Cerrar sin control de cantidad (solo si no se descontó
                    estimación)
                  </label>
                  <label>
                    Observación autorizada
                    <textarea
                      name="note"
                      required
                      minLength={5}
                      maxLength={500}
                    />
                  </label>
                  <button>Confirmar conciliación</button>
                </ActionForm>
              ) : (
                <p>
                  Administración debe confirmar la cantidad o cerrar sin
                  seguimiento con una observación.
                </p>
              )}
            </article>
          )),
        )}
        {!data.rows.some((r) => r.unresolved.length) && (
          <p>No hay importes pendientes de conciliar.</p>
        )}
      </section>
      {admin && (
        <details className="card">
          <summary>Configurar alertas y reglas de análisis</summary>
          <ActionForm
            action={inventorySettingsAction}
            label="Reglas de inventario"
          >
            <div className="form-grid">
              {[30, 15, 7, 3].map((n) => (
                <label className="check-line" key={n}>
                  <input
                    type="checkbox"
                    name={"alert-" + n}
                    defaultChecked={data.settings.expiryAlerts.includes(n)}
                  />
                  Alertar {n} días antes
                </label>
              ))}
              {(
                [
                  ["historyDays", "Días de historial", 7, 366],
                  ["noMovementDays", "Días para sin movimiento", 1, 366],
                  [
                    "defaultLeadDays",
                    "Plazo inicial si falta dato real (días)",
                    0,
                    90,
                  ],
                  ["marginThreshold", "Margen bajo menor que (%)", 0, 100],
                  [
                    "highRotationDays",
                    "Cobertura para alta rotación (días)",
                    1,
                    90,
                  ],
                ] as const
              ).map(([name, label, min, max]) => (
                <label key={name}>
                  {label}
                  <input
                    name={name}
                    type="number"
                    min={min}
                    max={max}
                    defaultValue={data.settings[name]}
                    required
                  />
                </label>
              ))}
            </div>
            <button>Guardar reglas de inventario</button>
          </ActionForm>
        </details>
      )}
      <section className="card">
        <h2>Revisiones de compra guardadas</h2>
        {reviews.map((r) => (
          <p key={r.id}>
            {data.rows.find((p) => p.product.id === r.productId)?.product
              .name || "Producto fuera del filtro"}{" "}
            · {r.grams ? kilograms(r.grams) : r.units + " un."} · {r.reason}
          </p>
        ))}
        <p className="help">
          Revisar no envía mensajes ni crea pedidos automáticamente. Usa
          Proveedores para preparar el pedido comercial.
        </p>
      </section>
    </>
  );
}

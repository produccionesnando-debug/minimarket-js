import Link from "next/link";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { ActionForm } from "@/components/action-form";
import { startCountAction } from "@/app/inventory-actions";
export default async function Counts() {
  const actor = await requireUser(),
    admin = can(actor.role, "inventory:adjust");
  const counts = await db.inventoryCount.findMany({
      where: admin ? {} : { actorId: actor.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
    users = await db.user.findMany({ select: { id: true, name: true } });
  return (
    <>
      <div className="page-heading">
        <h1>Conteos físicos de inventario</h1>
        <Link href="/inventario/inteligente">
          Volver al inventario inteligente
        </Link>
      </div>
      <section className="card">
        <h2>Iniciar conteo</h2>
        <ActionForm action={startCountAction} label="Nuevo conteo físico">
          <input type="hidden" name="requestKey" value={randomUUID()} />
          <label>
            Observación o sector
            <input
              name="note"
              maxLength={500}
              placeholder="Ej.: estante de abarrotes"
            />
          </label>
          <button>Iniciar conteo sin modificar stock</button>
        </ActionForm>
        <p className="help">
          El trabajador prepara el conteo con lector o cantidades explícitas.
          Solo administración aplica diferencias; no se ponen a cero los
          productos no contados.
        </p>
      </section>
      <section className="card">
        <h2>Historial de conteos</h2>
        {counts.map((c) => (
          <p key={c.id}>
            <Link href={"/inventario/conteos/" + c.id}>
              {c.id.slice(-8)} · {c.note || "Sin observación"} ·{" "}
              {c.status === "DRAFT" ? "En preparación" : "Aprobado"}
            </Link>
            <small>
              {users.find((u) => u.id === c.actorId)?.name} ·{" "}
              {c.createdAt.toLocaleString("es-CL", {
                timeZone: "America/Santiago",
              })}
              {c.approvedAt
                ? " · aprobado por " +
                  users.find((u) => u.id === c.approvedBy)?.name
                : ""}
            </small>
          </p>
        ))}
      </section>
    </>
  );
}

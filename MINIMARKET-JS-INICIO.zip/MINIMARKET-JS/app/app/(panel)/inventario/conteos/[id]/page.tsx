import Link from "next/link";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { weightBased, kilograms } from "@/lib/weight";
import { ActionForm } from "@/components/action-form";
import { CountScanner } from "@/components/count-scanner";
import {
  setCountLineAction,
  approveCountAction,
} from "@/app/inventory-actions";
export default async function Count({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const actor = await requireUser(),
    admin = can(actor.role, "inventory:adjust"),
    id = (await params).id,
    count = await db.inventoryCount.findUniqueOrThrow({ where: { id } });
  if (count.actorId !== actor.id && !admin)
    return <h1>Conteo de otro trabajador</h1>;
  const lines = await db.inventoryCountLine.findMany({
      where: { countId: id },
    }),
    products = await db.product.findMany({
      where: { id: { in: lines.map((l) => l.productId) } },
    });
  return (
    <>
      <div className="page-heading">
        <div>
          <h1>Conteo físico {id.slice(-8)}</h1>
          <p>
            {count.status === "DRAFT"
              ? "En preparación: el inventario no cambia todavía."
              : "Conteo aprobado y ajustes auditados."}
          </p>
        </div>
        <Link href="/inventario/conteos">Historial de conteos</Link>
      </div>
      {count.status === "DRAFT" && <CountScanner countId={id} />}
      <section className="card table-wrap">
        <table>
          <thead>
            <tr>
              <th>Producto</th>
              <th>Stock al comenzar</th>
              <th>Contado</th>
              <th>Diferencia</th>
              <th>Revisión</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => {
              const p = products.find((p) => p.id === l.productId)!;
              const weighted = weightBased(p),
                system = weighted ? l.systemGrams : l.systemUnits,
                actual = weighted ? l.countedGrams : l.countedUnits,
                difference = actual - system;
              return (
                <tr key={l.id}>
                  <td>
                    <strong>{p.name}</strong>
                    <small>{p.internalCode || p.barcode}</small>
                  </td>
                  <td>
                    {!l.wasKnown
                      ? "Sin registrar"
                      : weighted
                        ? kilograms(system)
                        : system + " un."}
                  </td>
                  <td>{weighted ? kilograms(actual) : actual + " un."}</td>
                  <td>
                    {!l.wasKnown
                      ? "Primer stock confirmado"
                      : weighted
                        ? kilograms(difference)
                        : difference + " un."}
                  </td>
                  <td>
                    {count.status === "DRAFT" ? (
                      <ActionForm
                        action={setCountLineAction}
                        label={"Revisar conteo " + p.name}
                      >
                        <input
                          type="hidden"
                          name="requestKey"
                          value={randomUUID()}
                        />
                        <input type="hidden" name="countId" value={id} />
                        <input type="hidden" name="productId" value={p.id} />
                        <label>
                          Total contado ({weighted ? "kg" : "unidades"})
                          <input
                            name="quantity"
                            type="number"
                            min={0}
                            step={weighted ? 0.001 : 1}
                            required
                            defaultValue={weighted ? actual / 1000 : actual}
                          />
                        </label>
                        {p.version !== l.productVersion && (
                          <label className="check-line">
                            <input name="recount" type="checkbox" required />
                            Hubo movimientos: volví a contar y confirmo
                            reiniciar la referencia
                          </label>
                        )}
                        <button>Guardar cantidad contada</button>
                      </ActionForm>
                    ) : (
                      "Ajuste conservado en historial"
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!lines.length && <p>Escanea el primer producto para comenzar.</p>}
      </section>
      {count.status === "DRAFT" && admin && (
        <section className="card">
          <h2>Aprobar diferencias de inventario</h2>
          <ActionForm action={approveCountAction} label="Aprobar conteo físico">
            <input type="hidden" name="countId" value={id} />
            <label className="check-line">
              <input type="checkbox" name="confirm" required />
              Revisé las diferencias y autorizo ajustar solo los productos
              contados.
            </label>
            <button>Aprobar conteo y ajustar inventario</button>
          </ActionForm>
        </section>
      )}
      {count.status === "DRAFT" && !admin && (
        <p>Administración debe aprobar el ajuste. Puedes continuar contando.</p>
      )}
    </>
  );
}

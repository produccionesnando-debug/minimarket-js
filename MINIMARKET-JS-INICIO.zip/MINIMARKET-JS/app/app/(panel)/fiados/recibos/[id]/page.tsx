import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { receiptNumber, voucherNumber } from "@/lib/credit-vouchers";
import { PrintButton } from "@/components/print-button";
import { getBrand } from "@/lib/brand";
import { BrandLogo } from "@/components/brand-logo";
import { clp } from "@/lib/money";
export default async function Receipt({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireUser();
  const { id } = await params,
    r = await db.creditReceipt.findUniqueOrThrow({ where: { id } }),
    allocations = await db.creditAllocation.findMany({
      where: { receiptId: id },
    }),
    vouchers = await db.creditVoucher.findMany({
      where: { id: { in: allocations.map((a) => a.voucherId) } },
    }),
    payments = await db.customerPayment.findMany({
      where: { id: { in: allocations.map((a) => a.customerPaymentId) } },
      include: { collection: true },
    }),
    actor = await db.user.findUniqueOrThrow({ where: { id: r.actorId } }),
    customer = await db.customer.findUniqueOrThrow({
      where: { id: r.customerId },
    });
  return (
    <>
      <div className="toolbar no-print">
        <Link href={"/clientes/" + r.customerId}>Volver al cliente</Link>
        <PrintButton />
      </div>
      <article className="credit-voucher card">
        <BrandLogo brand={await getBrand()} variant="receipt" />
        <h1>Recibo {receiptNumber(r.number)}</h1>
        <h2>{customer.name}</h2>
        <p>
          {r.createdAt.toLocaleString("es-CL", {
            timeZone: "America/Santiago",
          })}{" "}
          · Recibió {actor.name}
        </p>
        <strong>Total recibido {clp(r.amount)}</strong>
        <p>{r.reference} · Cobro de cuentas por cobrar, no es venta nueva.</p>
        {allocations.map((a) => {
          const p = payments.find((p) => p.id === a.customerPaymentId)!,
            v = vouchers.find((v) => v.id === a.voucherId)!;
          return (
            <p key={a.id}>
              <Link href={"/fiados/" + v.id}>{voucherNumber(v.number)}</Link> ·{" "}
              {p.collection?.method} {clp(p.amount)} · Saldo anterior{" "}
              {clp(a.balanceBefore)} → {clp(a.balanceAfter)}
            </p>
          );
        })}
      </article>
    </>
  );
}

import Link from "next/link";
import { requireUser } from "@/lib/auth";
import {
  voucherData,
  voucherNumber,
  receiptNumber,
} from "@/lib/credit-vouchers";
import { getBrand } from "@/lib/brand";
import { BrandLogo } from "@/components/brand-logo";
import { PrintButton } from "@/components/print-button";
import { clp } from "@/lib/money";
import { kilograms } from "@/lib/weight";
import { can } from "@/lib/permissions";
const date = (d: Date) =>
  d.toLocaleString("es-CL", { timeZone: "America/Santiago" });
export default async function Voucher({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const actor = await requireUser(),
    { id } = await params,
    d = await voucherData(id),
    brand = await getBrand();
  return (
    <>
      <div className="toolbar no-print">
        <Link href={"/clientes/" + d.voucher.customerId}>
          Volver al cliente
        </Link>
        <PrintButton />
        <a className="button secondary" href={"/api/fiados/" + id + "/pdf"}>
          Descargar voucher PDF
        </a>
        {can(actor.role, "returns:approve") && d.state !== "ANULADO" && (
          <Link href={"/ventas/" + d.sale.id + "#devolucion"}>
            Anular mediante devolución autorizada
          </Link>
        )}
      </div>
      <article
        className="credit-voucher card"
        aria-label={"Voucher " + voucherNumber(d.voucher.number)}
      >
        <BrandLogo brand={brand} variant="receipt" />
        {(d.sale.demo || process.env.DEMO_INSTANCE === "1") && (
          <p>DEMOSTRACIÓN · DATOS FICTICIOS</p>
        )}
        <h1>Voucher de fiado {voucherNumber(d.voucher.number)}</h1>
        <p>Comprobante interno · No es documento tributario SII</p>
        <h2>{d.voucher.customerName}</h2>
        <p>
          Compra: {date(d.sale.createdAt)}
          <br />
          Generó el voucher: {d.workers.find((w) => w.id === d.voucher.createdById)?.name}
          <br />
          Vence:{" "}
          {d.sale.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" }) ||
            "Sin vencimiento"}
        </p>
        <span className="badge">{d.state}</span>
        {d.state === "PAGADO" && (
          <div className="paid-seal" aria-label="Timbre PAGADO">
            PAGADO
          </div>
        )}
        {d.state === "ANULADO" && <div className="void-seal">ANULADO</div>}
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {d.sale.items.map((i) => (
                <tr key={i.id}>
                  <td>{i.productName || i.productId}</td>
                  <td>
                    {i.manualAmount
                      ? "Importe manual; sin peso medido"
                      : i.weightGrams
                        ? kilograms(i.weightGrams)
                        : i.quantity}
                  </td>
                  <td>
                    {clp(i.unitPrice)}
                    {i.weightGrams ? " / kg" : ""}
                  </td>
                  <td>{clp(i.lineTotal ?? i.unitPrice * i.quantity)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <dl className="voucher-totals">
          <div>
            <dt>Total original de compra</dt>
            <dd>{clp(d.sale.total)}</dd>
          </div>
          <div>
            <dt>Crédito original</dt>
            <dd>{clp(d.sale.creditAmount)}</dd>
          </div>
          <div>
            <dt>Abonos recibidos</dt>
            <dd>
              {clp(d.sale.customerPayments.reduce((a, p) => a + p.amount, 0))}
            </dd>
          </div>
          <div>
            <dt>Reducciones por devolución</dt>
            <dd>
              {clp(d.sale.returns.reduce((a, r) => a + r.creditReduction, 0))}
            </dd>
          </div>
          <div>
            <dt>Saldo pendiente</dt>
            <dd>{clp(d.balance)}</dd>
          </div>
        </dl>
        {d.state === "PAGADO" && (
          <section className="paid-details">
            <h3>Detalle de saldo completo</h3>
            <p>
              Fecha: {d.settledAt ? date(d.settledAt) : "Consultar movimientos"}
            </p>
            <p>
              Medios:{" "}
              {Array.from(
                new Set(
                  d.sale.customerPayments.map(
                    (p) => p.collection?.method || "Registro previo",
                  ),
                ),
              ).join(", ") || "Saldo compensado mediante devolución autorizada"}
            </p>
            <p>
              Recibos:{" "}
              {d.receipts.map((r) => receiptNumber(r.number)).join(", ") ||
                d.sale.customerPayments
                  .map((p) => p.reference || p.id)
                  .join(", ") ||
                "Ver movimientos compensatorios"}
            </p>
          </section>
        )}
        <h3>Historial de pagos y abonos</h3>
        {d.sale.customerPayments.map((p) => {
          const allocation = d.allocations.find(
              (a) => a.customerPaymentId === p.id,
            ),
            receipt = d.receipts.find((r) => r.id === allocation?.receiptId);
          return (
            <div className="order" key={p.id}>
              {date(p.createdAt)} · {clp(p.amount)} · {p.collection?.method}
              <small>
                Recibió{" "}
                {d.workers.find((w) => w.id === p.actorId)?.name || p.actorId} ·{" "}
                {receipt ? receiptNumber(receipt.number) : p.reference || p.id}
              </small>
              {allocation && (
                <small>
                  Saldo anterior {clp(allocation.balanceBefore)} · Saldo
                  posterior {clp(allocation.balanceAfter)}
                </small>
              )}
            </div>
          );
        })}
        {!d.sale.customerPayments.length && <p>Sin abonos.</p>}
        {d.sale.returns.map((r) => (
          <p key={r.id}>
            Movimiento compensatorio autorizado: {r.reason} ·{" "}
            {date(r.createdAt)} · Reducción de deuda {clp(r.creditReduction)}
          </p>
        ))}
      </article>
    </>
  );
}

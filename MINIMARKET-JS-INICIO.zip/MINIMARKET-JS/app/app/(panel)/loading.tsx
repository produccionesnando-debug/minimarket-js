export default function Loading() {
  return (
    <div role="status" aria-label="Cargando pantalla">
      <p className="eyebrow">MINIMARKET JS</p>
      <h1>Cargando tu operación…</h1>
      <div className="loading-grid">
        {Array.from({ length: 6 }, (_, i) => (
          <div className="skeleton" key={i} />
        ))}
      </div>
      <div className="skeleton skeleton-large" />
      <span className="sr-only">Espera un momento.</span>
    </div>
  );
}

import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { clp } from "@/lib/money";
import { channelPrice } from "@/lib/catalog";
import { ActionForm } from "@/components/action-form";
import { priceAction, priceSettingsAction } from "@/app/catalog-actions";
export default async function Prices({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write")) return <h1>Acceso restringido</h1>;
  const q = (await searchParams).q?.slice(0, 120) || "";
  const [config, products, history] = await Promise.all([
    db.priceConfig.findUniqueOrThrow({ where: { id: "global" } }),
    db.product.findMany({
      where: q
        ? {
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { barcode: { contains: q } },
            ],
          }
        : {},
      orderBy: { name: "asc" },
      take: 100,
    }),
    db.priceChange.findMany({
      include: { product: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
  ]);
  return (
    <>
      <p className="eyebrow">PRECIOS Y REGLAS COMERCIALES</p>
      <h1>Precios minimarket y PedidosYa</h1>
      <p className="alert">
        Comparación interna. No publica ni modifica precios en PedidosYa. El
        recargo no garantiza rentabilidad: comisiones, promociones y
        liquidaciones reales siguen pendientes de la integración oficial.
      </p>
      <section className="card">
        <h2>Regla global · inicial 20%</h2>
        <ActionForm action={priceSettingsAction} label="Regla de precios">
          <div className="form-grid">
            <label>
              Redondeo de venta por peso a pesos enteros
              <select
                name="weightRounding"
                defaultValue={config.weightRounding}
              >
                <option value="NEAREST">
                  Al peso más cercano (mitad hacia arriba)
                </option>
                <option value="UP">Siempre hacia arriba</option>
                <option value="DOWN">Siempre hacia abajo</option>
              </select>
            </label>
            <label>
              Recargo PedidosYa %
              <input
                name="markup"
                type="number"
                min={0}
                max={200}
                defaultValue={config.markup}
                required
              />
            </label>
            <label>
              Redondear a
              <select name="rounding" defaultValue={config.rounding}>
                {[1, 10, 50, 100].map((v) => (
                  <option key={v} value={v}>
                    {v} pesos
                  </option>
                ))}
              </select>
            </label>
            <label>
              Regla de redondeo
              <select name="roundingMode" defaultValue={config.roundingMode}>
                <option value="NEAREST">Más cercano</option>
                <option value="UP">Hacia arriba</option>
                <option value="DOWN">Hacia abajo</option>
              </select>
            </label>
          </div>
          <button>Guardar regla comercial</button>
        </ActionForm>
      </section>
      <section className="card">
        <h2>Comparar y editar precios</h2>
        <form className="filters">
          <label>
            Buscar producto o código
            <input name="q" defaultValue={q} />
          </label>
          <button>Buscar precios</button>
        </form>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Costo</th>
                <th>Minimarket</th>
                <th>PedidosYa interno</th>
                <th>Modo</th>
                <th>Editar</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td>
                    {p.name}
                    <small>
                      {p.barcode}
                      {p.demo ? " · DEMO" : ""}
                    </small>
                  </td>
                  <td>{clp(p.cost)}</td>
                  <td>{clp(p.price)}</td>
                  <td>
                    {clp(
                      channelPrice(
                        p.price,
                        config,
                        p.channelFixed ? p.channelPrice : null,
                      ),
                    )}
                  </td>
                  <td>{p.channelFixed ? "Fijo" : "Automático"}</td>
                  <td>
                    <details>
                      <summary>Editar precios</summary>
                      <ActionForm action={priceAction}>
                        <input type="hidden" name="id" value={p.id} />
                        <input type="hidden" name="version" value={p.version} />
                        <label>
                          Precio minimarket
                          <input
                            name="price"
                            type="number"
                            min={0}
                            required
                            defaultValue={p.price}
                          />
                        </label>
                        <label>
                          Costo
                          <input
                            name="cost"
                            type="number"
                            min={0}
                            required
                            defaultValue={p.cost}
                          />
                        </label>
                        <label className="check-line">
                          <input
                            type="checkbox"
                            name="channelFixed"
                            defaultChecked={p.channelFixed}
                          />
                          Fijar precio PedidosYa de este producto
                        </label>
                        <label>
                          Precio PedidosYa fijo
                          <input
                            name="channelPrice"
                            type="number"
                            min={0}
                            defaultValue={p.channelPrice ?? ""}
                          />
                        </label>
                        <label>
                          Motivo del cambio
                          <input
                            name="reason"
                            required
                            minLength={3}
                            maxLength={500}
                          />
                        </label>
                        <button>Guardar precios con historial</button>
                      </ActionForm>
                    </details>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="help">
          Hasta 100 productos por búsqueda. Los precios publicados, comisiones,
          descuentos del canal e ingreso neto liquidado no se infieren de esta
          sugerencia.
        </p>
      </section>
      <section className="card">
        <h2>Últimos cambios de precios</h2>
        {history.map((h) => (
          <div className="order" key={h.id}>
            <strong>{h.product.name}</strong>
            <small>
              {h.createdAt.toLocaleString("es-CL", {
                timeZone: "America/Santiago",
              })}{" "}
              · {h.reason} · Responsable {h.actorId}
            </small>
            <pre>
              Antes: {JSON.stringify(h.before)}
              {"\n"}Después: {JSON.stringify(h.after)}
            </pre>
          </div>
        ))}
        {!history.length && (
          <p>Aún no se han modificado precios desde esta etapa.</p>
        )}
      </section>
    </>
  );
}

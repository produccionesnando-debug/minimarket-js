import Link from "next/link";
import { randomUUID } from "node:crypto";
import {
  Wallet,
  ShoppingCart,
  ArrowLeftRight,
  AlertTriangle,
} from "lucide-react";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { dailyPOS } from "@/lib/pos";
import { serial, expectedCash } from "@/lib/cash";
import { clp, METHODS } from "@/lib/money";
import { POS } from "@/components/pos";
import { Card, EmptyState } from "@/components/ui";
import { LiveRefresh } from "@/components/live-refresh";
import { ActionForm } from "@/components/action-form";
import { incomeAction } from "@/app/pos-actions";
export default async function Sales({
  searchParams,
}: {
  searchParams: Promise<{ cambio?: string }>;
}) {
  const actor = await requireUser();
  const p = await searchParams;
  const shift = await db.shift.findFirst({
    where: { userId: actor.id, closedAt: null },
    include: { user: true },
  });
  const [
    summary,
    expected,
    products,
    categories,
    suppliers,
    customers,
    recent,
  ] = await Promise.all([
    dailyPOS(actor, actor.id, shift?.demo || false),
    shift ? serial((tx) => expectedCash(tx, shift.id)) : Promise.resolve(null),
    shift
      ? db.product.findMany({
          where: { demo: shift.demo, stock: { gt: 0 } },
          select: {
            id: true,
            name: true,
            barcode: true,
            internalCode: true,
            price: true,
            stock: true,
            category: true,
            brand: true,
          },
          orderBy: { name: "asc" },
          take: 60,
        })
      : Promise.resolve([]),
    db.product.findMany({
      where: { demo: shift?.demo || false },
      select: { category: true },
      distinct: ["category"],
    }),
    db.supplier.findMany({
      where: { active: true, demo: shift?.demo || false },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    }),
    can(actor.role, "credits:authorize")
      ? db.customer.findMany({
          where: { active: true, demo: shift?.demo || false },
          select: { id: true, name: true },
          orderBy: { name: "asc" },
        })
      : Promise.resolve([]),
    db.sale.findMany({
      where: { shift: { userId: actor.id } },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);
  return (
    <>
      <LiveRefresh />
      <div className="page-heading">
        <div>
          <p className="eyebrow">PUNTO DE VENTA · CHILE · CLP</p>
          <h1>Ventas y Caja</h1>
          <p>
            {actor.name} ·{" "}
            {shift ? `${shift.register} · Turno abierto` : "Sin turno abierto"}
          </p>
        </div>
        <div className="toolbar">
          <Link className="button secondary" href="/ventas/historial">
            Buscar ventas y devoluciones
          </Link>
          {actor.role === "ADMIN" && (
            <Link className="button secondary" href="/inventario/importar">
              Importar productos desde Excel
            </Link>
          )}
          <Link className="button secondary" href="/caja">
            {shift ? "Gastos, retiros y cierre" : "Abrir caja"}
          </Link>
        </div>
      </div>
      <section
        className="day-balance card"
        aria-label="Resumen financiero de hoy"
      >
        <div className="day-balance-heading">
          <strong>Resumen de caja — Hoy</strong>
          <span className={shift ? "badge" : "badge warning"}>
            {shift ? "Caja abierta" : "Caja cerrada"}
            {shift?.demo ? " · DEMO" : ""}
          </span>
        </div>
        <div className="day-balance-grid">
          <div>
            <small>Ventas brutas del día</small>
            <strong>{clp(summary.gross)}</strong>
          </div>
          <div>
            <small>Ventas netas · menos devoluciones</small>
            <strong>{clp(summary.netSales)}</strong>
          </div>
          <div
            className={
              summary.net < 0 ? "net-balance negative-balance" : "net-balance"
            }
          >
            <small>Saldo neto del día</small>
            <strong>{clp(summary.net)}</strong>
          </div>
          <div>
            <small>Efectivo esperado en caja</small>
            <strong>
              {expected === null ? "Sin caja abierta" : clp(expected)}
            </strong>
          </div>
        </div>
        <div className="day-methods">
          {METHODS.map((m) => (
            <div key={m}>
              <small>
                {m === "CREDITO"
                  ? "Tarjeta de crédito"
                  : m === "DEBITO"
                    ? "Débito"
                    : m === "TRANSFERENCIA"
                      ? "Transferencia"
                      : "Efectivo"}
              </small>
              <strong>{clp(summary.byMethod[m])}</strong>
            </div>
          ))}
          <div>
            <small>Crédito otorgado hoy · sin cobrar</small>
            <strong>{clp(summary.credit)}</strong>
          </div>
          <div>
            <small>Utilidad estimada</small>
            <strong>
              {summary.profit === null
                ? "Información insuficiente"
                : clp(summary.profit)}
            </strong>
          </div>
        </div>
        <details>
          <summary>¿Cómo se calcula?</summary>
          <p className="help">
            Resumen de tus turnos, horario de Chile. Saldo neto = cobros
            registrados (incluidos abonos e ingresos adicionales, menos
            reembolsos) − gastos, retiros y pagos a proveedores del día. No
            incluye el fondo inicial, crédito sin cobrar ni compras aún no
            pagadas. Efectivo esperado = fondo inicial + entradas en efectivo −
            salidas en efectivo del turno abierto. La utilidad estimada
            descuenta costos conocidos, gastos operativos y mermas; no es
            utilidad contable. Actualización tras movimientos y cada 15 segundos
            con esta pantalla activa.
          </p>
        </details>
      </section>
      {p.cambio && (
        <p className="alert">
          Cambio vinculado a devolución {p.cambio}. Registra aquí el producto de
          reemplazo como nueva venta; el reembolso o ajuste de deuda quedó
          separado en la devolución.
        </p>
      )}
      {shift ? (
        <POS
          shiftId={shift.id}
          initial={products}
          requestKey={randomUUID()}
          categories={categories.map((c) => c.category).filter(Boolean)}
          suppliers={suppliers}
          customers={customers}
          authorizeCredit={can(actor.role, "credits:authorize")}
          discountAllowed={can(actor.role, "discounts:apply")}
          createProduct={actor.role === "ADMIN"}
          exchangeReturnId={p.cambio}
        />
      ) : (
        <EmptyState
          title="Abre tu caja para comenzar a vender"
          description="La venta quedará vinculada a tu trabajador y turno."
          action={
            <Link className="button" href="/caja#abrir-caja">
              <Wallet size={17} />
              Abrir mi caja
            </Link>
          }
        />
      )}
      <div className="columns">
        <Card title="Ventas recientes" icon={ShoppingCart}>
          {recent.map((s) => (
            <div className="stock-row" key={s.id}>
              <Link href={"/ventas/" + s.id}>
                Comprobante {s.id.slice(-8).toUpperCase()} ·{" "}
                {s.createdAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}
              </Link>
              <strong>{clp(s.total)}</strong>
            </div>
          ))}
          {!recent.length && <EmptyState title="Aún no registras ventas" />}
        </Card>
        {shift && (
          <Card title="Ingresos adicionales" icon={ArrowLeftRight}>
            <ActionForm action={incomeAction} label="Ingreso adicional">
              <input type="hidden" name="requestKey" value={randomUUID()} />
              <input type="hidden" name="shiftId" value={shift.id} />
              <label>
                Motivo del ingreso
                <input name="reason" required minLength={3} maxLength={500} />
              </label>
              <label>
                Monto del ingreso
                <input name="amount" type="number" min={1} required />
              </label>
              <label>
                Medio del ingreso
                <select name="method">
                  {METHODS.map((m) => (
                    <option key={m}>{m}</option>
                  ))}
                </select>
              </label>
              <button>Registrar ingreso adicional</button>
              <p className="help">
                No crea ventas ni reemplaza los abonos de clientes.
              </p>
            </ActionForm>
          </Card>
        )}
      </div>
    </>
  );
}

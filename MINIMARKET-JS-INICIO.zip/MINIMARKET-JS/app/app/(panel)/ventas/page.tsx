import Link from "next/link";
import { printSettings } from "@/lib/daily-scripture";
import { randomUUID } from "node:crypto";
import { Wallet, ShoppingCart, ArrowLeftRight } from "lucide-react";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { financialSummary } from "@/lib/financial-summary";
import { clp, METHODS } from "@/lib/money";
import { POS } from "@/components/pos";
import { Card, EmptyState } from "@/components/ui";
import { LiveRefresh } from "@/components/live-refresh";
import { ActionForm } from "@/components/action-form";
import { incomeAction } from "@/app/pos-actions";
export default async function Sales({
  searchParams,
}: {
  searchParams: Promise<{ cambio?: string; fecha?: string; turno?: string }>;
}) {
  const actor = await requireUser();
  const printer = await printSettings();
  const priceConfig = (await db.priceConfig.findUnique({
    where: { id: "global" },
  })) || {
    markup: 20,
    rounding: 1,
    roundingMode: "NEAREST",
    weightRounding: "NEAREST",
  };
  const p = await searchParams;
  const shift = await db.shift.findFirst({
    where: { userId: actor.id, closedAt: null },
    include: { user: true },
  });
  const summaryShifts = await db.shift.findMany({
    where: {
      demo: shift?.demo || false,
      ...(can(actor.role, "shifts:manage") ? {} : { userId: actor.id }),
    },
    include: { user: { select: { name: true } } },
    orderBy: { openedAt: "desc" },
    take: 100,
  });
  const [summary, products, categories, suppliers, customers, recent] =
    await Promise.all([
      financialSummary(actor, {
        day: p.fecha,
        shiftId: p.turno,
        demo: shift?.demo || false,
      }),
      shift
        ? db.product.findMany({
            where: {
              demo: shift.demo,
              OR: [{ stock: { gt: 0 } }, { stockGrams: { gt: 0 } }],
            },
            select: {
              id: true,
              name: true,
              barcode: true,
              internalCode: true,
              price: true,
              stock: true,
              stockGrams: true,
              unitType: true,
              quickSale: true,
              barcodeKind: true,
              category: true,
              brand: true,
            },
            orderBy: [{ quickSale: "desc" }, { name: "asc" }],
            take: 60,
          })
        : Promise.resolve([]),
      db.product.findMany({
        where: { demo: shift?.demo || false },
        select: { category: true },
        distinct: ["category"],
      }),
      db.supplier.findMany({
        where: { active: true, demo: shift?.demo || false },
        select: { id: true, name: true },
        orderBy: { name: "asc" },
      }),
      can(actor.role, "credits:authorize")
        ? db.customer.findMany({
            where: { active: true, demo: shift?.demo || false },
            select: { id: true, name: true },
            orderBy: { name: "asc" },
          })
        : Promise.resolve([]),
      db.sale.findMany({
        where: { shift: { userId: actor.id } },
        orderBy: { createdAt: "desc" },
        take: 10,
      }),
    ]);
  return (
    <>
      <LiveRefresh />
      <div className="page-heading">
        <div>
          <p className="eyebrow">PUNTO DE VENTA · CHILE · CLP</p>
          <h1>Ventas y Caja</h1>
          <p>
            {actor.name} ·{" "}
            {shift ? `${shift.register} · Turno abierto` : "Sin turno abierto"}
          </p>
        </div>
        <div className="toolbar">
          <Link className="button secondary" href="/ventas/historial">
            Buscar ventas y devoluciones
          </Link>
          {actor.role === "ADMIN" && (
            <Link className="button secondary" href="/inventario/importar">
              Importar productos desde Excel
            </Link>
          )}
          <Link className="button secondary" href="/caja">
            {shift ? "Gastos, retiros y cierre" : "Abrir caja"}
          </Link>
        </div>
      </div>
      <section
        className="day-balance card financial-compact"
        aria-label="Resumen financiero de hoy"
      >
        <div className="day-balance-heading">
          <strong>Resumen financiero</strong>
          <form method="get" className="summary-scope">
            {p.cambio && <input type="hidden" name="cambio" value={p.cambio} />}
            <input
              aria-label="Fecha del resumen"
              type="date"
              name="fecha"
              defaultValue={summary.day}
            />
            <select
              aria-label="Alcance del resumen"
              name="turno"
              defaultValue={p.turno || ""}
            >
              <option value="">Día completo · mis cajas</option>
              {summaryShifts.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.register} · {s.user.name} ·{" "}
                  {s.openedAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                  {s.closedAt ? " · cerrado" : " · abierto"}
                </option>
              ))}
            </select>
            <button type="submit">Ver</button>
          </form>
        </div>
        <div className="day-balance-grid">
          <div className="sales-balance">
            <small>Ventas del día{p.turno ? " · turno" : ""}</small>
            <strong>{clp(summary.netSales)}</strong>
          </div>
          <div
            className={
              summary.net < 0 ? "net-balance negative-balance" : "net-balance"
            }
          >
            <small>Saldo neto del día</small>
            <strong>{clp(summary.net)}</strong>
            <span className="summary-disclaimer">No es utilidad contable</span>
          </div>
        </div>
        <div
          className="day-methods"
          tabIndex={0}
          aria-label="Cobros y caja; desliza para ver todos los indicadores"
        >
          {METHODS.map((m) => (
            <div key={m}>
              <small>
                {m === "CREDITO"
                  ? "Tarjeta crédito"
                  : m === "DEBITO"
                    ? "Débito"
                    : m === "TRANSFERENCIA"
                      ? "Transferencia"
                      : "Efectivo cobrado"}
              </small>
              <strong>{clp(summary.byMethod[m])}</strong>
            </div>
          ))}
          <div>
            <small>Crédito clientes pendiente</small>
            <strong>{clp(summary.pending)}</strong>
          </div>
          <div>
            <small>Efectivo esperado{summary.closed ? " · cierre" : ""}</small>
            <strong>{clp(summary.expectedCash)}</strong>
          </div>
        </div>
        <details>
          <summary>Fórmulas y alcance · Chile</summary>
          <p className="help">
            Ventas netas = ventas registradas menos devoluciones del período.
            Saldo neto = ventas netas − egresos operativos (
            {clp(summary.operating)}); no es utilidad contable ni dinero
            disponible. Cobros incluyen abonos y restan reembolsos, excluyen
            ingresos adicionales y fondo inicial. Crédito pendiente: saldo
            actual de las ventas originadas en el período, descontando abonos y
            devoluciones. Efectivo esperado = fondo inicial + entradas en
            efectivo − gastos, retiros, pagos y reembolsos en efectivo. En día
            completo muestra las cajas abiertas al terminar ese día (
            {summary.cashBoxes}), sin sumar fondos de turnos cerrados que
            podrían reutilizarse. Por turno muestra su caja completa.
            Actualización tras cada movimiento y cada 15 segundos con la
            pantalla activa.
            {summary.legacyReturns > 0
              ? " Hay devoluciones antiguas sin turno identificado, atribuidas al vendedor original."
              : ""}
          </p>
        </details>
      </section>
      {p.cambio && (
        <p className="alert">
          Cambio vinculado a devolución {p.cambio}. Registra aquí el producto de
          reemplazo como nueva venta; el reembolso o ajuste de deuda quedó
          separado en la devolución.
        </p>
      )}
      {shift ? (
        <POS
          autoPrint={printer.autoPrint}
          ticketPaper={printer.paper === 58 ? 58 : 80}
          shiftId={shift.id}
          initial={products}
          priceConfig={priceConfig}
          requestKey={randomUUID()}
          categories={categories.map((c) => c.category).filter(Boolean)}
          suppliers={suppliers}
          customers={customers}
          authorizeCredit={can(actor.role, "credits:authorize")}
          discountAllowed={can(actor.role, "discounts:apply")}
          createProduct={actor.role === "ADMIN"}
          exchangeReturnId={p.cambio}
        />
      ) : (
        <EmptyState
          title="Abre tu caja para comenzar a vender"
          description="La venta quedará vinculada a tu trabajador y turno."
          action={
            <Link className="button" href="/caja#abrir-caja">
              <Wallet size={17} />
              Abrir mi caja
            </Link>
          }
        />
      )}
      <div className="columns">
        <Card title="Ventas recientes" icon={ShoppingCart}>
          {recent.map((s) => (
            <div className="stock-row" key={s.id}>
              <Link href={"/ventas/" + s.id}>
                Comprobante {s.id.slice(-8).toUpperCase()} ·{" "}
                {s.createdAt.toLocaleString("es-CL", {
                  timeZone: "America/Santiago",
                })}
              </Link>
              <strong>{clp(s.total)}</strong>
            </div>
          ))}
          {!recent.length && <EmptyState title="Aún no registras ventas" />}
        </Card>
        {shift && (
          <Card title="Ingresos adicionales" icon={ArrowLeftRight}>
            <ActionForm action={incomeAction} label="Ingreso adicional">
              <input type="hidden" name="requestKey" value={randomUUID()} />
              <input type="hidden" name="shiftId" value={shift.id} />
              <label>
                Motivo del ingreso
                <input name="reason" required minLength={3} maxLength={500} />
              </label>
              <label>
                Monto del ingreso
                <input name="amount" type="number" min={1} required />
              </label>
              <label>
                Medio del ingreso
                <select name="method">
                  {METHODS.map((m) => (
                    <option key={m}>{m}</option>
                  ))}
                </select>
              </label>
              <button>Registrar ingreso adicional</button>
              <p className="help">
                No crea ventas ni reemplaza los abonos de clientes.
              </p>
            </ActionForm>
          </Card>
        )}
      </div>
    </>
  );
}

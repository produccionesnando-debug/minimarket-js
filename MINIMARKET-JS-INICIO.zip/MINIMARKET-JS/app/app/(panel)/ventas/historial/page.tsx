import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { clp } from "@/lib/money";
import {
  validDate,
  chileDayStart,
  dateOnly,
  addDays,
  isoDay,
} from "@/lib/dates";
export default async function History({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; desde?: string; hasta?: string }>;
}) {
  const actor = await requireUser();
  const p = await searchParams,
    q = (p.q || "").trim().slice(0, 120);
  const sales = await db.sale.findMany({
    where: {
      ...(!can(actor.role, "shifts:manage")
        ? { shift: { userId: actor.id } }
        : {}),
      ...(validDate(p.desde || "") || validDate(p.hasta || "")
        ? {
            createdAt: {
              ...(validDate(p.desde || "")
                ? { gte: chileDayStart(p.desde!) }
                : {}),
              ...(validDate(p.hasta || "")
                ? { lt: chileDayStart(isoDay(addDays(dateOnly(p.hasta!), 1))) }
                : {}),
            },
          }
        : {}),
      ...(q
        ? {
            OR: [
              { id: { contains: q, mode: "insensitive" } },
              { customer: { name: { contains: q, mode: "insensitive" } } },
              {
                items: {
                  some: {
                    OR: [
                      { productName: { contains: q, mode: "insensitive" } },
                      { product: { barcode: q } },
                      {
                        product: { name: { contains: q, mode: "insensitive" } },
                      },
                    ],
                  },
                },
              },
            ],
          }
        : {}),
    },
    include: {
      shift: { include: { user: { select: { name: true } } } },
      customer: { select: { name: true } },
      returns: true,
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">COMPROBANTES Y OPERACIONES COMPENSATORIAS</p>
          <h1>Buscar ventas y devoluciones</h1>
        </div>
        <Link className="button secondary" href="/ventas">
          Volver al punto de venta
        </Link>
      </div>
      <form className="filters">
        <label>
          Número, producto, código o cliente
          <input name="q" defaultValue={q} />
        </label>
        <label>
          Desde
          <input type="date" name="desde" defaultValue={p.desde} />
        </label>
        <label>
          Hasta
          <input type="date" name="hasta" defaultValue={p.hasta} />
        </label>
        <button>Buscar ventas</button>
      </form>
      <section className="card table-wrap">
        <p className="help">
          Hasta 100 coincidencias.{" "}
          {can(actor.role, "shifts:manage")
            ? "Todos los trabajadores."
            : "Solo tus turnos."}
        </p>
        <table>
          <thead>
            <tr>
              <th>Comprobante</th>
              <th>Fecha Chile</th>
              <th>Trabajador</th>
              <th>Cliente</th>
              <th>Total</th>
              <th>Devuelto</th>
              <th>Detalle</th>
            </tr>
          </thead>
          <tbody>
            {sales.map((s) => (
              <tr key={s.id}>
                <td>
                  {s.id.slice(-8).toUpperCase()}
                  {s.demo ? " · DEMO" : ""}
                </td>
                <td>
                  {s.createdAt.toLocaleString("es-CL", {
                    timeZone: "America/Santiago",
                  })}
                </td>
                <td>{s.shift.user.name}</td>
                <td>{s.customer?.name || "Venta de mostrador"}</td>
                <td>{clp(s.total)}</td>
                <td>{clp(s.returns.reduce((a, r) => a + r.amount, 0))}</td>
                <td>
                  <Link href={"/ventas/" + s.id}>Comprobante y devolución</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!sales.length && <p>No hay ventas que coincidan.</p>}
      </section>
    </>
  );
}

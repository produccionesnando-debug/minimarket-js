import { kilograms } from "@/lib/weight";
import Link from "next/link";
import { getBrand } from "@/lib/brand";
import { BrandLogo } from "@/components/brand-logo";
import { notFound } from "next/navigation";
import { randomUUID } from "node:crypto";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { clp } from "@/lib/money";
import { outstanding } from "@/lib/pos";
import { Card } from "@/components/ui";

import { ReturnForm } from "@/components/return-form";
export default async function Receipt({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const actor = await requireUser();
  const brand = await getBrand();
  const { id } = await params;
  const sale = await db.sale.findFirst({
    where: {
      id,
      ...(!can(actor.role, "shifts:manage")
        ? { shift: { userId: actor.id } }
        : {}),
    },
    include: {
      shift: { include: { user: true } },
      items: { include: { product: true, returnLines: true } },
      collections: true,
      customerPayments: true,
      customer: true,
      returns: { include: { lines: true } },
    },
  });
  if (!sale) notFound();
  const shift = await db.shift.findFirst({
    where: { userId: actor.id, closedAt: null, demo: sale.demo },
  });
  return (
    <>
      <div className="page-heading no-print">
        <h1>Detalle de venta</h1>
        <div className="toolbar">
          <Link className="button secondary" href="/ventas">
            Volver a vender
          </Link>
          <Link className="button secondary" href={"/ticket/" + sale.id}>
            Ver e imprimir ticket
          </Link>
        </div>
      </div>
      <article className="card receipt-paper">
        <BrandLogo brand={brand} variant="receipt" />
        <h2>Comprobante interno de venta</h2>
        <p>
          <strong>No es boleta ni factura tributaria.</strong>
          {sale.demo || process.env.DEMO_INSTANCE === "1"
            ? " · DEMOSTRACIÓN"
            : ""}
        </p>
        <dl className="profile-details">
          <div>
            <dt>Venta</dt>
            <dd>{sale.id}</dd>
          </div>
          <div>
            <dt>Fecha y hora Chile</dt>
            <dd>
              {sale.createdAt.toLocaleString("es-CL", {
                timeZone: "America/Santiago",
              })}
            </dd>
          </div>
          <div>
            <dt>Trabajador</dt>
            <dd>{sale.shift.user.name}</dd>
          </div>
          <div>
            <dt>Caja</dt>
            <dd>{sale.shift.register}</dd>
          </div>
          {sale.customer && (
            <div>
              <dt>Cliente</dt>
              <dd>{sale.customer.name}</dd>
            </div>
          )}
        </dl>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad / peso</th>
                <th>Precio unitario</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {sale.items.map((i) => (
                <tr key={i.id}>
                  <td>{i.productName || i.product.name}</td>
                  <td>
                    {i.weightGrams ? kilograms(i.weightGrams) : i.quantity}
                  </td>
                  <td>{clp(i.unitPrice)}{i.weightGrams?" / kg":""}</td>
                  <td>{clp(i.lineTotal ?? i.unitPrice * i.quantity)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {sale.discount > 0 && (
          <p>
            Descuento autorizado: {clp(sale.discount)} · {sale.discountReason}
          </p>
        )}
        <div className="pos-total">
          <small>Total de la venta original</small>
          <strong>{clp(sale.total)}</strong>
        </div>
        <h3>Cobros registrados</h3>
        {sale.paymentVersion === 0 ? (
          <p>
            {sale.method} · {clp(sale.total)}
          </p>
        ) : (
          sale.collections
            .filter((c) => c.kind === "VENTA")
            .map((c) => (
              <div className="stock-row" key={c.id}>
                <span>{c.method}</span>
                <strong>{clp(c.amount)}</strong>
                {c.tendered !== null && (
                  <small>
                    Recibido {clp(c.tendered)} · vuelto{" "}
                    {clp(c.tendered - c.amount)}
                  </small>
                )}
              </div>
            ))
        )}
        {sale.creditAmount > 0 && (
          <p>
            Crédito original {clp(sale.creditAmount)} · Abonos{" "}
            {clp(sale.customerPayments.reduce((a, p) => a + p.amount, 0))} ·
            Saldo pendiente {clp(outstanding(sale))} · Vence{" "}
            {sale.dueDate?.toLocaleDateString("es-CL", { timeZone: "UTC" })}
          </p>
        )}
      </article>
      {sale.returns.map((r) => (
        <Card key={r.id} title="Devolución registrada">
          <p>
            {r.createdAt.toLocaleString("es-CL", {
              timeZone: "America/Santiago",
            })}{" "}
            · {r.reason}
          </p>
          <p>
            Total devuelto {clp(r.amount)} · Reducción de deuda{" "}
            {clp(r.creditReduction)} · Reembolso{" "}
            {clp(r.amount - r.creditReduction)}
          </p>
          <Link
            className="button secondary no-print"
            href={"/ventas?cambio=" + r.id}
          >
            Registrar producto de cambio
          </Link>
        </Card>
      ))}
      {can(actor.role, "returns:approve") && (
        <section className="card no-print">
          <h2>Devolver productos de esta venta</h2>
          {shift ? (
            <ReturnForm
              saleId={sale.id}
              shiftId={shift.id}
              requestKey={randomUUID()}
              items={sale.items.map((i) => ({
                id: i.id,
                name: i.productName || i.product.name,
                weight: !!i.weightGrams,
                remaining: i.weightGrams
                  ? i.weightGrams -
                    i.returnLines.reduce((a, r) => a + (r.weightGrams || 0), 0)
                  : i.quantity -
                    i.returnLines.reduce((a, r) => a + r.quantity, 0),
              }))}
            />
          ) : (
            <p>
              Abre una caja del mismo modo real/demo para registrar reembolsos y
              devoluciones.
            </p>
          )}
        </section>
      )}
    </>
  );
}

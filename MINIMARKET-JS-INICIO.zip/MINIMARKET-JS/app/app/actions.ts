"use server";
import { gramsFromInput, weightBased, knownCodeName } from "@/lib/weight";
import { can } from "@/lib/permissions";
import { serial, ownedShift, expectedCash, closeCash } from "@/lib/cash";
import { createExpense } from "@/lib/expenses";
import { randomUUID } from "node:crypto";
import { todayChile } from "@/lib/dates";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { refresh, revalidatePath } from "next/cache";
import { compare } from "bcryptjs";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, hashToken } from "@/lib/auth";
import { audit } from "@/lib/mutations";
import { cashExpected, METHODS } from "@/lib/money";
const integer = (f: FormData, key: string, min = 0) =>
  z.coerce.number().int().min(min).max(1000000000).parse(f.get(key));
const text = (f: FormData, key: string) =>
  z.string().trim().min(1).max(500).parse(f.get(key));
export async function login(f: FormData) {
  const parsed = z.email().max(254).safeParse(f.get("email"));
  if (!parsed.success || String(f.get("password")).length > 100)
    redirect("/login?error=1");
  const email = parsed.data.toLowerCase();
  const attempt = await db.loginAttempt.findUnique({ where: { email } });
  if (attempt?.blockedUntil && attempt.blockedUntil > new Date())
    redirect("/login?error=1");
  const user = await db.user.findUnique({ where: { email } });
  const valid = await compare(
    String(f.get("password")),
    user?.password ||
      "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxU2fDlLHRDEHL6c7N7jR0aV5Ze",
  );
  if (!user || !user.active || !valid) {
    const failures =
      (attempt?.blockedUntil && attempt.blockedUntil <= new Date()
        ? 0
        : attempt?.failures || 0) + 1;
    await db.loginAttempt.upsert({
      where: { email },
      create: {
        email,
        failures,
        blockedUntil: failures >= 5 ? new Date(Date.now() + 15 * 60000) : null,
      },
      update: {
        failures,
        blockedUntil: failures >= 5 ? new Date(Date.now() + 15 * 60000) : null,
      },
    });
    redirect("/login?error=1");
  }
  await db.loginAttempt.deleteMany({ where: { email } });
  const token = randomBytes(32).toString("hex");
  await db.$transaction(async (tx) => {
    await tx.session.create({
      data: {
        token: hashToken(token),
        userId: user.id,
        expires: new Date(Date.now() + 86400000),
      },
    });
    await audit(tx, user, "SESION_INICIADA", "Usuario", user.id, {
      role: user.role,
    });
  });
  const secure = (await headers()).get("x-forwarded-proto") === "https";
  (await cookies()).set("mm_mobile_entry", "1", {
    path: "/",
    sameSite: "lax",
    maxAge: 120,
  });
  (await cookies()).set("mm_session", token, {
    httpOnly: true,
    secure,
    sameSite: "lax",
    path: "/",
    maxAge: 86400,
  });
  redirect("/inicio");
}
export async function logout() {
  const jar = await cookies();
  const token = jar.get("mm_session")?.value;
  if (token)
    await db.session.deleteMany({ where: { token: hashToken(token) } });
  jar.delete("mm_session");
  redirect("/login");
}
export async function saveProduct(f: FormData) {
  await requireUser(true);
  const id = String(f.get("id") || "");
  const data = {
    name: text(f, "name"),
    brand: String(f.get("brand") || "")
      .trim()
      .slice(0, 100),
    barcode: text(f, "barcode"),
    price: integer(f, "price"),
    cost: integer(f, "cost"),
    stock: integer(f, "stock"),
    minimum: integer(f, "minimum"),
  };
  const categoryId = String(f.get("categoryId") || "") || null;
  const category = categoryId
    ? await db.category.findFirstOrThrow({
        where: { id: categoryId, active: true },
      })
    : null;
  const defaultSupplierId = String(f.get("defaultSupplierId") || "") || null;
  if (defaultSupplierId)
    await db.supplier.findFirstOrThrow({
      where: { id: defaultSupplierId, active: true },
    });
  const extras = {
    categoryId,
    defaultSupplierId,
    internalCode: String(f.get("internalCode") || "").trim() || null,
    category: category?.name || String(f.get("category") || "").slice(0, 100),
    costKnown: String(f.get("cost") || "").trim() !== "",
    priceKnown: Number(f.get("price")) > 0,
    stockKnown:
      String(
        f.get(
          ["PESO", "VARIABLE"].includes(String(f.get("unitType")))
            ? "weightKg"
            : "stock",
        ) || "",
      ).trim() !== "",
    manualStockPolicy: z
      .enum(["PENDING", "ESTIMATE"])
      .parse(f.get("manualStockPolicy") || "PENDING"),
    ...(f.get("activePresent") === "1"
      ? { active: f.get("active") === "on" }
      : {}),
    leadTimeDays:
      String(f.get("leadTimeDays") || "").trim() === ""
        ? null
        : z
            .number()
            .int()
            .min(0)
            .max(365)
            .parse(Number(f.get("leadTimeDays"))),
    quickSale: f.get("quickSale") === "on",
    stockGrams:
      ["PESO", "VARIABLE"].includes(String(f.get("unitType"))) &&
      Number(f.get("weightKg")) > 0
        ? gramsFromInput(String(f.get("weightKg")), "kg")
        : 0,
    presentation: String(f.get("presentation") || "").slice(0, 150),
    flavor: String(f.get("flavor") || "").slice(0, 100),
    unitType: z
      .enum([
        "UNIDAD",
        "PESO",
        "VARIABLE",
        "BIDON_LLENO",
        "BIDON_VACIO",
        "BIDON_RETORNABLE",
      ])
      .parse(f.get("unitType") || "UNIDAD"),
  };
  const actor = await requireUser(true);
  await serial(async (tx) => {
    const before = id
      ? await tx.product.findUniqueOrThrow({ where: { id } })
      : null;
    if (before && !extras.stockKnown) {
      data.stock = before.stock;
      extras.stockGrams = before.stockGrams;
      extras.stockKnown = before.stockKnown;
    }
    if (before && before.version !== Number(f.get("version")))
      throw Error(
        "El producto cambió. Recarga antes de ajustar stock o precios.",
      );
    if (
      !knownCodeName(extras.internalCode || "", data.name) ||
      !knownCodeName(data.barcode, data.name)
    )
      throw Error("El código 20 está reservado para Pan.");
    if (
      extras.manualStockPolicy === "ESTIMATE" &&
      (!extras.priceKnown || !extras.stockKnown)
    )
      throw Error(
        "Confirma precio por kg y stock antes de descontar estimaciones.",
      );
    if (
      before &&
      before.unitType !== extras.unitType &&
      (before.stock || before.stockGrams)
    )
      throw Error("No cambies la unidad mientras existan existencias.");
    if (weightBased(extras)) data.stock = 0;
    const codes = [data.barcode, extras.internalCode].filter(
      (c): c is string => !!c,
    );
    if (
      await tx.product.findFirst({
        where: {
          id: { not: id || "" },
          OR: [{ barcode: { in: codes } }, { internalCode: { in: codes } }],
        },
      })
    )
      throw Error("Código duplicado.");
    if (extras.internalCode) {
      const reserved = await tx.internalProductCode.findUnique({
        where: { code: extras.internalCode },
      });
      if (reserved && reserved.productId !== id)
        throw Error("El código interno ya fue utilizado.");
    }
    const product = before
      ? await tx.product.update({
          where: { id },
          data: { ...data, ...extras, version: { increment: 1 } },
        })
      : await tx.product.create({ data: { ...data, ...extras } });
    if (extras.internalCode)
      await tx.internalProductCode.upsert({
        where: { code: extras.internalCode },
        create: { code: extras.internalCode, productId: product.id },
        update: {},
      });
    if (extras.stockGrams !== (before?.stockGrams || 0))
      await tx.stockMovement.create({
        data: {
          productId: product.id,
          type: "AJUSTE",
          quantity: 0,
          weightGrams: extras.stockGrams - (before?.stockGrams || 0),
          note: "Conteo de peso en inventario",
          actorId: actor.id,
        },
      });
    if (defaultSupplierId)
      await tx.supplier.update({
        where: { id: defaultSupplierId },
        data: { products: { connect: { id: product.id } } },
      });
    if (
      !before ||
      before.price !== product.price ||
      before.cost !== product.cost
    )
      await tx.priceChange.create({
        data: {
          productId: product.id,
          actorId: actor.id,
          before: before ? { price: before.price, cost: before.cost } : {},
          after: { price: product.price, cost: product.cost },
          reason: "Edición administrativa en inventario",
        },
      });
    const delta = data.stock - (before?.stock ?? 0);
    if (delta)
      await tx.stockMovement.create({
        data: {
          productId: product.id,
          type: "AJUSTE",
          quantity: delta,
          note: "Conteo ingresado en Inventario",
          actorId: actor.id,
        },
      });
    await audit(tx, actor, "PRODUCTO_GUARDADO", "Producto", product.id, {
      ...data,
      ...extras,
      previousStock: before?.stock ?? null,
    });
  });
  revalidatePath("/inventario");
  revalidatePath("/inicio", "layout");
  redirect("/inventario?q=" + encodeURIComponent(data.barcode));
}
export async function openShift(f: FormData) {
  const user = await requireUser();
  const userId = String(f.get("userId") || user.id);
  if (userId !== user.id && !can(user.role, "shifts:manage"))
    throw Error("No autorizado");
  await serial(async (tx) => {
    if (!(await tx.user.findFirst({ where: { id: userId, active: true } })))
      throw Error("Responsable no disponible");
    if (await tx.shift.findFirst({ where: { userId, closedAt: null } })) return;
    const shift = await tx.shift.create({
      data: {
        userId,
        opening: integer(f, "opening"),
        register:
          String(f.get("register") || "Caja principal")
            .trim()
            .slice(0, 100) || "Caja principal",
        openingNotes: String(f.get("openingNotes") || "").slice(0, 1000),
        openedById: user.id,
        demo: f.get("demo") === "on",
      },
    });
    await audit(tx, user, "CAJA_ABIERTA", "Caja", shift.id, {
      userId,
      opening: shift.opening,
    });
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
}
export async function sell(f: FormData) {
  const actor = await requireUser();
  const quantity = integer(f, "quantity", 1),
    method = z.enum(METHODS).parse(f.get("method"));
  const product = await db.product.findUniqueOrThrow({
    where: { id: text(f, "productId") },
  });
  if (weightBased(product))
    throw Error("Usa Ventas y Caja para ingresar peso o importe manual.");
  const { checkout } = await import("@/lib/pos");
  await checkout(actor, {
    requestKey: String(f.get("requestKey") || randomUUID()),
    shiftId: String(f.get("shiftId") || ""),
    lines: [{ productId: product.id, quantity, expectedPrice: product.price }],
    payments: [
      {
        method,
        amount: product.price * quantity,
        ...(method === "EFECTIVO"
          ? { tendered: product.price * quantity }
          : { confirmed: f.get("bankVerified") === "on" }),
      },
    ],
  });
  revalidatePath("/caja");
  revalidatePath("/inventario");
  revalidatePath("/inicio", "layout");
  refresh();
}
export async function expense(f: FormData) {
  const user = await requireUser();
  await createExpense(user, {
    requestKey: String(f.get("requestKey") || randomUUID()),
    description: text(f, "description"),
    amount: integer(f, "amount", 1),
    category: "Sin categoría",
    method: "EFECTIVO",
    date: todayChile(),
    shiftId: String(f.get("shiftId") || "") || undefined,
    responsibleId: String(f.get("responsibleId") || user.id),
    beneficiary: "",
    notes: "",
    kind: "OPERATIVO",
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
  revalidatePath("/gastos");
}
export async function closeShift(f: FormData) {
  const user = await requireUser();
  await closeCash(
    user,
    String(f.get("shiftId") || ""),
    integer(f, "counted"),
    String(f.get("closingNotes") || ""),
  );
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
}

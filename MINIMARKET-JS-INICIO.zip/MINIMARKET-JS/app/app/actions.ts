"use server";
import { can } from "@/lib/permissions";
import { serial, ownedShift, expectedCash } from "@/lib/cash";
import { createExpense } from "@/lib/expenses";
import { randomUUID } from "node:crypto";
import { todayChile } from "@/lib/dates";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { compare } from "bcryptjs";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, hashToken } from "@/lib/auth";
import { audit } from "@/lib/mutations";
import { cashExpected, METHODS } from "@/lib/money";
const integer = (f: FormData, key: string, min = 0) =>
  z.coerce.number().int().min(min).max(1000000000).parse(f.get(key));
const text = (f: FormData, key: string) =>
  z.string().trim().min(1).max(500).parse(f.get(key));
export async function login(f: FormData) {
  const parsed = z.email().max(254).safeParse(f.get("email"));
  if (!parsed.success || String(f.get("password")).length > 100)
    redirect("/login?error=1");
  const email = parsed.data.toLowerCase();
  const attempt = await db.loginAttempt.findUnique({ where: { email } });
  if (attempt?.blockedUntil && attempt.blockedUntil > new Date())
    redirect("/login?error=1");
  const user = await db.user.findUnique({ where: { email } });
  const valid = await compare(
    String(f.get("password")),
    user?.password ||
      "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxU2fDlLHRDEHL6c7N7jR0aV5Ze",
  );
  if (!user || !user.active || !valid) {
    const failures =
      (attempt?.blockedUntil && attempt.blockedUntil <= new Date()
        ? 0
        : attempt?.failures || 0) + 1;
    await db.loginAttempt.upsert({
      where: { email },
      create: {
        email,
        failures,
        blockedUntil: failures >= 5 ? new Date(Date.now() + 15 * 60000) : null,
      },
      update: {
        failures,
        blockedUntil: failures >= 5 ? new Date(Date.now() + 15 * 60000) : null,
      },
    });
    redirect("/login?error=1");
  }
  await db.loginAttempt.deleteMany({ where: { email } });
  const token = randomBytes(32).toString("hex");
  await db.$transaction(async (tx) => {
    await tx.session.create({
      data: {
        token: hashToken(token),
        userId: user.id,
        expires: new Date(Date.now() + 86400000),
      },
    });
    await audit(tx, user, "SESION_INICIADA", "Usuario", user.id, {
      role: user.role,
    });
  });
  const secure = (await headers()).get("x-forwarded-proto") === "https";
  (await cookies()).set("mm_session", token, {
    httpOnly: true,
    secure,
    sameSite: "lax",
    path: "/",
    maxAge: 86400,
  });
  redirect("/inicio");
}
export async function logout() {
  const jar = await cookies();
  const token = jar.get("mm_session")?.value;
  if (token)
    await db.session.deleteMany({ where: { token: hashToken(token) } });
  jar.delete("mm_session");
  redirect("/login");
}
export async function saveProduct(f: FormData) {
  await requireUser(true);
  const id = String(f.get("id") || "");
  const data = {
    name: text(f, "name"),
    brand: text(f, "brand"),
    barcode: text(f, "barcode"),
    price: integer(f, "price"),
    cost: integer(f, "cost"),
    stock: integer(f, "stock"),
    minimum: integer(f, "minimum"),
  };
  const extras = {
    category: String(f.get("category") || "").slice(0, 100),
    presentation: String(f.get("presentation") || "").slice(0, 150),
    flavor: String(f.get("flavor") || "").slice(0, 100),
    unitType: z
      .enum(["UNIDAD", "BIDON_LLENO", "BIDON_VACIO", "BIDON_RETORNABLE"])
      .parse(f.get("unitType") || "UNIDAD"),
  };
  const actor = await requireUser(true);
  await serial(async (tx) => {
    const before = id
      ? await tx.product.findUniqueOrThrow({ where: { id } })
      : null;
    const product = before
      ? await tx.product.update({ where: { id }, data: { ...data, ...extras } })
      : await tx.product.create({ data: { ...data, ...extras } });
    const delta = data.stock - (before?.stock ?? 0);
    if (delta)
      await tx.stockMovement.create({
        data: {
          productId: product.id,
          type: "AJUSTE",
          quantity: delta,
          note: "Conteo ingresado en Inventario",
          actorId: actor.id,
        },
      });
    await audit(tx, actor, "PRODUCTO_GUARDADO", "Producto", product.id, {
      ...data,
      ...extras,
      previousStock: before?.stock ?? null,
    });
  });
  revalidatePath("/inventario");
  revalidatePath("/inicio", "layout");
}
export async function openShift(f: FormData) {
  const user = await requireUser();
  const userId = String(f.get("userId") || user.id);
  if (userId !== user.id && !can(user.role, "shifts:manage"))
    throw Error("No autorizado");
  await serial(async (tx) => {
    if (!(await tx.user.findFirst({ where: { id: userId, active: true } })))
      throw Error("Responsable no disponible");
    if (await tx.shift.findFirst({ where: { userId, closedAt: null } })) return;
    const shift = await tx.shift.create({
      data: {
        userId,
        opening: integer(f, "opening"),
        openedById: user.id,
        demo: f.get("demo") === "on",
      },
    });
    await audit(tx, user, "CAJA_ABIERTA", "Caja", shift.id, {
      userId,
      opening: shift.opening,
    });
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
}
export async function sell(f: FormData) {
  const user = await requireUser();
  const quantity = integer(f, "quantity", 1);
  const method = z.enum(METHODS).parse(f.get("method"));
  await serial(async (tx) => {
    const shift = await ownedShift(tx, user, String(f.get("shiftId") || ""));
    const requestKey = String(f.get("requestKey") || randomUUID());
    if (await tx.sale.findUnique({ where: { requestKey } })) return;
    const product = await tx.product.findUniqueOrThrow({
      where: { id: text(f, "productId") },
    });
    if (product.demo !== shift.demo)
      throw Error(
        "El producto y la caja deben pertenecer al mismo modo real o demo.",
      );
    const updated = await tx.product.updateMany({
      where: { id: product.id, stock: { gte: quantity } },
      data: { stock: { decrement: quantity } },
    });
    if (!updated.count) throw Error("Stock insuficiente");
    const sale = await tx.sale.create({
      data: {
        shiftId: shift.id,
        requestKey,
        actorId: user.id,
        demo: shift.demo || product.demo,
        method,
        total: product.price * quantity,
        items: {
          create: {
            productId: product.id,
            quantity,
            unitPrice: product.price,
            unitCost: product.cost,
            category: product.category,
          },
        },
      },
    });
    await audit(tx, user, "VENTA_REGISTRADA", "Venta", sale.id, {
      shiftId: shift.id,
      productId: product.id,
      quantity,
      method,
      total: sale.total,
      requestKey,
    });
    await tx.stockMovement.create({
      data: {
        productId: product.id,
        type: "VENTA",
        quantity: -quantity,
        note: "Venta presencial",
        actorId: user.id,
      },
    });
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
  revalidatePath("/inventario");
  revalidatePath("/inicio", "layout");
}
export async function expense(f: FormData) {
  const user = await requireUser();
  await createExpense(user, {
    requestKey: String(f.get("requestKey") || randomUUID()),
    description: text(f, "description"),
    amount: integer(f, "amount", 1),
    category: "Sin categoría",
    method: "EFECTIVO",
    date: todayChile(),
    shiftId: String(f.get("shiftId") || "") || undefined,
    responsibleId: String(f.get("responsibleId") || user.id),
    beneficiary: "",
    notes: "",
    kind: "OPERATIVO",
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
  revalidatePath("/gastos");
}
export async function closeShift(f: FormData) {
  const user = await requireUser();
  await serial(async (tx) => {
    const shift = await ownedShift(tx, user, String(f.get("shiftId") || ""));
    const expected = await expectedCash(tx, shift.id);
    const counted = integer(f, "counted");
    await audit(tx, user, "CAJA_CERRADA", "Caja", shift.id, {
      expected,
      counted,
      difference: counted - expected,
    });
    await tx.shift.update({
      where: { id: shift.id },
      data: {
        closedAt: new Date(),
        counted,
        expected,
        difference: counted - expected,
      },
    });
  });
  revalidatePath("/caja");
  revalidatePath("/inicio", "layout");
}

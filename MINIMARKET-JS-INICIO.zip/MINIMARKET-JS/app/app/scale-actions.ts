"use server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { allow } from "@/lib/pos";
import { serial } from "@/lib/cash";
import { audit, mutation, type ActionResult } from "@/lib/mutations";
import { revalidatePath } from "next/cache";
export async function scalePatternAction(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    allow(actor, "prices:write");
    const int = (name: string) => Number(f.get(name));
    const p = z
      .object({
        model: z.string().trim().min(2).max(100),
        prefix: z.string().min(1).max(10),
        codeLength: z.number().int().min(8).max(40),
        productStart: z.number().int().min(0).max(30),
        productLength: z.number().int().min(1).max(15),
        valueStart: z.number().int().min(0).max(30),
        valueLength: z.number().int().min(1).max(12),
        decimals: z.number().int().min(0).max(3),
        kind: z.enum(["WEIGHT", "AMOUNT"]),
      })
      .parse({
        model: f.get("model"),
        prefix: f.get("prefix"),
        codeLength: int("codeLength"),
        productStart: int("productStart"),
        productLength: int("productLength"),
        valueStart: int("valueStart"),
        valueLength: int("valueLength"),
        decimals: int("decimals"),
        kind: f.get("kind"),
      });
    if (
      p.productStart + p.productLength > p.codeLength ||
      p.valueStart + p.valueLength > p.codeLength
    )
      throw Error("Campos fuera del código.");
    await serial(async (tx) => {
      await tx.scalePattern.upsert({
        where: { id: "global" },
        create: { ...p, enabled: false },
        update: { ...p, enabled: false },
      });
      await audit(tx, actor, "BALANZA_PREPARADA", "Configuración", "global", {
        ...p,
        enabled: false,
      });
    });
    revalidatePath("/balanza");
  }, "Patrón guardado desactivado. Falta validar etiquetas reales del modelo antes de habilitarlo en caja.");
}

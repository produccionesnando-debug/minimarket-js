import { readFile } from "node:fs/promises";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { uploadPath, type StoredUpload } from "@/lib/uploads";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const u = await requireUser();
  const { id } = await params;
  const loss = await db.stockLoss.findFirst({
    where: {
      id,
      ...(!can(u.role, "expenses:readAll") ? { responsibleId: u.id } : {}),
    },
  });
  if (!loss?.photo) return new Response("No encontrado", { status: 404 });
  const photo = loss.photo as unknown as StoredUpload;
  try {
    return new Response(
      new Uint8Array(await readFile(uploadPath(photo.storageKey))),
      {
        headers: {
          "Content-Type": photo.mime,
          "Content-Disposition": "inline",
          "Cache-Control": "private, no-store",
          "X-Content-Type-Options": "nosniff",
          "Content-Security-Policy": "default-src 'none'; sandbox",
        },
      },
    );
  } catch {
    return new Response("No encontrado", { status: 404 });
  }
}

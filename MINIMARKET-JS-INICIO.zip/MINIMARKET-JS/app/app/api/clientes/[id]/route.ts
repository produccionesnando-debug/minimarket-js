import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { outstanding } from "@/lib/pos";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  await requireUser();
  const { id } = await params;
  const customer = await db.customer.findUnique({
    where: { id },
    include: {
      sales: {
        include: {
          returns: true,
          customerPayments: { include: { collection: true } },
        },
        orderBy: { createdAt: "asc" },
      },
    },
  });
  if (!customer) return new Response("No encontrado", { status: 404 });
  const cell = (v: unknown) =>
    '"' +
    String(v ?? "")
      .replace(/^[=+@-]/, "'$&")
      .replaceAll('"', '""') +
    '"';
  const rows: unknown[][] = [
    [
      "MINIMARKET JS",
      customer.demo || process.env.DEMO_INSTANCE === "1"
        ? "DEMOSTRACIÓN"
        : "DATOS REALES",
    ],
    [
      "Cliente",
      "Tipo",
      "Fecha Chile",
      "Referencia",
      "Venta",
      "Crédito original",
      "Abono",
      "Ajuste por devolución",
      "Saldo actual",
      "Medio",
      "Responsable",
    ],
  ];
  for (const s of customer.sales) {
    rows.push([
      customer.name,
      "COMPRA",
      s.createdAt.toLocaleString("es-CL", { timeZone: "America/Santiago" }),
      s.id,
      s.total,
      s.creditAmount,
      "",
      s.returns.reduce((a, r) => a + r.creditReduction, 0),
      outstanding(s),
      "",
      s.creditAuthorizedById || s.actorId,
    ]);
    for (const p of s.customerPayments)
      rows.push([
        customer.name,
        "ABONO",
        p.createdAt.toLocaleString("es-CL", { timeZone: "America/Santiago" }),
        p.reference,
        "",
        "",
        p.amount,
        "",
        "",
        p.collection?.method,
        p.actorId,
      ]);
  }
  return new Response(
    "\uFEFF" + rows.map((r) => r.map(cell).join(";")).join("\r\n"),
    {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition":
          'attachment; filename="estado-cuenta-cliente.csv"',
        "Cache-Control": "private, no-store",
      },
    },
  );
}

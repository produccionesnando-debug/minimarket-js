import { brandAsset } from "@/lib/brand";
export async function GET(request: Request) {
  const requested = new URL(request.url).searchParams.get("size"),
    size = requested ? Number(requested) : undefined;
  if (size !== undefined && ![16, 32, 180, 192, 512].includes(size))
    return new Response("Tamaño no válido", { status: 400 });
  const asset = await brandAsset(
    size,
    new URL(request.url).searchParams.get("mono") === "1",
  );
  if (!asset)
    return new Response(null, {
      status: 404,
      headers: { "Cache-Control": "no-store" },
    });
  return new Response(new Uint8Array(asset.bytes), {
    headers: {
      "Content-Type": asset.mime,
      "Cache-Control": "private, max-age=60",
      ETag:
        '"' +
        asset.sha256 +
        (size || "original") +
        (new URL(request.url).searchParams.get("mono") === "1" ? "mono" : "") +
        '"',
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'",
    },
  });
}

import ExcelJS from "exceljs";
import { PDFDocument, StandardFonts } from "pdf-lib";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { getReport, reportInput } from "@/lib/reports";
export const runtime = "nodejs";
function safeCell(value: unknown) {
  const s = String(value ?? "");
  return /^[=+@\-\t\r]/.test(s) ? "'" + s : s;
}
export async function GET(request: Request) {
  const user = await requireUser();
  if (!can(user.role, "stats:read"))
    return new Response("Sin permiso", { status: 403 });
  const p = Object.fromEntries(new URL(request.url).searchParams);
  let r;
  try {
    r = await getReport(reportInput(p));
  } catch {
    return new Response("Período inválido", { status: 400 });
  }
  const rows: (string | number)[][] = [
    ["MINIMARKET JS", r.input.demo ? "DEMOSTRACIÓN" : "DATOS REALES"],
    ["Desde", r.input.from],
    ["Hasta", r.input.to],
    ["Ventas registradas", r.totals.sales],
    ["Gastos operativos", r.totals.operatingExpenses],
    ["Compras facturadas", r.totals.purchases],
    ["Pagos proveedores", r.totals.payments],
    ["Retiros", r.totals.withdrawals],
    ["Flujo efectivo", r.totals.cashFlow],
    [
      "Margen bruto estimado",
      r.totals.grossMargin ?? "Información insuficiente",
    ],
    [
      "Resultado operativo estimado",
      r.totals.estimatedOperatingResult ?? "Información insuficiente",
    ],
    ["Saldo proveedores actual", r.totals.payable],
    [],
    ["Período", "Ventas", "Gastos", "Compras", "Pagos", "Flujo efectivo"],
    ...r.timeline.map((t) => [
      t.label,
      t.ventas,
      t.gastos,
      t.compras,
      t.pagos,
      t.efectivo,
    ]),
    [],
    ["Ventas por trabajador", "CLP"],
    ...r.byWorker.map((v) => [v.label, v.value]),
    [],
    ["Ventas por medio", "CLP"],
    ...r.byMethod.map((v) => [v.label, v.value]),
    [],
    ["Compras por proveedor", "CLP"],
    ...r.bySupplier.map((v) => [v.label, v.value]),
    [],
    ["Gastos por categoría", "CLP"],
    ...r.byCategory.map((v) => [v.label, v.value]),
    [],
    ["Productos vendidos", "Unidades"],
    ...r.topProducts.map((v) => [v.label, v.value]),
    [],
    ["Stock actual", "Unidades", "Rotación"],
    ...r.stock.map((v) => [v.label, v.stock, v.rotation ?? "Insuficiente"]),
  ];
  const headers = {
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff",
  };
  if (p.formato === "xlsx") {
    const book = new ExcelJS.Workbook();
    const sheet = book.addWorksheet("Informe");
    rows.forEach((row) =>
      sheet.addRow(row.map((v) => (typeof v === "number" ? v : safeCell(v)))),
    );
    sheet.columns.forEach((c) => (c.width = 28));
    const bytes = await book.xlsx.writeBuffer();
    return new Response(new Uint8Array(bytes), {
      headers: {
        ...headers,
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": 'attachment; filename="minimarket-informe.xlsx"',
      },
    });
  }
  if (p.formato === "pdf") {
    const pdf = await PDFDocument.create();
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    let page = pdf.addPage();
    let y = 790;
    for (const row of rows) {
      if (y < 40) {
        page = pdf.addPage();
        y = 790;
      }
      const text = row.join(" | ").replace(/[^\x20-\x7e\xa0-\xff]/g, "?");
      const segments = text.match(/.{1,100}/g) || [" "];
      for (const line of segments) {
        if (y < 40) {
          page = pdf.addPage();
          y = 790;
        }
        page.drawText(line, { x: 30, y, size: 9, font });
        y -= 14;
      }
    }
    return new Response(new Uint8Array(await pdf.save()), {
      headers: {
        ...headers,
        "Content-Type": "application/pdf",
        "Content-Disposition": 'attachment; filename="minimarket-informe.pdf"',
      },
    });
  }
  const csv =
    "\ufeff" +
    rows
      .map((row) =>
        row.map((v) => '"' + safeCell(v).replaceAll('"', '""') + '"').join(";"),
      )
      .join("\r\n");
  return new Response(csv, {
    headers: {
      ...headers,
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="minimarket-informe.csv"',
    },
  });
}

import { NextResponse } from "next/server";
import { beginGoogle, googleReady } from "@/lib/google";
export async function GET(request: Request) {
  if (!googleReady())
    return NextResponse.redirect(
      new URL("/login?google=configuracion", request.url),
    );
  try {
    const { url, browser } = await beginGoogle();
    const res = NextResponse.redirect(url);
    res.cookies.set("mm_google", browser, {
      httpOnly: true,
      secure:
        url.protocol === "https:" && process.env.APP_URL?.startsWith("https:"),
      sameSite: "lax",
      maxAge: 600,
      path: "/api/auth/google",
    });
    return res;
  } catch {
    return NextResponse.redirect(new URL("/login?google=error", request.url));
  }
}

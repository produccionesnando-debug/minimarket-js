import { NextRequest, NextResponse } from "next/server";
import { finishGoogle, appOrigin } from "@/lib/google";
export async function GET(request: NextRequest) {
  try {
    const token = await finishGoogle(
      new URL(request.url),
      request.cookies.get("mm_google")?.value,
    );
    const res = NextResponse.redirect(new URL("/inicio", appOrigin()));
    res.cookies.set("mm_session", token, {
      httpOnly: true,
      secure: appOrigin().startsWith("https:"),
      sameSite: "lax",
      path: "/",
      maxAge: 86400,
    });
    res.cookies.delete("mm_google");
    return res;
  } catch {
    const res = NextResponse.redirect(
      new URL("/login?google=denegado", request.url),
    );
    res.cookies.delete("mm_google");
    return res;
  }
}

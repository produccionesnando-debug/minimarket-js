import { requireUser } from "@/lib/auth";
import { voucherPdf } from "@/lib/voucher-pdf";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  await requireUser();
  const { id } = await params;
  return new Response(Buffer.from(await voucherPdf(id)), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": 'attachment; filename="voucher-fiado.pdf"',
      "Cache-Control": "private, no-store",
    },
  });
}

import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { expenseScope } from "@/lib/expenses";
import { readUpload } from "@/lib/uploads";
export const runtime = "nodejs";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await requireUser();
  const { id } = await params;
  const attachment = await db.expenseAttachment.findFirst({
    where: { id, expense: expenseScope(user) },
  });
  if (!attachment) return new Response("No encontrado", { status: 404 });
  try {
    const file = await readUpload(attachment.storageKey);
    return new Response(new Uint8Array(file), {
      headers: {
        "Content-Type": attachment.mime,
        "Content-Disposition": `${attachment.mime === "application/pdf" ? "attachment" : "inline"}; filename*=UTF-8''${encodeURIComponent(attachment.originalName)}`,
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "sandbox; default-src 'none'",
      },
    });
  } catch {
    return new Response("Archivo no disponible", { status: 404 });
  }
}

import { timingSafeEqual } from "node:crypto";
import { verifyMetaSignature, ingestWhatsApp } from "@/lib/whatsapp-webhook";
export async function GET(request: Request) {
  const u = new URL(request.url),
    token = u.searchParams.get("hub.verify_token") || "",
    expected = process.env.WHATSAPP_VERIFY_TOKEN;
  if (
    !expected ||
    Buffer.byteLength(token) !== Buffer.byteLength(expected) ||
    !timingSafeEqual(Buffer.from(token), Buffer.from(expected)) ||
    u.searchParams.get("hub.mode") !== "subscribe"
  )
    return new Response("No autorizado", { status: 403 });
  return new Response(u.searchParams.get("hub.challenge") || "", {
    headers: { "Cache-Control": "no-store" },
  });
}
export async function POST(request: Request) {
  const secret = process.env.WHATSAPP_APP_SECRET,
    id = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!secret || !id)
    return new Response("Integración no configurada", { status: 503 });
  if (Number(request.headers.get("content-length") || 0) > 1000000)
    return new Response("Tamaño excedido", { status: 413 });
  const raw = await request.text();
  if (Buffer.byteLength(raw) > 1000000)
    return new Response("Tamaño excedido", { status: 413 });
  if (
    !verifyMetaSignature(
      raw,
      request.headers.get("x-hub-signature-256"),
      secret,
    )
  )
    return new Response("Firma inválida", { status: 401 });
  try {
    await ingestWhatsApp(JSON.parse(raw), id);
    return Response.json({ received: true });
  } catch {
    return new Response("Recepción no disponible o contenido inválido", {
      status: 422,
    });
  }
}

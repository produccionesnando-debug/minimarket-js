import ExcelJS from "exceljs";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
export async function GET() {
  const u = await requireUser();
  if (!can(u.role, "prices:write"))
    return new Response("Acceso restringido", { status: 403 });
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Productos DEMO");
  ws.addRow([
    "Código de barras",
    "Código interno",
    "Nombre",
    "Marca",
    "Categoría",
    "Presentación",
    "Precio de costo",
    "Precio de venta",
    "Precio PedidosYa",
    "Stock",
    "Stock mínimo",
  ]);
  ws.addRow([
    "000012340001",
    "DEMO-001",
    "DEMO · Producto de prueba",
    "Marca ficticia",
    "Abarrotes",
    "Unidad",
    600,
    1000,
    1200,
    12,
    3,
  ]);
  ws.getColumn(1).numFmt = "@";
  return new Response(new Uint8Array(await wb.xlsx.writeBuffer()), {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition":
        'attachment; filename="catalogo-demostracion.xlsx"',
      "Cache-Control": "private, no-store",
    },
  });
}

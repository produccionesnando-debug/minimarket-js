import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write"))
    return new Response("Acceso restringido", { status: 403 });
  const { id } = await params;
  const batch = await db.productImport.findFirst({
    where: { id, actorId: actor.id, status: "COMPLETED" },
  });
  if (!batch) return new Response("No encontrado", { status: 404 });
  const csv = (v: unknown) =>
    '"' +
    String(v ?? "")
      .replace(/^[=+@-]/, "'$&")
      .replaceAll('"', '""') +
    '"';
  const rows = batch.result as {
    row: number;
    action: string;
    detail: string;
  }[];
  return new Response(
    "\uFEFF" +
      [
        ["Fila", "Resultado", "Detalle"],
        ...rows.map((r) => [r.row, r.action, r.detail]),
      ]
        .map((r) => r.map(csv).join(";"))
        .join("\r\n"),
    {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition":
          'attachment; filename="resultado-importacion.csv"',
        "Cache-Control": "private, no-store",
      },
    },
  );
}

import { toSVG } from "bwip-js/node";
import { requireUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const actor = await requireUser();
  if (!can(actor.role, "prices:write"))
    return new Response("Acceso restringido", { status: 403 });
  const p = await db.product.findUnique({ where: { id: (await params).id } });
  if (!p?.internalCode)
    return new Response("Producto sin código interno", { status: 404 });
  const svg = toSVG({
    bcid: "code128",
    text: p.internalCode,
    scale: 3,
    height: 12,
    includetext: true,
    textxalign: "center",
    paddingwidth: 8,
    paddingheight: 4,
  });
  return new Response(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy":
        "default-src 'none'; style-src 'unsafe-inline'; sandbox",
    },
  });
}

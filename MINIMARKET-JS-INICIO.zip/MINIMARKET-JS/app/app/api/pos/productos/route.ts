import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
export async function GET(r: NextRequest) {
  const actor = await requireUser();
  const p = r.nextUrl.searchParams;
  const editing = p.get("editar") === "1";
  if (editing && !can(actor.role, "prices:write"))
    return Response.json({ error: "Acceso restringido" }, { status: 403 });
  const shift = await db.shift.findFirst({
    where: {
      id: p.get("shift") || "",
      closedAt: null,
      ...(!can(actor.role, "shifts:manage") ? { userId: actor.id } : {}),
    },
  });
  if (!shift)
    return Response.json(
      { error: "Abre una caja autorizada antes de vender." },
      { status: 403 },
    );
  const q = (p.get("q") || "").trim().slice(0, 120),
    code = p.get("codigo")?.slice(0, 100);
  const aliases = code
    ? await db.internalProductCode.findMany({
        where: { code },
        select: { productId: true },
      })
    : [];
  const products = await db.product.findMany({
    where: {
      demo: shift.demo,
      ...(!editing ? { active: true } : {}),
      ...(editing && p.get("id") ? { id: p.get("id")! } : {}),
      ...(code
        ? {
            OR: [
              { barcode: code },
              { internalCode: code },
              { id: { in: aliases.map((a) => a.productId) } },
            ],
          }
        : {
            ...(q
              ? {
                  OR: [
                    { name: { contains: q, mode: "insensitive" } },
                    { brand: { contains: q, mode: "insensitive" } },
                    { barcode: { contains: q } },
                    { internalCode: { contains: q, mode: "insensitive" } },
                  ],
                }
              : {}),
            ...(p.get("categoria") ? { category: p.get("categoria")! } : {}),
            ...(p.get("marca")
              ? { brand: { contains: p.get("marca")!, mode: "insensitive" } }
              : {}),
            ...(p.get("proveedor")
              ? { suppliers: { some: { id: p.get("proveedor")! } } }
              : {}),
            ...(p.get("disponible") === "1"
              ? {
                  AND: [
                    {
                      OR: [
                        { stock: { gt: 0 } },
                        { stockGrams: { gt: 0 } },
                        {
                          unitType: "VARIABLE",
                          manualStockPolicy: "PENDING",
                          stockKnown: false,
                        },
                      ],
                    },
                  ],
                }
              : {}),
          }),
    },
    select: editing
      ? undefined
      : {
          id: true,
          name: true,
          barcode: true,
          internalCode: true,
          price: true,
          stock: true,
          active: true,
          priceKnown: true,
          stockKnown: true,
          manualStockPolicy: true,
          stockGrams: true,
          unitType: true,
          quickSale: true,
          barcodeKind: true,
          category: true,
          brand: true,
        },
    orderBy: [{ quickSale: "desc" }, { name: "asc" }],
    take: code ? 2 : 60,
  });
  return Response.json(
    { products },
    { headers: { "Cache-Control": "private, no-store" } },
  );
}

"use server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { hash } from "bcryptjs";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requirePermission, requireUser } from "@/lib/auth";
import {
  audit,
  mutation,
  ValidationError,
  type ActionResult,
} from "@/lib/mutations";
import {
  supplierValues,
  contactSchema,
  businessDate,
} from "@/lib/supplier-validation";
import { ORDER_STATUSES } from "@/lib/order-status";
const id = (f: FormData, k = "id") =>
  z.string().min(1).max(100).parse(f.get(k));
const version = (f: FormData) =>
  z.coerce.number().int().min(0).parse(f.get("version"));
const refresh = () => {
  revalidatePath("/proveedores/[id]", "page");
  revalidatePath("/pedidos/[id]", "page");
  for (const p of ["/proveedores", "/calendario", "/auditoria"])
    revalidatePath(p, "layout");
};
const serial = <T>(fn: (tx: Prisma.TransactionClient) => Promise<T>) =>
  db.$transaction(fn, {
    isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
  });
async function lockSupplier(
  tx: Prisma.TransactionClient,
  supplierId: string,
  v: number,
) {
  const updated = await tx.supplier.updateMany({
    where: { id: supplierId, version: v, active: true },
    data: { version: { increment: 1 } },
  });
  if (!updated.count)
    throw new ValidationError(
      "El proveedor cambió o está inactivo. Recarga la página antes de continuar.",
    );
}
export async function saveSupplierProfile(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  let created = "";
  const result = await mutation(async () => {
    const supplierId = String(f.get("id") || "");
    const values = supplierValues(
      f,
      !!(
        supplierId && (await db.supplierCycle.count({ where: { supplierId } }))
      ),
    );
    const { productIds, calendarConfigured, ...data } = values;
    await serial(async (tx) => {
      if (supplierId) {
        const before = await tx.supplier.findUniqueOrThrow({
          where: { id: supplierId },
          include: { products: { select: { id: true } } },
        });
        await lockSupplier(tx, supplierId, version(f));
        await tx.supplier.update({
          where: { id: supplierId },
          data: {
            ...data,
            products: { set: productIds.map((id) => ({ id })) },
          },
        });
        await audit(tx, actor, "PROVEEDOR_EDITADO", "Proveedor", supplierId, {
          before: {
            name: before.name,
            category: before.category,
            phone: before.phone,
            whatsapp: before.whatsapp,
            email: before.email,
            productsDescription: before.productsDescription,
            paymentTerms: before.paymentTerms,
            notes: before.notes,
            scheduleMode: before.scheduleMode,
            orderDays: before.orderDays,
            deliveryDays: before.deliveryDays,
            productIds: before.products.map((p) => p.id),
          },
          after: values,
        });
      } else {
        const supplier = await tx.supplier.create({
          data: {
            ...data,
            products: { connect: productIds.map((id) => ({ id })) },
          },
        });
        created = supplier.id;
        await audit(tx, actor, "PROVEEDOR_CREADO", "Proveedor", supplier.id, {
          after: values,
        });
      }
    });
    refresh();
  });
  if (created && result.success) redirect(`/proveedores/${created}?creado=1`);
  return result;
}
export async function toggleSupplier(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  return mutation(async () => {
    await serial(async (tx) => {
      const supplierId = id(f);
      const before = await tx.supplier.findUniqueOrThrow({
        where: { id: supplierId },
      });
      const changed = await tx.supplier.updateMany({
        where: { id: supplierId, version: version(f) },
        data: { active: !before.active, version: { increment: 1 } },
      });
      if (!changed.count)
        throw new ValidationError("Los datos cambiaron. Recarga la página.");
      await audit(
        tx,
        actor,
        before.active ? "PROVEEDOR_DESACTIVADO" : "PROVEEDOR_REACTIVADO",
        "Proveedor",
        supplierId,
        { name: before.name, active: !before.active },
      );
    });
    refresh();
  }, "Estado del proveedor actualizado. El historial se conserva.");
}
export async function saveContact(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  return mutation(async () => {
    const data = contactSchema.parse(
      Object.fromEntries(
        ["name", "role", "phone", "whatsapp", "email", "notes"].map((k) => [
          k,
          String(f.get(k) || ""),
        ]),
      ),
    );
    await serial(async (tx) => {
      const supplierId = id(f, "supplierId");
      await lockSupplier(tx, supplierId, version(f));
      const contactId = String(f.get("contactId") || "");
      const before = contactId
        ? await tx.supplierContact.findFirstOrThrow({
            where: { id: contactId, supplierId },
          })
        : null;
      const contact = before
        ? await tx.supplierContact.update({ where: { id: before.id }, data })
        : await tx.supplierContact.create({ data: { ...data, supplierId } });
      await audit(
        tx,
        actor,
        before ? "CONTACTO_EDITADO" : "CONTACTO_CREADO",
        "Contacto",
        contact.id,
        {
          supplierId,
          before: before
            ? {
                name: before.name,
                role: before.role,
                phone: before.phone,
                whatsapp: before.whatsapp,
                email: before.email,
                notes: before.notes,
              }
            : null,
          after: data,
        },
      );
    });
    refresh();
  }, "Contacto guardado.");
}
export async function deleteContact(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("suppliers:write");
  return mutation(async () => {
    await serial(async (tx) => {
      const supplierId = id(f, "supplierId");
      await lockSupplier(tx, supplierId, version(f));
      const before = await tx.supplierContact.findFirstOrThrow({
        where: { id: id(f, "contactId"), supplierId },
      });
      await tx.supplierContact.delete({ where: { id: before.id } });
      await audit(tx, actor, "CONTACTO_ELIMINADO", "Contacto", before.id, {
        supplierId,
        name: before.name,
        role: before.role,
      });
    });
    refresh();
  }, "Contacto eliminado del directorio.");
}
export async function saveCalendarOrder(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("calendar:write");
  return mutation(async () => {
    const orderDate = businessDate.parse(f.get("orderDate"));
    const date = businessDate.parse(f.get("date"));
    if (date < orderDate)
      throw new ValidationError(
        "La entrega no puede ser anterior al día del pedido.",
      );
    const data = {
      supplierId: id(f, "supplierId"),
      orderDate,
      date,
      detail: z.string().trim().min(1).max(2000).parse(f.get("detail")),
      budget: z.coerce
        .number()
        .int()
        .min(0)
        .max(1000000000)
        .parse(f.get("budget")),
    };
    await serial(async (tx) => {
      if (
        !(await tx.supplier.findFirst({
          where: { id: data.supplierId, active: true },
        }))
      )
        throw new ValidationError("Selecciona un proveedor activo.");
      if (
        await tx.supplierCycle.count({
          where: { supplierId: data.supplierId, active: true },
        })
      )
        throw new ValidationError(
          "Este proveedor usa ciclos inteligentes. Crea el pedido por productos desde su ficha para evitar duplicados.",
        );
      const order = await tx.supplierOrder.create({ data });
      await audit(tx, actor, "PEDIDO_CREADO", "Pedido", order.id, {
        ...data,
        orderDate: orderDate.toISOString().slice(0, 10),
        date: date.toISOString().slice(0, 10),
      });
    });
    refresh();
  }, "Pedido programado. No se ha enviado ningún mensaje.");
}
export async function changeOrderStatus(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("calendar:write");
  return mutation(async () => {
    const status = z.enum(ORDER_STATUSES).parse(f.get("status"));
    await serial(async (tx) => {
      const order = await tx.supplierOrder.findUniqueOrThrow({
        where: { id: id(f) },
      });
      if (order.status === "RECIBIDO")
        throw new ValidationError(
          "Una recepción no se revierte cambiando el estado. Registra un ajuste de inventario si corresponde.",
        );
      if (order.structured && status === "RECIBIDO")
        throw new ValidationError(
          "Usa Registrar recepción para actualizar inventario de forma segura.",
        );
      const changed = await tx.supplierOrder.updateMany({
        where: { id: order.id, version: version(f) },
        data: {
          status,
          ...(status === "CONFIRMADO" ? { confirmedAt: new Date() } : {}),
          ...(status === "CANCELADO" ? { occurrenceKey: null } : {}),
          version: { increment: 1 },
        },
      });
      if (!changed.count)
        throw new ValidationError(
          "Otro usuario cambió el pedido. Recarga antes de actualizarlo.",
        );
      await audit(tx, actor, "ESTADO_PEDIDO_CAMBIADO", "Pedido", order.id, {
        before: order.status,
        after: status,
      });
    });
    refresh();
  }, "Estado actualizado manualmente. No se enviaron pedidos ni se registraron pagos.");
}
export async function saveTask(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("calendar:write");
  return mutation(async () => {
    const data = {
      supplierId: id(f, "supplierId"),
      date: businessDate.parse(f.get("date")),
      type: z.enum(["PEDIDO", "ENTREGA", "PAGO"]).parse(f.get("type")),
      description: z
        .string()
        .trim()
        .min(2)
        .max(500)
        .parse(f.get("description")),
      amount: z.coerce
        .number()
        .int()
        .min(0)
        .max(1000000000)
        .parse(f.get("amount")),
    };
    await serial(async (tx) => {
      if (
        !(await tx.supplier.findFirst({
          where: { id: data.supplierId, active: true },
        }))
      )
        throw new ValidationError("El proveedor está inactivo.");
      const task = await tx.supplierTask.create({ data });
      await audit(tx, actor, "RECORDATORIO_CREADO", "Recordatorio", task.id, {
        ...data,
        date: data.date.toISOString().slice(0, 10),
      });
    });
    refresh();
  }, "Recordatorio guardado. No es un pago ni una factura.");
}
export async function finishTask(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("calendar:write");
  return mutation(async () => {
    await serial(async (tx) => {
      const task = await tx.supplierTask.findUniqueOrThrow({
        where: { id: id(f) },
      });
      const doneAt = f.get("done") === "true" ? new Date() : null;
      await tx.supplierTask.update({
        where: { id: task.id },
        data: { doneAt },
      });
      await audit(
        tx,
        actor,
        doneAt ? "RECORDATORIO_RESUELTO" : "RECORDATORIO_REABIERTO",
        "Recordatorio",
        task.id,
        { type: task.type, description: task.description },
      );
    });
    refresh();
  }, "Recordatorio actualizado. No se registró movimiento de dinero.");
}
export async function saveUser(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requirePermission("users:write");
  return mutation(async () => {
    const userId = String(f.get("id") || "");
    const data = {
      name: z.string().trim().min(2).max(150).parse(f.get("name")),
      email: z.email().max(254).parse(f.get("email")).toLowerCase(),
      role: z.enum(["ADMIN", "SUPERVISOR", "WORKER"]).parse(f.get("role")),
      active: f.get("active") === "on",
    };
    const password = String(f.get("password") || "");
    if (!userId && !password)
      throw new ValidationError("Ingresa una contraseña inicial.");
    if (password)
      z.string()
        .min(12)
        .max(72)
        .refine((value) => Buffer.byteLength(value, "utf8") <= 72)
        .parse(password);
    const passwordHash = password ? await hash(password, 12) : undefined;
    await serial(async (tx) => {
      const before = userId
        ? await tx.user.findUniqueOrThrow({ where: { id: userId } })
        : null;
      if (userId === actor.id && (!data.active || data.role !== "ADMIN"))
        throw new ValidationError(
          "No puedes desactivar tu cuenta ni quitarte el rol administrador.",
        );
      if (
        before?.role === "ADMIN" &&
        before.active &&
        (!data.active || data.role !== "ADMIN") &&
        (await tx.user.count({
          where: { role: "ADMIN", active: true, id: { not: before.id } },
        })) < 1
      )
        throw new ValidationError(
          "Debe quedar al menos un administrador activo.",
        );
      const user = before
        ? await tx.user.update({
            where: { id: userId },
            data: {
              ...data,
              ...(passwordHash ? { password: passwordHash } : {}),
            },
          })
        : await tx.user.create({ data: { ...data, password: passwordHash! } });
      if (
        before &&
        (passwordHash ||
          before.role !== data.role ||
          !data.active ||
          before.email !== data.email)
      )
        await tx.session.deleteMany({ where: { userId: user.id } });
      await audit(
        tx,
        actor,
        before ? "USUARIO_EDITADO" : "USUARIO_CREADO",
        "Usuario",
        user.id,
        {
          before: before
            ? {
                name: before.name,
                email: before.email,
                role: before.role,
                active: before.active,
              }
            : null,
          after: data,
          passwordChanged: !!passwordHash,
        },
      );
    });
    revalidatePath("/usuarios");
    revalidatePath("/auditoria");
  }, "Usuario guardado. Los cambios de acceso revocan sus sesiones anteriores.");
}
export async function changePassword(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const user = await requireUser();
  return mutation(async () => {
    const { compare } = await import("bcryptjs");
    if (!(await compare(String(f.get("currentPassword")), user.password)))
      throw new ValidationError("La contraseña actual no es correcta.");
    const password = z
      .string()
      .min(12)
      .max(72)
      .refine((value) => Buffer.byteLength(value, "utf8") <= 72)
      .parse(f.get("password"));
    if (password !== f.get("confirmation"))
      throw new ValidationError("Las contraseñas nuevas no coinciden.");
    const hashed = await hash(password, 12);
    await serial(async (tx) => {
      await tx.user.update({
        where: { id: user.id },
        data: { password: hashed },
      });
      await tx.session.deleteMany({ where: { userId: user.id } });
      await audit(tx, user, "CLAVE_CAMBIADA", "Usuario", user.id, {
        sessionsRevoked: true,
      });
    });
  }, "Contraseña cambiada. Vuelve a iniciar sesión con tu nueva clave.");
}

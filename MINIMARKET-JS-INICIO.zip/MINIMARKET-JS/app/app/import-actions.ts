"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { mutation, type ActionResult } from "@/lib/mutations";
import {
  uploadProducts,
  previewProducts,
  commitProducts,
  IMPORT_FIELDS,
} from "@/lib/product-import";
export async function uploadImport(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    const file = f.get("file");
    if (!(file instanceof File)) throw Error("Selecciona un archivo");
    id = await uploadProducts(actor, file);
  });
  if (result.success) redirect("/inventario/importar?id=" + id);
  return result;
}
export async function previewImport(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const mapping = Object.fromEntries(
      Object.keys(IMPORT_FIELDS)
        .filter((k) => f.get(k) !== "" && f.has(k))
        .map((k) => [k, Number(f.get(k))]),
    );
    const overrides = Object.fromEntries(
      [...f.entries()]
        .filter(([k]) => k.startsWith("row-"))
        .map(([k, v]) => [k.slice(4), String(v)]),
    );
    await previewProducts(actor, String(f.get("id")), {
      mapping,
      demo: f.get("demo") === "on",
      mode: String(f.get("mode")),
      overwritePrices: f.get("overwritePrices") === "on",
      overwriteStock: f.get("overwriteStock") === "on",
      overrides,
    });
    revalidatePath("/inventario/importar");
  }, "Vista previa lista. Todavía no se modificó ningún producto.");
}
export async function commitImport(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await commitProducts(actor, String(f.get("id")), {
      prices: f.get("confirmPrices") === "on",
      stock: f.get("confirmStock") === "on",
    });
    revalidatePath("/", "layout");
  }, "Importación terminada. Descarga el informe para revisar cada fila.");
}

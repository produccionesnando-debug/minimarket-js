"use server";
import { z } from "zod";
import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser, requirePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import {
  mutation,
  audit,
  ValidationError,
  type ActionResult,
} from "@/lib/mutations";
import {
  createExpense,
  addAttachments,
  requestExpenseChange,
  reviewExpense,
} from "@/lib/expenses";
import { serial } from "@/lib/cash";
import { validDate, dateOnly, todayChile } from "@/lib/dates";
const refresh = () => {
  for (const p of [
    "/inicio",
    "/gastos",
    "/caja",
    "/calendario",
    "/estadisticas",
    "/finanzas",
    "/configuracion",
    "/pedidosya",
  ])
    revalidatePath(p, "layout");
  revalidatePath("/gastos/[id]", "page");
};
const key = (f: FormData, k = "id") =>
  z.string().min(1).max(100).parse(f.get(k));
const amount = (f: FormData, k = "amount", min = 1) =>
  z.coerce.number().int().min(min).max(1000000000).parse(f.get(k));
const text = (f: FormData, k: string, max = 1000) =>
  z.string().trim().min(1).max(max).parse(f.get(k));
const day = (f: FormData, k = "date") =>
  z.string().refine(validDate).parse(f.get(k));
const files = (f: FormData) =>
  [...f.getAll("files"), ...f.getAll("camera")].filter(
    (v): v is File => v instanceof File && v.size > 0,
  );
export async function saveExpense(
  _: ActionResult,
  f: FormData,
): Promise<ActionResult> {
  const actor = await requireUser();
  let id = "";
  const result = await mutation(async () => {
    id = await createExpense(
      actor,
      {
        requestKey: z.uuid().parse(f.get("requestKey")),
        description: text(f, "description"),
        category: text(f, "category", 100),
        amount: amount(f),
        method: z
          .enum(["EFECTIVO", "DEBITO", "CREDITO", "TRANSFERENCIA"])
          .parse(f.get("method")),
        date: day(f),
        shiftId: String(f.get("shiftId") || "") || undefined,
        bankAccountId: String(f.get("bankAccountId") || "") || undefined,
        responsibleId: String(f.get("responsibleId") || actor.id),
        beneficiary: String(f.get("beneficiary") || "").slice(0, 200),
        notes: String(f.get("notes") || "").slice(0, 2000),
        kind: z
          .enum(["OPERATIVO", "RETIRO"])
          .parse(f.get("kind") || "OPERATIVO"),
      },
      files(f),
    );
    refresh();
  });
  if (result.success) redirect(`/gastos/${id}`);
  return result;
}
export async function attach(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    const uploads = files(f);
    if (!uploads.length)
      throw new ValidationError("Selecciona al menos un archivo.");
    await addAttachments(actor, key(f), uploads);
    refresh();
  }, "Comprobantes adjuntados de forma privada.");
}
export async function proposeExpense(_: ActionResult, f: FormData) {
  const actor = await requireUser();
  return mutation(async () => {
    await requestExpenseChange(
      actor,
      key(f),
      z.enum(["CORRECCION", "ANULACION"]).parse(f.get("type")),
      {
        description: text(f, "description"),
        category: text(f, "category", 100),
        amount: amount(f),
        beneficiary: String(f.get("beneficiary") || "").slice(0, 200),
        notes: String(f.get("notes") || "").slice(0, 2000),
      },
      text(f, "reason"),
    );
    refresh();
  }, "Solicitud guardada. El gasto no cambia hasta la aprobación administrativa.");
}
export async function approveExpense(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await reviewExpense(
      actor,
      key(f),
      String(f.get("revisionId") || "") || undefined,
      f.get("approve") !== "false",
    );
    refresh();
  }, "Revisión registrada con historial.");
}
export async function reviewShift(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await serial(async (tx) => {
      const shift = await tx.shift.findFirstOrThrow({
        where: { id: key(f), closedAt: { not: null } },
      });
      const status = z.enum(["APROBADO", "OBSERVADO"]).parse(f.get("status"));
      const notes = text(f, "notes");
      await tx.shift.update({
        where: { id: shift.id },
        data: {
          reviewStatus: status,
          reviewNotes: notes,
          reviewedById: actor.id,
          reviewedAt: new Date(),
        },
      });
      await audit(tx, actor, "CIERRE_REVISADO", "Caja", shift.id, {
        status,
        notes,
        expected: shift.expected,
        counted: shift.counted,
        difference: shift.difference,
      });
    });
    refresh();
  }, "Revisión de cierre guardada.");
}
export async function saveBank(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const data = {
      name: text(f, "name", 100),
      initialBalance:
        f.get("initialBalance") === ""
          ? null
          : amount(f, "initialBalance", -1000000000),
      balanceDate: f.get("balanceDate")
        ? dateOnly(day(f, "balanceDate"))
        : null,
    };
    if ((data.initialBalance === null) !== (data.balanceDate === null))
      throw new ValidationError(
        "Registra el saldo y su fecha juntos, o deja ambos pendientes.",
      );
    await serial(async (tx) => {
      const id = String(f.get("id") || "");
      const previous = id
        ? await tx.bankAccount.findFirstOrThrow({ where: { id, demo: false } })
        : null;
      const account = previous
        ? await tx.bankAccount.update({ where: { id }, data })
        : await tx.bankAccount.create({ data });
      await audit(
        tx,
        actor,
        previous ? "CUENTA_ACTUALIZADA" : "CUENTA_REGISTRADA",
        "Cuenta",
        account.id,
        {
          name: data.name,
          initialBalance: data.initialBalance,
          balanceDate: data.balanceDate?.toISOString() || null,
          previous: previous
            ? {
                name: previous.name,
                initialBalance: previous.initialBalance,
                balanceDate: previous.balanceDate?.toISOString() || null,
              }
            : null,
        },
      );
      await tx.financeConfig.upsert({
        where: { id: "global" },
        create: { id: "global" },
        update: { fundsConfirmed: false },
      });
    });
    refresh();
  }, "Cuenta registrada. No se conectó ningún banco.");
}
export async function saveReserve(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    await serial(async (tx) => {
      const reserve = await tx.financeReserve.upsert({
        where: { id: String(f.get("id") || randomUUID()) },
        create: { name: text(f, "name", 100), amount: amount(f, "amount", 0) },
        update: {
          name: text(f, "name", 100),
          amount: amount(f, "amount", 0),
          active: f.get("active") !== "false",
        },
      });
      await audit(tx, actor, "RESERVA_CONFIGURADA", "Reserva", reserve.id, {
        name: reserve.name,
        amount: reserve.amount,
        active: reserve.active,
      });
    });
    refresh();
  }, "Reserva guardada. No representa un gasto pagado.");
}
export async function confirmFinance(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const data = {
      fundsConfirmed: f.get("fundsConfirmed") === "on",
      reservesConfirmed: f.get("reservesConfirmed") === "on",
    };
    await serial(async (tx) => {
      await tx.financeConfig.upsert({
        where: { id: "global" },
        create: { id: "global", ...data },
        update: data,
      });
      await audit(
        tx,
        actor,
        "SUPUESTOS_FINANCIEROS_CONFIRMADOS",
        "Finanzas",
        "global",
        data,
      );
    });
    refresh();
  });
}
export async function bankMovement(_: ActionResult, f: FormData) {
  const actor = await requireUser(true);
  return mutation(async () => {
    const data = {
      accountId: key(f, "accountId"),
      date: dateOnly(day(f)),
      amount: amount(f, "amount", -1000000000),
      description: text(f, "description"),
      actorId: actor.id,
      requestKey: z.uuid().parse(f.get("requestKey")),
    };
    if (!data.amount)
      throw new ValidationError("El movimiento no puede ser cero.");
    await serial(async (tx) => {
      if (
        await tx.bankMovement.findUnique({
          where: { requestKey: data.requestKey },
        })
      )
        return;
      await tx.bankAccount.findFirstOrThrow({
        where: { id: data.accountId, active: true },
      });
      const move = await tx.bankMovement.create({ data });
      await audit(
        tx,
        actor,
        "MOVIMIENTO_BANCARIO_REGISTRADO",
        "Movimiento bancario",
        move.id,
        { amount: data.amount, date: day(f), description: data.description },
      );
    });
    refresh();
  }, "Movimiento registrado; no se ejecutó una operación bancaria.");
}
export async function channelDemo(_: ActionResult, f: FormData) {
  const actor = await requirePermission("shifts:manage");
  return mutation(async () => {
    await serial(async (tx) => {
      const id = String(f.get("id") || "");
      if (!id) {
        const order = await tx.channelOrder.create({
          data: {
            customerLabel: "Cliente ficticio · DEMOSTRACIÓN",
            lines: [{ name: "Producto ficticio", quantity: 2 }],
            total: 2500,
          },
        });
        await audit(
          tx,
          actor,
          "PEDIDOSYA_DEMO_CREADO",
          "Pedido demo",
          order.id,
          { demo: true },
        );
      } else {
        const order = await tx.channelOrder.findUniqueOrThrow({
          where: { id, demo: true },
        });
        const next = z
          .enum([
            "ACEPTADO",
            "RECHAZADO",
            "PREPARANDO",
            "LISTO",
            "ENTREGADO",
            "CANCELADO",
          ])
          .parse(f.get("status"));
        const transitions: Record<string, string[]> = {
          RECIBIDO: ["ACEPTADO", "RECHAZADO", "CANCELADO"],
          ACEPTADO: ["PREPARANDO", "CANCELADO"],
          PREPARANDO: ["LISTO", "CANCELADO"],
          LISTO: ["ENTREGADO", "CANCELADO"],
        };
        if (!transitions[order.status]?.includes(next))
          throw new ValidationError(
            "Transición no permitida para este estado.",
          );
        const changed = await tx.channelOrder.updateMany({
          where: { id, version: amount(f, "version", 0) },
          data: { status: next, version: { increment: 1 } },
        });
        if (!changed.count)
          throw new ValidationError("El pedido cambió. Recarga.");
        await audit(tx, actor, "PEDIDOSYA_DEMO_ESTADO", "Pedido demo", id, {
          from: order.status,
          to: next,
          stockChanged: false,
        });
      }
    });
    refresh();
  }, "Prueba guardada. Sin conexión a PedidosYa y sin alterar inventario real.");
}

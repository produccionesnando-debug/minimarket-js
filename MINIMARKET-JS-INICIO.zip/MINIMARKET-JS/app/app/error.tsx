"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="card">
      <h1>No se pudo completar la operación</h1>
      <p>
        Revisa los datos, el stock disponible y que tu caja esté abierta. Si el
        problema continúa, contacta al administrador.
      </p>
      <button onClick={reset}>Volver a intentar</button>
    </main>
  );
}

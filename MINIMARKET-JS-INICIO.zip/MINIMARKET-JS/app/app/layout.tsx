import "@fontsource-variable/inter";
import "./globals.css";
import { getBrand } from "@/lib/brand";
export async function generateMetadata() {
  const brand = await getBrand();
  return {
    title: "MINIMARKET JS",
    description: "Administración de minimarket en Chile",
    manifest: "/manifest.webmanifest",
    icons: brand.available
      ? {
          icon: [
            {
              url: "/api/identidad/logo?size=32&v=" + brand.version,
              type: "image/png",
              sizes: "32x32",
            },
          ],
          apple: [
            {
              url: "/api/identidad/logo?size=180&v=" + brand.version,
              sizes: "180x180",
            },
          ],
        }
      : undefined,
    appleWebApp: {
      capable: true,
      title: "Minimarket JS",
      statusBarStyle: "default",
    },
  };
}
export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#075578",
};
export default function Root({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-CL">
      <body>{children}</body>
    </html>
  );
}

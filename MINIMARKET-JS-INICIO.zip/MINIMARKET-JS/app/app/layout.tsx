import "./globals.css";
export const metadata = {
  title: "MINIMARKET JS",
  description: "Administración de minimarket en Chile",
};
export default function Root({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-CL">
      <body>{children}</body>
    </html>
  );
}

import "@fontsource-variable/inter";
import "./globals.css";
export const metadata = {
  title: "MINIMARKET JS",
  description: "Administración de minimarket en Chile",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Minimarket JS",
    statusBarStyle: "default",
  },
};
export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#102337",
};
export default function Root({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-CL">
      <body>{children}</body>
    </html>
  );
}

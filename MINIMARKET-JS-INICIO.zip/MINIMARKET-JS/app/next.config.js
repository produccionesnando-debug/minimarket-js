module.exports={poweredByHeader:false,experimental:{serverActions:{bodySizeLimit:"28mb"}}};

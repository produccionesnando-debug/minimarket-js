module.exports={poweredByHeader:false,serverExternalPackages:["unzipper","@fast-csv/parse"],experimental:{serverActions:{bodySizeLimit:"28mb"}}};

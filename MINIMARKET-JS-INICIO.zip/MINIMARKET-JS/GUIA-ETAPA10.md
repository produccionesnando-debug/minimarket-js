# Etapa 10 — Caja rápida e inventario

El código interno 20 está reservado para Pan. Es una configuración solicitada: no incluye precio, costo ni stock reales. Los campos desconocidos se muestran como «Sin registrar». Administración debe completarlos cuando los conozca.

## Venta rápida

La tabla mantiene el total visible y devuelve el foco al lector después de agregar productos. El lector funciona como teclado; configura su terminador Enter o Tab. F5 solicita confirmar la eliminación de la fila seleccionada, F9 abre el cobro y F12 permite a administración buscar o editar productos. Hay botones y combinaciones Alt configurables si el navegador o Windows interceptan teclas. No se garantiza capturar teclas reservadas fuera del foco de la aplicación.

Los productos por peso usan gramos enteros y precios por kilogramo. Un importe manual es dinero, no una medición: con un precio/kg confirmado se puede mostrar un peso estimado. La política PENDING no descuenta esa estimación y exige conciliación; ESTIMATE descuenta una estimación explícita que después debe conciliarse con una medición. Una devolución posterior a la conciliación restaura la cantidad real conciliada. No se configura una balanza sin sus etiquetas y modelo.

Los cambios de precio conservan los importes históricos. Los códigos anteriores quedan reservados como alias. Desactivar un producto impide nuevas ventas sin borrar el historial.

## Existencias

- Inventario inteligente: filtros, disponibilidad, rotación, margen conocido, vencimientos y propuestas explicadas. Sin datos suficientes, indica una recomendación preliminar o sin cantidad calculable.
- Lotes: registrar una recepción agrega stock; asignar existencias actuales a un lote no lo duplica. Se consumen primero los lotes vigentes con vencimiento más próximo. El stock sin lote conserva vencimiento desconocido.
- Mermas: movimientos auditados, sin venta ficticia; costo desconocido se conserva como desconocido.
- Conteos: el lector prepara cantidades sin modificar existencias. Administración aprueba. Si hubo movimientos desde el conteo, se exige volver a contar; las diferencias de lotes requieren conciliación.
- Reposición: usa movimientos, ventas, existencias, mínimos, pedidos pendientes y calendario disponible. Guardar una revisión no envía WhatsApp ni crea una compra automáticamente.

Las ventas y formularios se verifican con datos sintéticos en una base terminada en `_test`. No se han probado una impresora térmica, una balanza ni un lector físico concretos desde Linux. La impresión usa el diálogo del navegador, con margen interior de 3 mm.

El catálogo principal muestra 40 productos por página y conserva los filtros al navegar. Guardar dirige al producto guardado. Los informes distinguen existencias desconocidas de cero y las cantidades manuales sin conciliar de unidades medidas.

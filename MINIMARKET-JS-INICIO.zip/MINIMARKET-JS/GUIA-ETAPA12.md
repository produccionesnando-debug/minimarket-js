# Etapa 12: fiados y uso móvil

Los vouchers se vinculan a ventas a crédito existentes. Sus números son únicos; generarlos no registra otra venta ni modifica inventario. Los estados se calculan desde abonos y devoluciones autorizadas. El timbre PAGADO aparece únicamente cuando el saldo llega a cero. La anulación utiliza la devolución autorizada y conserva el historial.

En Clientes y créditos, abre un cliente para seleccionar vouchers, distribuir un abono parcial o completo y revisar la asignación de efectivo, débito, crédito y transferencia antes de confirmar. Los cobros electrónicos requieren comprobar su recepción fuera de la aplicación. Los reintentos usan una clave única y no duplican cobros. Cada recibo conserva trabajador, referencias y saldos anteriores y posteriores.

Cada voucher permite imprimir y descargar PDF. El estado de cuenta incluye compras y recibos; los filtros corresponden a la fecha de compra del voucher. La identidad visual usa el logo guardado en la aplicación, sin redibujarlo.

En celular, el acceso abre Pedidos por defecto. Configuración permite cambiar esa pantalla y el cuarto acceso inferior por rol. Los cinco grupos del menú de computador conservan su estado por usuario. Los pedidos permiten reutilizar el último confirmado, comparar cantidades y recuperar un borrador local. Guardar un pedido no descuenta stock; WhatsApp conserva su confirmación explícita y excluye precios.

## Archivo real recibido

El Excel se analizó de forma privada, sin importarlo. Contiene 2.505 filas, 2.329 saldos negativos, costos decimales, tres precios decimales y códigos con ceros iniciales. Se requiere revisar existencias y valores antes de confirmar una importación. El importador reconoce su encabezado desplazado y rechaza celdas numéricas fraccionarias en campos enteros; no redondea ni inventa stock. El archivo y sus productos no forman parte de la demostración pública.

## Actualización local

Cierra el iniciador anterior y realiza un respaldo antes de actualizar. Conserva la carpeta `.local`, `ACCESO.txt` y `comprobantes-demo` en la nueva carpeta. El restaurador aplica migraciones pendientes sin recargar datos ficticios sobre una base ya inicializada. Conserva el logo y los registros locales. Las pruebas en Linux no sustituyen la comprobación de impresora, lector o Windows nativo.

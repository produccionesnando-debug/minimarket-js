# Etapa 13 — preparación rápida de compras

En Compras → Pedidos → Crear pedido, seleccionar un proveedor abre automáticamente su editor. Recupera el último pedido confirmado/recibido y muestra también productos asociados al proveedor. Cada cantidad anterior se distingue de la sugerencia calculada con stock conocido, mínimos, ventas netas y compras pendientes. La recomendación se considera preliminar cuando faltan ventas, plazo o fechas. No hay compras ni reservas automáticas. Sin una base suficiente, la cantidad queda en cero para que el usuario la defina; las líneas en cero no se guardan.

Se puede buscar/agregar/quitar, ajustar con +/−, guardar observaciones y recuperar un borrador local después de recargar. Guardar persiste productos, cantidades, costos internos, fechas y ciclo en PostgreSQL. Los días alternativos de un ciclo comparten la misma clave de ocurrencia, evitando pedidos duplicados. La creación usa una clave de solicitud y comprueba los datos antes de reutilizar un resultado de un reintento.

Un producto nuevo se crea únicamente con nombre, marca y presentación ingresados por el usuario. Su ficha queda inactiva con precio, costo y stock desconocidos; no se inventan existencias ni un precio de venta. Antes de venderlo, administración debe completar y activar la ficha en Inventario. El código interno generado no es un GTIN oficial. Este editor conserva la limitación previa de cantidades enteras por unidad: la compra/recepción fraccionaria por peso requiere el flujo de Inventario.

## WhatsApp

El botón del editor guarda primero el pedido y abre la sección de compartir. Allí se puede editar el mensaje y seleccionar exclusivamente un contacto vendedor o el WhatsApp comercial verificado de la ficha. Los contactos de comprobantes de transferencia no participan. El servidor comprueba contacto, versión vigente y ausencia de referencias monetarias comunes; los costos internos nunca se usan para construir el mensaje. Al editar texto libre, se debe revisar además que no se hayan escrito precios como números ambiguos sin símbolo ni descripción monetaria.

Preparar el mensaje conserva una copia auditada y habilita el enlace. Abrir WhatsApp no envía automáticamente, no confirma disponibilidad y no cambia el estado. Después de enviarlo, marcar la casilla y confirmar manualmente registra «Compartido, pendiente de confirmación». No hay comprobación automática de lectura/entrega de WhatsApp ni integración con su API. Las pruebas interceptan la apertura externa y no envían mensajes reales.

El detalle conserva fecha de confirmación y recepción, observaciones y registro de modificaciones con usuario y fecha de Chile. Los costos solo son internos; el presupuesto disponible proviene de fondos y reservas registrados y se muestra como pendiente si faltan datos.

## Acceso y conservación

La demostración Windows actualiza el proyecto existente. Cerrar el iniciador anterior, respaldar y conservar `.local`, `ACCESO.txt` y `comprobantes-demo` mantiene la base, el logo y las credenciales locales. La migración agrega campos sin borrar tablas ni registros. No se importa el Excel real ni se publican contactos, productos, credenciales o saldos del negocio. No se ha comprobado el arranque nativo de esta revisión en Windows ni el hardware del local.

## Listas habituales — instrucción 13.1

Cada proveedor dispone de una lista independiente en PostgreSQL con nombre/presentación, código, cantidad habitual entera, unidad de compra, posición y estado activo. «Administrar lista habitual» permite agregar, editar, quitar, subir/bajar e inactivar filas. «Guardar este pedido como lista habitual» solicita confirmación para reemplazar; «Agregar productos sin reemplazar lista» conserva las filas existentes y agrega únicamente las nuevas. Ningún pedido actualiza la lista de forma automática.

Un pedido nuevo precarga las filas activas y cantidades de la lista; la cantidad anterior y la sugerencia de reposición son informativas. Se puede poner cero o quitar una fila solo de esa compra. Las filas en cero no se comparten ni se guardan como líneas de compra. Si la lista existe y está vacía/inactiva, no se reactivan productos desde pedidos antiguos. «Copiar este pedido confirmado» conserva la plantilla histórica seleccionada explícitamente.

Las unidades quedan guardadas en cada pedido y aparecen en WhatsApp, sin costos. Cambiar la lista no modifica pedidos históricos. Las listas usan control de versión y auditoría por usuario. El calendario abre el mismo editor con la fecha/ciclo, y conserva la comprobación de duplicados por ocurrencia.

Limitación explícita: cantidades enteras por unidad de compra. No hay conversión automática de cajas/paquetes/kg a unidades de inventario; una recepción con esas unidades solicita revisar equivalencias y no incrementa stock de forma incorrecta. La recepción fraccionaria o con conversión se mantiene pendiente de un flujo específico verificado.

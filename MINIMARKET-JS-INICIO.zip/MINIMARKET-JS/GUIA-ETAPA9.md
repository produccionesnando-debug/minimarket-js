# Punto de venta: escaneo, peso y códigos internos

La pantalla Ventas y Caja prioriza el listado (70% en computador), con cobro lateral y total visible; en celular se ordenan búsqueda, carrito y pago. Se conservan pagos mixtos, crédito autorizado, devoluciones, gastos y caja.

## Probar

1. Abre una caja de prueba. En Ventas y Caja, haz clic en Escanear código o buscar producto (F2).
2. Lector USB/Bluetooth: modo teclado, sufijo Enter; en Configurar lector puedes cambiar a Tab. No requiere instalar un controlador propio de la aplicación. El equipo físico aún debe probarse.
3. Sin lector: escribe el código y pulsa Enter. Repite para sumar unidades; el foco queda listo para la siguiente lectura. Un código inexistente muestra una advertencia y no agrega un producto.
4. Administrador: + Nuevo producto permite código de fabricante, interno manual con letras o código automático MMJS. Completa nombre, categoría y precio; costo, stock y proveedor son opcionales. Guardar agrega al carrito sin perder la venta.
5. Venta por peso: precio y costo por kg; stock inicial en kg. El cuadro permite gramos enteros o kg con hasta tres decimales. A $9.000/kg, 350 g cuestan $3.150. Otra lectura pide una nueva porción; se acumula el peso y se conservan las porciones en el comprobante de la base.
6. Selecciona medio de pago e ingresa efectivo recibido, si corresponde. Cobrar confirma una sola venta y movimiento. La tecla F8 también cobra; no cobra mientras una lectura o cuadro esté pendiente.
7. Inventario permite ajustar el peso exacto y marcar productos reales como venta rápida. Abre /etiquetas para generar Code 128 de códigos internos e imprimir con el diálogo del navegador. Son códigos propios, no GTIN/EAN registrados.

## Cálculo y límites

Los pesos se guardan como gramos enteros, equivalentes exactos a kg con tres decimales. Se rechaza precisión mayor; no se redondea el peso. Los precios y cobros son pesos chilenos enteros. El subtotal se calcula con aritmética entera y redondeo al peso más cercano, hacia arriba o hacia abajo configurable en Precios por canal. Se redondea el total de cada producto sobre su peso acumulado; las porciones permanecen detalladas.

El inventario de unidades y el de gramos se mantienen separados. Una venta por peso descuenta stockGrams; una devolución parcial apta repone gramos. Los costos desconocidos permanecen desconocidos; no se inventa utilidad. Las recepciones de compras por peso se registran mediante conteo de kg en Inventario: los pedidos antiguos siguen siendo por unidades. La importación Excel y los encargos antiguos no convierten cantidades de unidad a kg automáticamente.

Los códigos internos quedan reservados en un registro persistente y no pueden reemplazarse desde Inventario. El generador considera los códigos reservados después de restaurar una base. El patrón de balanza es solo preparación desactivada en /balanza: requiere modelo, etiquetas y mapeo reales antes de habilitarse. No existe formato universal ni lectura automática de importes de balanza activada.

## Ticket y actualización

El ticket tiene 3 mm de margen interior, además de los 2 mm de página en papel 58/80 mm. El logo se ajusta sin cambiar proporciones. La impresión física depende de controlador, papel y márgenes del equipo; no está certificada en esta nube.

Para conservar el logo y los movimientos locales al actualizar: cierra la ventana del iniciador con Ctrl+C; conserva una copia completa de la carpeta anterior. Extrae la versión nueva en otra carpeta. Copia la carpeta oculta `.local`, `ACCESO.txt` y `comprobantes-demo` de la anterior a la nueva antes de abrirla. `.local` contiene la base y el logo; no la borres. Los usuarios existentes permanecen. No se publican datos del negocio.

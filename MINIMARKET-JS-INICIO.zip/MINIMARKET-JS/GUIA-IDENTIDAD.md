# Identidad visual — MiniMarket JS

Se conserva la lógica de proveedores, calendarios, POS, caja, inventario y finanzas. Esta entrega cambia la presentación, la marca y la cabecera de impresión. La paleta utiliza azul profundo, turquesa, verde y amarillo sobre fondos claros y tarjetas blancas.

## Archivo original

El original se carga como administrador en **Identidad del negocio → Archivo original del logo → Guardar identidad visual**. Se acepta PNG, JPG o WebP estático de hasta 5 MB y 20 megapíxeles. Se conservan los bytes exactos y un SHA-256; no se redibuja, sustituye, recolorea ni recorta el logo. El fondo original y sus márgenes se conservan. Si solo tienes un diseño Canva, usa Compartir → Descargar → PNG y conserva sus proporciones antes de cargarlo.

Una única configuración alimenta el acceso, menú lateral y móvil, encabezado, comprobantes internos e informes PDF. Sobre azul marino se usa un panel blanco con el logo completo. Los iconos de 16, 32, 180, 192 y 512 px se generan por contención con un margen del 8%; no se extrae el carrito ni se estira el texto. La información de versión se actualiza también en el manifest para evitar que quede fijado el icono anterior.

Sin un original cargado se utiliza **MiniMarket JS en texto**. Los iconos oficiales se habilitan después de cargar el original. Esto es un estado pendiente, no un logo oficial inventado. Los antiguos iconos genéricos dejaron de referenciarse en los metadatos y el manifest.

## Estado del original adjunto

La imagen pegada del logo se ve en el chat, pero no se proporcionó una ruta de archivo ni un identificador descargable de su binario. El usuario proporcionó después un enlace Canva. El proxy del entorno rechazó su acceso (CONNECT 403, Canva fuera de los destinos permitidos). Se guardó un borrador de red para canva.link y Canva, conservando los destinos Google conocidos. Hasta contar con el archivo original o habilitar y verificar la descarga, no se afirma que ese archivo esté incorporado ni se sustituye por un redibujo.

En Codex: revisar **Editar entorno**, guardar y publicar la configuración del entorno. Esto no despliega la aplicación en producción. Tras aplicarse la red, hay que volver a comprobar el enlace: un diseño Canva puede requerir permiso del propietario o una exportación PNG descargable.

En Windows la carga directa desde el archivo original evita depender de la descarga desde esta nube. La misma configuración queda guardada en su PostgreSQL local y se conserva al reiniciar; una carpeta de demostración nueva tiene su propia base.

## Datos reales y previsualización

La verificación de esta etapa encontró **25 proveedores, 9 contactos y 20 ciclos reales**, sin productos, ventas ni gastos reales. Se verificaron las huellas de las columnas originales de 22 tablas, sin cambios. El directorio real sigue en la base principal de la nube; los paquetes públicos Windows solo contienen datos ficticios. No se mezclan ni se publican contactos reales.

La sesión actual no ofrece un enlace público verificado al puerto 3000. El acceso Windows continúa mediante el paquete descargable, **Extraer todo en una carpeta nueva → ABRIR-MINIMARKET.cmd → ACCESO.txt**. No presentar localhost de la nube como una URL accesible desde Windows.

## Validación

Las pruebas usan imágenes sintéticas identificadas como prueba, nunca una aproximación al logo oficial. Comprueban conservación byte a byte, proporciones, tamaños, rechazo de SVG/archivos no válidos y permisos del administrador; también acceso, navegación, manifest y ausencia de desbordamiento en celular. Los datos comerciales se verifican por conteos y huellas, sin crear operaciones reales.

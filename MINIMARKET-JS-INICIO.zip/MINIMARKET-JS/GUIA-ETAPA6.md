# Google y pedidos por WhatsApp

## Funciona sin servicios externos

En el menú **WhatsApp — Pedidos y encargos**, registrar conversaciones manuales con teléfono internacional y un cliente existente opcional. Elegir una conversación, revisar sus mensajes y abrir **Crear pedido interno**. Elegir productos reales del catálogo o escribir encargos especiales sin inventar producto ni precio. Los precios de catálogo se calculan en el servidor.

Confirmar reserva stock, sin descontarlo: el POS y la caja anterior respetan las reservas. Los anticipos requieren caja abierta del mismo modo y precios confirmados; registran dinero una sola vez, sin crear ventas. **Completar venta en caja** cobra únicamente el saldo, convierte la reserva en una venta con costo histórico y descuenta inventario una vez. Conserva los anticipos en sus turnos originales, sin volver a cobrarlos. Comprobante y devoluciones se abren desde el enlace de venta. Marcar entregado es una operación posterior; no es lo mismo que pagado.

Un anticipo se puede reembolsar por un supervisor antes de cancelar; no se permite cancelar dejando anticipos retenidos. No se mezclan ventas de demostración con cajas reales. En la instancia Windows completa, TODOS los datos son ficticios aunque sus registros internos no tengan marcado demo: no activar la casilla de conversación demo si se quiere usar su catálogo principal ficticio.

Encargos especiales: indicar proveedor sugerido, fecha comprometida y **Propuesta de compra interna**. Es una solicitud para revisar, nunca una orden enviada al proveedor. Para marcar recibido, asociar un producto real que tenga stock suficiente; la recepción se registra antes en el inventario o módulo de recepciones. El responsable recibe un aviso interno. No se envía WhatsApp automáticamente.

La bandeja filtra por nombre, teléfono, fecha de creación y estado. Trabajadores acceden solo a conversaciones asignadas; supervisores pueden reasignar. En computador hay tres columnas, y en celular las pestañas Conversaciones, Mensajes y Cliente y pedidos. Los resultados están limitados a 100 conversaciones, 300 mensajes de la conversación seleccionada y 1000 productos de catálogo. Usar filtros cuando corresponda.

Plantillas editables por el administrador: seleccionar, revisar, modificar y copiar texto. No existe botón que envíe automáticamente. La copia al portapapeles no significa que un mensaje haya sido enviado.

## Google: código preparado, conexión NO verificada

Se utiliza **openid-client**, biblioteca OpenID Connect, con Authorization Code, PKCE S256, state aleatorio vinculado al navegador, nonce y comprobación criptográfica de ID token. No almacena contraseñas Google, access tokens ni refresh tokens. La solicitud vence en diez minutos y se consume una sola vez. El correo debe estar verificado. Se mantienen las sesiones privadas y cierre de sesión existentes.

1. En Google Cloud Console crear un proyecto, configurar Google Auth Platform / pantalla de consentimiento y audiencia externa para Gmail y Workspace. En pruebas, añadir las cuentas de prueba. Si Workspace limita aplicaciones, su administrador debe autorizarla.
2. Crear un cliente OAuth de tipo **Aplicación web**.
3. Configurar `APP_URL` con el origen real que usará el navegador. Desarrollo Windows: `http://127.0.0.1:3000` (o puerto realmente elegido); desplegado: origen HTTPS autorizado. No utilizar la dirección cloud localhost desde Windows.
4. Registrar exactamente `APP_URL/api/auth/google/callback` como URI de redirección. Si se cambia puerto/origen, actualizar ambos lugares. No se requiere Gmail API ni acceso a correos: scopes `openid email profile`.
5. Configurar `GOOGLE_CLIENT_ID` y `GOOGLE_CLIENT_SECRET` en el entorno privado del servidor, nunca en código, Git, capturas ni chat. Reiniciar el servidor. Habilitar salidas HTTPS hacia `accounts.google.com`, `oauth2.googleapis.com` y `www.googleapis.com` en entornos con red restringida, manteniendo proxy y TLS.
6. Entrar con contraseña como administrador → **Acceso con Google** → verificar presencialmente identidad del trabajador → autorizar su correo Google para un usuario existente. No se envía correo: el trabajador entra con el botón Google dentro de siete días. El administrador debe crear antes cualquier usuario nuevo con su rol y contraseña local. No hay altas ni administradores automáticos por OAuth, ni vinculación por mera coincidencia de correo.
7. Probar con la cuenta autorizada; rechazar una no invitada, cerrar sesión, desactivar usuario y probar de nuevo. Revocar Google elimina la vinculación, invitación y todas sus sesiones.

Sin credenciales, el botón está deshabilitado y explica la configuración pendiente. Las pruebas locales verifican autorización, roles y restricciones; **no constituyen prueba de un login real con Google**. No se han proporcionado credenciales en este entorno.

## WhatsApp Business Platform: recepción preparada, conexión NO activa

Se necesita una cuenta de Meta for Developers, negocio/WABA y número comercial registrado en **WhatsApp Business Platform Cloud API**, permisos y revisión de Meta según el uso, y una URL pública HTTPS que Meta pueda alcanzar. Puede utilizarse el número de pruebas oficial para validar primero. Revisar compatibilidad/coexistencia o migración del número antes de cambiar el número comercial actual. Los posibles cobros y verificaciones los determina Meta o el proveedor oficial elegido; este proyecto no contrata servicios.

- Webhook verificación y recepción: `APP_URL/api/whatsapp/webhook` (GET y POST).
- Servidor: `WHATSAPP_VERIFY_TOKEN` (token privado de verificación), `WHATSAPP_APP_SECRET` (secreto de la app para firma HMAC), `WHATSAPP_PHONE_NUMBER_ID` (ID autorizado). Los secretos deben ser accesibles al proceso servidor para validación local; un marcador sustituido solo por proxy HTTP no sirve para HMAC. Guardarlos en configuración privada del servidor, nunca en Git.
- Suscribir el campo `messages` de WhatsApp Business Account en Meta; completar challenge y verificar firmas `X-Hub-Signature-256`.
- Administrador → Plantillas y privacidad → elegir un trabajador activo responsable → habilitar recepción. Sin responsable, configuración y firma válidas se rechaza. Los IDs externos únicos evitan duplicados incluso con reintentos.
- Solo mensajes de texto se almacenan directamente. Otros tipos se registran como avisos para revisar en el canal oficial; no se descargan adjuntos privados. Los estados de entrega sin mensajes no crean conversaciones.
- No hay emisor por API, token de envío ni respuestas automáticas: no se envían mensajes externos. Para incorporar envío más adelante, configurar permisos/token oficiales, consentimiento y ventanas de servicio; fuera de ventana, solo plantillas aprobadas por Meta, con revisión y autorización de envío. No usar sesiones personales, scraping ni bibliotecas no oficiales.

Retención: administrador define días y ejecuta eliminación de textos antiguos escribiendo **ELIMINAR**. Se conserva auditoría del número eliminado y registros comerciales (pedidos/comprobantes) para poder aplicar una política legal apropiada; no se eliminan automáticamente documentos de caja. La política debe ajustarse con el encargado legal/privacidad del negocio. No se usan teléfonos para campañas ni se han enviado mensajes.

## Resumen de caja

Ver [resumen-financiero.md](resumen-financiero.md): ventas netas y saldo después de egresos operativos son diferentes de cobros y efectivo. Los anticipos y sus reembolsos afectan cobros/caja al momento de recibirse/devolverse, sin crear una venta. La conversión a venta no registra nuevamente esos cobros.

## Configuración de nube guardada

Se guardó un borrador con los nombres de las variables externas anteriores y `NODE_USE_ENV_PROXY=1`, más los tres destinos HTTPS de Google. No contiene valores secretos y no activa conexiones. En **Editar entorno**, revisar y guardar los valores que correspondan y publicar la configuración del entorno para aplicarla; esto no despliega la aplicación en producción. La aplicación y pruebas locales no dependen de completar estos valores.

## Validación de entrega

24 pruebas unitarias, 13 de integración PostgreSQL y 14 de navegador. La integración cubre cambio horario de Chile (día de 23 horas), saldo histórico anterior a un cierre posterior, crédito y abonos, turnos, gastos, retiros, proveedores, reserva, anticipos, venta única, firmas Meta, deduplicación y autorización Google. Navegador cubre barra móvil fija y compacta, selector de turno, bandeja, encargo sin precio y preservación de los 13 recorridos anteriores.

La demostración precompilada se verifica con instalación limpia de dependencias de producción, restauración nueva y actualización repetibles, páginas y exportaciones, sin errores de JavaScript. La validación criptográfica de tokens externos y la entrega de mensajes reales necesitan credenciales autorizadas; no se sustituyen por los tests locales de autorización.

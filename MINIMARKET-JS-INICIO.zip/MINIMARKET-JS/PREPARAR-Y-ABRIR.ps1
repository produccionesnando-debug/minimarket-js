$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$cacheFolder = Join-Path $PSScriptRoot '.descargas'
$runtimeFolder = Join-Path $PSScriptRoot 'runtime'
$nodePath = Join-Path $runtimeFolder 'node.exe'
$npmPath = Join-Path $runtimeFolder 'node_modules\npm\bin\npm-cli.js'
function Download-Verified([string]$Url, [string]$Destination, [string]$ExpectedHash) {
    if ((Test-Path $Destination) -and (Get-FileHash $Destination -Algorithm SHA256).Hash.ToLowerInvariant() -eq $ExpectedHash) { return }
    Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing
    if ((Get-FileHash $Destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedHash) { throw 'La descarga no paso la verificacion. Vuelve a abrir este asistente.' }
}
function Run-Tar([string[]]$Arguments) {
    & tar.exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw 'Windows no pudo extraer un componente. Conserva esta ventana para informar el error.' }
}
try {
    Write-Host 'MINIMARKET JS - Preparando la demostracion local' -ForegroundColor Cyan
    Write-Host 'La primera vez necesita Internet y puede tardar varios minutos. No cierres esta ventana.'
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Se requiere Windows de 64 bits.' }
    if (-not (Get-Command tar.exe -ErrorAction SilentlyContinue)) { throw 'Se necesita una version actualizada de Windows 10/11 para extraer los componentes.' }
    New-Item -ItemType Directory -Path $cacheFolder -Force | Out-Null
    New-Item -ItemType Directory -Path $runtimeFolder -Force | Out-Null
    if (-not (Test-Path $nodePath) -or -not (Test-Path $npmPath)) {
        Write-Host '1/4 Descargando Node.js oficial...'
        $nodeZip = Join-Path $cacheFolder 'node.zip'
        Download-Verified 'https://nodejs.org/dist/v24.22.0/node-v24.22.0-win-x64.zip' $nodeZip 'f9683a19877e12a9b167305c8db71040d812876359de21f0d2e97c3f321f80c3'
        Run-Tar @('-xf', $nodeZip, '-C', $cacheFolder)
        Copy-Item (Join-Path $cacheFolder 'node-v24.22.0-win-x64\*') $runtimeFolder -Recurse -Force
    }
    $postgresFolder = Join-Path $PSScriptRoot 'postgres'
    Write-Host '2/4 PostgreSQL incluido, sin extraer archivos XZ.'
    foreach ($program in @('postgres.exe','initdb.exe','pg_ctl.exe')) {
        if (-not (Test-Path (Join-Path $postgresFolder ('bin\' + $program)))) {
            throw 'Faltan archivos de PostgreSQL. Extrae TODO el ZIP actualizado antes de iniciar.'
        }
    }
    $env:Path = "$runtimeFolder;$env:Path"
    $readyFile = Join-Path $PSScriptRoot '.dependencias-listas'
    if (-not (Test-Path $readyFile) -or (Get-Content $readyFile -Raw).Trim() -ne 'pos-v4') {
        Write-Host '3/4 Preparando los componentes de la aplicacion...'
        Push-Location (Join-Path $PSScriptRoot 'app')
        try {
            & $nodePath $npmPath ci --omit=dev --ignore-scripts --no-audit --no-fund --cache (Join-Path $cacheFolder 'npm-cache')
            if ($LASTEXITCODE -ne 0) { throw 'No se pudieron descargar las dependencias. Revisa el mensaje anterior.' }
        } finally { Pop-Location }
        $clientFolder = Join-Path $PSScriptRoot 'app\node_modules\.prisma\client'
        New-Item -ItemType Directory -Path $clientFolder -Force | Out-Null
        Copy-Item (Join-Path $PSScriptRoot '.cliente-prisma\*') $clientFolder -Recurse -Force
        Set-Content -Path $readyFile -Value 'pos-v4'
    }
    Write-Host '4/4 Abriendo MINIMARKET JS...' -ForegroundColor Green
    & $nodePath (Join-Path $PSScriptRoot 'iniciar-demo.cjs')
    if ($LASTEXITCODE -ne 0) { throw 'El inicio se detuvo. Envia una foto de esta ventana para revisar el motivo.' }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

# Resumen financiero — Ventas y Caja

Barra fija en computador y celular. Dos indicadores destacados y seis indicadores secundarios en una fila desplazable. Actualización después de operaciones, al volver a la ventana y cada 15 segundos visible; no requiere volver a iniciar sesión. Los formularios conservan el carrito.

- **Ventas del día:** total de ventas registradas menos devoluciones del período. El importe incluye IVA; no significa ventas sin IVA.
- **Saldo neto del día:** ventas netas menos gastos de tipo OPERATIVO no anulados. **No es utilidad contable, cobros ni efectivo disponible.** Retiros y pagos de proveedores no se restan nuevamente como gastos operativos.
- **Medios de cobro:** ventas antiguas sin libro de cobros + movimientos normalizados VENTA, ABONO y ANTICIPO menos REEMBOLSO y REEMBOLSO_ANTICIPO. Excluye INGRESO adicional y fondo inicial. Se muestran cuatro métodos, incluido tarjeta de crédito (distinta de fiado).
- **Crédito pendiente:** saldo ACTUAL de ventas originadas en el período seleccionado: crédito concedido menos abonos y reducciones por devoluciones, nunca negativo. No es toda la cartera histórica.
- **Efectivo esperado:** fondo inicial + entradas en efectivo (incluidos ingresos adicionales) − salidas en efectivo (gastos, retiros, pagos, devoluciones). Por turno cerrado utiliza el esperado guardado al cierre. Por día muestra las cajas que seguían abiertas al finalizar ese día, incluyendo su saldo previo: evita sumar fondos reutilizados de turnos cerrados. Si todas cerraron, cero cajas abiertas no significa que el cierre tuviera cero dinero: consultar ese turno.

Seleccionar fecha y Día completo (todas MIS cajas) o un turno y pulsar Ver. Administradores/supervisores pueden consultar turnos ajenos; trabajadores únicamente los propios. Turno completo puede abarcar más de un día; el selector de fecha aplica al modo día. Últimos 100 turnos disponibles en el selector. La fecha civil usa America/Santiago, incluyendo días de 23/25 horas.

Los nuevos reembolsos y reducciones de deuda guardan turno incluso sin salida de dinero. Migración aditiva: las devoluciones antiguas con cobro se vinculan a su turno; las que no pueden identificarse conservan una advertencia y atribución al vendedor original. No se inventa su turno.

Lectura en una transacción RepeatableRead: cada indicador procede de la misma instantánea PostgreSQL, sin sumar dos veces ventas normalizadas y cobros. Pruebas de integración cubren crédito, abonos, ingreso adicional, egreso operativo, retiro, pago, devolución posterior, repetición, autorización y cierre.

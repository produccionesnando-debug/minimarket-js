# Etapa 5 — POS y operaciones del minimarket

Se amplía el proyecto existente con dos migraciones aditivas. No se reemplazan ventas, cajas, contactos, proveedores, ciclos, facturas ni documentos del negocio. Antes de migrar se guardaron un respaldo privado y hashes de las columnas originales de 22 tablas; se comparan después de las pruebas. Las pruebas y capturas usan bases aisladas.

## Ventas y Caja

Abre **Ventas y Caja** en el menú. Si no tienes turno abierto, **Abrir caja** lleva al formulario con trabajador, caja utilizada, fondo y observaciones. **Caja y ventas (turnos)** conserva gestión de responsables, gastos, retiros, cierres históricos y revisión administrativa.

El POS separa catálogo/escaneo, carrito y cobro. Tiene filtros por categoría, marca, proveedor y existencias; búsqueda por nombre, código de barras y código interno; cantidades táctiles, eliminación, precios y subtotales. **Actualizar precios y existencias del carrito** consulta el catálogo vigente y permite revisar el total antes de cobrar. El servidor vuelve a comprobar precios, existencias y permisos dentro de la transacción.

Los lectores USB/Bluetooth deben estar en modo teclado. El campo acepta **Enter/CR/LF**, **Tabulación** o botón manual; la configuración se conserva en ese navegador. **F2** enfoca el lector y **F8** cobra. Escanear el mismo producto incrementa unidades. Códigos desconocidos muestran alerta y un enlace de creación solo a administración. La prueba automatizada emula el teclado del lector; no se probó un dispositivo físico desde Linux. El endpoint de búsqueda puede reutilizarse para una futura cámara, que todavía no está implementada.

Se registran efectivo, débito, tarjeta de crédito, transferencia, crédito del minimarket a clientes y pagos mixtos. El efectivo recibido calcula vuelto; solo el importe aplicado queda como entrada de caja. Débito, tarjeta de crédito y transferencia no aumentan efectivo físico. Una venta a crédito queda pendiente de cobro. Los descuentos requieren permiso administrativo y motivo.

El comprobante conserva líneas, precios, descuento, formas de cobro, vuelto, trabajador, caja y crédito. **Imprimir comprobante interno** usa la impresión del navegador. **No es boleta ni factura tributaria**, y la app no procesa cargos de tarjetas ni ejecuta transferencias. **Buscar ventas y devoluciones** consulta hasta 100 coincidencias por número, producto, código, cliente o fechas, respetando el acceso a turnos.

### Resumen superior del día

Consulta tus turnos, con fecha de Chile; se refresca tras movimientos, cada 15 segundos mientras la pantalla está activa y al regresar a la ventana.

- Ventas brutas: importe de ventas registradas, antes de devoluciones (con descuentos comerciales ya aplicados).
- Ventas netas: ventas brutas menos devoluciones.
- Cobros por medio: ventas cobradas y abonos, menos reembolsos; los ingresos adicionales se identifican en su propio registro.
- Saldo neto del día (actualizado): ventas netas menos egresos operativos registrados. No es utilidad contable, cobros ni efectivo. Ver [resumen-financiero.md](resumen-financiero.md) para alcance por día y turno y fórmulas actuales.
- Efectivo esperado: fondo del turno abierto + cobros/abonos/ingresos en efectivo − reembolsos y salidas en efectivo.
- Utilidad estimada: ventas netas − costo histórico neto de lo vendido − gastos operativos − mermas. Si falta costo histórico, se muestra información insuficiente. No representa utilidad contable.

## Importación XLSX y CSV

**Inventario → Importar productos desde Excel**, solo administración. Primera hoja XLSX o CSV UTF-8 con coma/punto y coma; hasta 2 MB, 1.000 filas y 60 columnas. Se comprueba un límite descomprimido de 32 MB. No se ejecutan fórmulas: deben reemplazarse por valores.

1. Subir el archivo y revisar las primeras filas.
2. Relacionar manualmente cada columna. Las sugerencias se pueden cambiar. Nombre, costo y precio explícitos son necesarios para crear; se acepta cero cuando corresponda. Los campos adicionales se conservan en `Product.extra`.
3. Elegir crear nuevos/omitir existentes, crear y actualizar, u omitir todo. Puede elegirse una acción por fila.
4. Revisar errores, códigos duplicados, conflictos y proveedores desconocidos. Las filas inválidas se omiten y se informan.
5. Confirmar la importación. Reemplazar precios/costos o stock/mínimos exige autorización y una segunda confirmación explícita. Sin ella se conservan los valores existentes.
6. Descargar el resultado por fila como CSV.

Las operaciones se procesan en grupos de 100 dentro de una única transacción: si cambió un producto desde la vista previa, se revierte la importación y se solicita revisar otra vez. Repetir una importación completada no duplica productos, ajustes ni cambios de precios.

Los códigos son texto; se preservan ceros iniciales y formatos de Excel como `000000`. Códigos numéricos imprecisos se rechazan; la pérdida de ceros que ya ocurrió en otro sistema no se puede reconstruir. Sin barcode se usa el identificador visible `INTERNO:<código interno>`, no un EAN inventado. El costo/precio usa enteros CLP: `1.200`, `1200`, `1200,00`; se rechazan fracciones de unidad/peso y notación científica. Si el archivo excede los límites, sepáralo en archivos más pequeños.

El Excel de ejemplo está marcado como demostración. En la instancia del negocio puede importarse al catálogo demo, separado de los productos reales. La demostración Windows completa identifica toda la instancia como ficticia.

## Categorías y precios

**Configuración → Categorías** permite categorías/subcategorías, edición y desactivación, con prevención de ciclos. El catálogo textual anterior se conserva; puede vincularse desde la edición administrativa o la importación.

**Precios por canal** compara costo, minimarket y sugerencia PedidosYa. La regla inicial es +20%, configurable entre 0 y 200%, con redondeo a 1/10/50/100 pesos, cercano/arriba/abajo. Cada producto puede seguir la regla o tener un precio fijo. Ediciones administrativas, importaciones y cambios de costo por recepción dejan historial. Cambios globales quedan en auditoría.

La sugerencia interna no equivale a precio publicado ni garantiza rentabilidad. No se publican precios y no se infieren comisiones, descuentos externos o liquidaciones netas. Esa información requiere integración oficial y autorización posterior.

## Clientes y créditos

**Clientes y créditos** incluye ficha, contacto opcional, dirección opcional, fecha, límite, notas, compras, líneas, autorizaciones, vencimiento y saldo. Administración/supervisión autorizan créditos; trabajadores pueden registrar abonos desde su caja abierta. Cada abono indica monto, medio, receptor y referencia. No crea otra venta. Hay pagos parciales, alertas de vencimiento y estado de cuenta imprimible/CSV.

Una devolución reduce primero el crédito aún impago de esa venta. Solo el resto ya cobrado se reembolsa. De este modo no se entrega dinero por una compra que aún no fue pagada, ni se genera un saldo negativo del cliente.

## Mermas, devoluciones y cambios

**Mermas** guarda producto, unidades, fecha, costo vigente, motivo configurable, responsable, notas y foto opcional privada. Descuenta stock sin crear venta ni salida de dinero. Los ajustes por diferencia de inventario requieren administración. Las mermas de trabajadores se consultan por responsable; administración/supervisión pueden revisar todas.

Desde el comprobante, usuarios autorizados seleccionan líneas, unidades, destino y motivo de devolución, con confirmación expresa. Se contabilizan devoluciones anteriores y no se pueden exceder unidades vendidas. Si vuelve a stock se genera una entrada; si no está apto, se registra una merma sin descontar otra vez la unidad que ya salió. Se conserva la venta original.

**Registrar producto de cambio** abre una nueva venta vinculada a la devolución. El reembolso y el cobro del reemplazo son operaciones separadas y trazables; no se presupone que tengan el mismo precio o medio de pago. No se borra ni reescribe el comprobante original. Los reembolsos en efectivo requieren fondos suficientes en la caja abierta.

## Informes y seguridad

Estadísticas y sus exportaciones distinguen ventas brutas, devoluciones, ventas netas, cobros, crédito otorgado, deuda pendiente, gastos, compras, pagos a proveedores y mermas. Las categorías de ventas usan la instantánea de cada línea y los costos son históricos. Los abonos y reembolsos se registran en la fecha y turno de su movimiento; nunca se vuelven a contar como una venta. Los cierres anteriores conservan sus valores aunque se pague una deuda o devuelva una venta en otro turno.

La caja combina ventas antiguas sin libro de cobros (`paymentVersion=0`) con movimientos normalizados de las nuevas (`paymentVersion=1`), evitando contar ambos. Transacciones serializables y claves únicas protegen stock, límites, cobros, abonos y devoluciones; un cierre simultáneo no genera dos cierres ni dos auditorías. Permisos se verifican en servidor, no solo ocultando botones.

## Validación y Windows

24 pruebas unitarias, 8 de integración y 13 de navegador. La prueba nueva de navegador recorre Excel con duplicados, lector, vuelto, tarjeta, mixto, fiado, abono, merma, devolución y cierre; verifica stock, dinero y ausencia de duplicados. Integración prueba última unidad concurrente, claves repetidas/diferentes cargas, precios cambiados, importación obsoleta, redondeos, límites/permisos y cierres simultáneos con movimientos posteriores. La compilación de producción incluye TypeScript.

La descarga Windows usa solo datos ficticios y mantiene Node/PostgreSQL locales. Incluye ejemplo Excel, capturas y guía. El restaurador aplica migraciones pendientes al actualizar una carpeta existente, conserva datos y no vuelve a sembrar; se valida tanto instalación nueva como actualización desde v3. Conserva una copia de la carpeta anterior antes de actualizar. No se ejecuta Windows nativo en esta nube: aplicación, dependencias, restauración, actualización y pantallas se comprueban en Linux.

Pendientes concretos: lectura de barcode con cámara, SII/boleta electrónica, procesamiento bancario/terminales y conexión oficial de PedidosYa (publicación, comisiones y conciliación). No hay tienda pública ni despliegue productivo.

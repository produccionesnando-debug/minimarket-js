# Bienvenida diaria y tickets internos

## Saludo y biblioteca

La primera entrada del trabajador al área privada en un día de Chile muestra una tarjeta con saludo por hora, nombre, fecha, texto bíblico y frase de ánimo. Es una tarjeta no modal: puede cerrarse sin bloquear ventas ni navegación. Su cierre se guarda por trabajador y fecha en PostgreSQL. Al día siguiente vuelve a aparecer. En Inicio queda una tarjeta pequeña con **Ver bienvenida**.

La rotación utiliza la fecha civil de **America/Santiago**, no la fecha UTC del servidor. Se elige de forma reproducible entre los versículos publicados, se evita repetir el de ayer si hay alternativas y se fija una copia del texto/referencia/traducción para ese día. Dos trabajadores ven el mismo texto, con su propio nombre y estado de bienvenida. Las ediciones de biblioteca afectan próximas selecciones; el texto ya fijado para hoy no cambia.

Administrador → **Versículos**: agregar, editar y desactivar. Guardar texto, referencia, traducción, tema y derechos de reproducción. Se pide confirmar la referencia y permiso; si la traducción es autorizada, indicar su autorización. No se importa una Biblia moderna protegida.

La selección inicial contiene diez textos breves de **Reina-Valera 1909 (dominio público)**, contrastados con `SpaRV: La Santa Biblia Reina-Valera (1909)` de [scrollmapper/bible_databases](https://github.com/scrollmapper/bible_databases). Se conserva su ortografía histórica. En Salmos 46:1 se usa el texto principal sin el encabezado musical. La base solo carga esta selección, no una traducción completa. No se usa Reina-Valera 1960 como biblioteca inicial.

## Configurar tickets

Administrador → **Impresoras y tickets**:

- Ancho 58 u 80 mm.
- Mostrar/ocultar logo y mensaje bíblico.
- Solicitar impresión automática después de guardar la venta (desactivado inicialmente).
- Cajero por nombre, identificador interno o ninguno.
- Mensaje de agradecimiento.
- Versículo del día, uno especial para clientes o mensaje fijo de hasta 180 caracteres.
- Activar bienvenida y configurar la frase de ánimo.
- Abrir una página de prueba, claramente marcada como ficticia, que no registra una venta.

Los versículos de más de 180 caracteres se omiten del ticket, sin truncar ni alterar la cita. Permanecen disponibles para la bienvenida. Los iconos y la versión monocromática dependen de que el original del logo esté cargado en **Identidad del negocio**; nunca se redibuja ni se sustituye por un carrito genérico. El original permanece intacto.

## Venta e impresión

La venta se guarda primero mediante el flujo transaccional e idempotente existente, actualizando caja e inventario. Después aparecen **Imprimir / reimprimir ticket**, vista previa y el vuelto confirmado. La impresión automática, si está activada, intenta cargar el ticket en un marco del mismo origen y abrir su diálogo; el navegador puede impedirlo. El botón manual queda disponible.

Los tickets incluyen número interno, fecha/hora Chile, cajero según configuración, productos y cantidades, precios/subtotales, descuento, total, medios de pago, recibido/vuelto cuando están registrados y pie configurable. Distinguen anticipos, abonos posteriores, devoluciones y crédito. No incluyen nombre, teléfono o dirección del cliente ni datos completos de tarjeta.

Historial de ventas → detalle → **Ver e imprimir ticket** permite reimprimir. Cada intento queda auditado como solicitud inicial, reimpresión o prueba, con trabajador y ancho. **REQUESTED significa solicitud de diálogo, no confirma que salió papel.** Cerrar/cancelar o fallar la impresora no vuelve a cobrar ni elimina la venta.

El formato es **ticket interno**, con la advertencia **No es boleta ni factura tributaria**. El modelo FiscalDocument prepara una futura asociación única por venta e identificador del emisor; no se conecta al SII ni emite documentos tributarios ahora.

## Windows: conectar una térmica

1. Conectar por USB, red o Bluetooth según el fabricante. En Bluetooth, emparejar en Windows y comprobar que el modelo permite imprimir mediante su controlador; no todos los modelos BLE se comportan igual.
2. Instalar el controlador oficial del fabricante, obtenido de su sitio oficial. En Windows abrir **Configuración → Impresoras y escáneres** (según versión: Bluetooth y dispositivos / Dispositivos), agregar el equipo y abrir sus preferencias.
3. Configurar rollo de 58 u 80 mm y probar la página de Windows. Si no aparece ese ancho, crear el tamaño de papel admitido por el controlador siguiendo sus instrucciones.
4. En MiniMarket JS, elegir el mismo ancho y abrir **Página de prueba**.
5. Pulsar **Imprimir / reimprimir ticket**. Elegir la térmica en el diálogo de Edge/Chrome o usar el diálogo del sistema. Seleccionar el tamaño del controlador, escala 100 %, sin encabezados/pies del navegador y márgenes mínimos compatibles. Si el logo no aparece, habilitar gráficos de fondo según el navegador.
6. Revisar legibilidad, alineación y corte usando únicamente la página de prueba. El corte automático depende del modelo y controlador; no está implementado por la aplicación web.

El CSS define el ancho del ticket y una página de 297 mm de alto para la vista PDF; los tickets largos pueden paginar. En rollo, la longitud efectiva depende del controlador y su configuración. Ajustar el tamaño personalizado en Windows si el equipo requiere otra longitud.

**Hardware realmente probado: ningún modelo físico.** Se prueban el renderizado en Chromium, dimensiones PDF 58/80 mm, importes, privacidad, solicitudes y reimpresión con la llamada de impresión simulada. Guardar PDF tampoco certifica una impresora. No se promete impresión silenciosa ni selección programática de impresora en todos los navegadores.

## Alternativa futura ESC/POS

Una opción es QZ Tray, aplicación local que comunica el navegador con controladores y puede enviar comandos ESC/POS a equipos compatibles. Requiere instalarla y verificar el modelo/controlador, configurar confianza y autorizar el origen. La alternativa se debe implementar con trabajos firmados, certificados y validación de origen/permisos en un servicio local; no exponer un puerto de impresión sin autenticación ni aceptar comandos arbitrarios desde Internet. El proyecto oficial es [qzind/tray](https://github.com/qzind/tray).

Otra posibilidad es una aplicación de escritorio firmada con un adaptador de impresión local. Ambas requieren validación de equipo, firma/confianza y pruebas físicas. Esta entrega no instala QZ Tray, abre servicios locales nuevos ni activa impresión directa/silenciosa.

## Evidencia de esta entrega

56 pruebas únicas aprobadas: 24 unitarias, 16 de integración y 16 de navegador. La prueba ampliada de tickets también simula un fallo del intento automático y verifica una sola venta, un solo descuento de stock y conservación de sus cobros. Se generaron capturas reales del saludo, ventas y acceso, y PDF de 58/80 mm, exclusivamente con datos ficticios de una base separada.

La instalación limpia de dependencias de producción y la restauración/actualización del paquete Windows se verifican en Linux; esto no sustituye una prueba del iniciador nativo Windows ni una impresora física.

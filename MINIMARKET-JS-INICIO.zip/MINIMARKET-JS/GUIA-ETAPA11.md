# Etapa 11 — Espera y recuperación segura

## Operación

«Dejar venta en espera» guarda únicamente productos, cantidades e importes manuales, con fecha, trabajador e identificador. No crea una venta, un cobro ni una reserva de stock. La pestaña permite recuperar o cancelar. Los trabajadores acceden a sus propias ventas; administración y supervisión pueden recuperar ventas autorizadas. Al recuperarlas se actualizan precios y se valida disponibilidad. La asignación al trabajador y turno se comprueba nuevamente dentro de la transacción del cobro; una cancelación concurrente no se cobra. Una venta cobrada se devuelve mediante el flujo autorizado, nunca cancelando el borrador.

Los borradores del usuario y turno tienen una revisión para impedir sobrescrituras desde otra pestaña. Se conserva además una copia mínima local con identificadores y cantidades para interrupciones de conexión. Al volver se solicita recuperación; nunca se cobra automáticamente. El acceso inicial comprueba si el identificador ya corresponde a una venta registrada. No se guardan números de tarjeta ni credenciales bancarias. En computadores compartidos deben usarse cuentas individuales y proteger el acceso al perfil de Windows y navegador.

F9 abre el diálogo de cobro y Enter confirma los datos activos. El identificador se mantiene durante un fallo de respuesta. Antes de reintentar se consulta si la venta existe; la transacción del servidor también impide duplicados. Si falla la comprobación, no se envía otro cobro.

Seleccionar débito, crédito o transferencia no significa aprobación bancaria. El trabajador debe confirmar que verificó la aprobación y puede registrar su referencia; eso queda auditado como verificación manual, no aprobación de una API bancaria. El punto de venta rechaza nuevos cobros electrónicos sin esa confirmación. Los registros históricos sin verificación se identifican explícitamente para conciliación. La aplicación no realiza transacciones del terminal bancario. Ante una respuesta incierta, revisa también el terminal antes de repetir una operación externa.

## Caja y permisos

Cada turno conserva usuario, terminal, apertura y fondo inicial. Antes de cerrar se desglosan ventas por medio, crédito de clientes, abonos, gastos, retiros y reembolsos. El cierre guarda una instantánea con esperado, contado y diferencia. No se suma dinero electrónico al efectivo físico. Cualquier diferencia, por pequeña que sea, queda pendiente de autorización administrativa; es una regla conservadora mientras el negocio no defina un umbral. Solo administración aprueba los cierres y modifica precios o trabajadores. Supervisión conserva los permisos existentes y no recibe permiso para cambiar precios o aprobar ajustes de inventario.

## Respaldos y actualización

El iniciador de Windows conserva la base y logo en `.local`. Para actualizar: detén el iniciador anterior, copia la carpeta COMPLETA a un lugar seguro y extrae la versión nueva en otra carpeta. Copia `.local`, `ACCESO.txt` y `comprobantes-demo` a la nueva antes de abrirla. No copies una base PostgreSQL mientras está ejecutándose; detén primero el iniciador. Guarda los respaldos en un dispositivo distinto y comprueba que puedas restaurarlos. El ZIP de demostración no contiene los datos de tu instalación local ni es un respaldo de ellos.

La restauración de demostración verifica checksums de migraciones y no vuelve a cargar datos ficticios sobre una base ya iniciada. Las pruebas de actualización deben comprobar preservación de datos, logo y movimientos en una copia aislada antes de distribuir una versión. No se implementa en esta etapa publicación, respaldo remoto automático ni integración bancaria.

## Evidencia de preservación

La revisión compara las 22 tablas y columnas originales contra la instantánea previa. Solo se excluye de esa comparación la nueva configuración solicitada Pan 20, cuyo precio, costo y stock permanecen sin confirmar. El directorio original conserva 25 proveedores, 9 contactos y 20 ciclos. Las pruebas y capturas usan bases aisladas ficticias. La restauración nueva y la actualización de una copia previa se ejecutaron dos veces, conservando bytes de logo sintético, ediciones y ventas.

Al dejar una venta en espera se limpian también el efectivo recibido, descuentos, cliente y distribución de pagos para atender a otra persona. Cambiar el carrito o reparto de medios invalida la confirmación bancaria anterior. La caja tradicional usa el mismo servicio transaccional de ventas y comprobación de existencias, lotes e idempotencia del POS.

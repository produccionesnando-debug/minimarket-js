const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const {Client}=require('./app/node_modules/pg');
const root=__dirname;
async function restore(config){
  if(config.host!=='127.0.0.1'||!(config.database==='minimarket_demo'||/^minimarket_.*_test$/.test(config.database)))throw Error('La demostración solo utiliza una base local aislada.');
  const admin=new Client({...config,database:'postgres'});await admin.connect();
  try{if(!(await admin.query('SELECT 1 FROM pg_database WHERE datname=$1',[config.database])).rowCount)await admin.query('CREATE DATABASE "'+config.database+'"');}finally{await admin.end();}
  const client=new Client(config);await client.connect();
  try{
    const ready=await client.query("SELECT to_regclass('public._demo_bootstrap') AS ready");if(ready.rows[0].ready)return;
    await client.query('BEGIN');
    const folder=path.join(root,'app','prisma','migrations');
    for(const name of fs.readdirSync(folder).sort()){const file=path.join(folder,name,'migration.sql');if(fs.existsSync(file))await client.query(fs.readFileSync(file,'utf8'));}
    const tables=JSON.parse(fs.readFileSync(path.join(root,'datos-demo.json'),'utf8'));
    const jsonColumns=new Set(['options','details','lines','changes']);
    const quote=s=>'"'+s.replaceAll('"','""')+'"';
    for(const {table,rows} of tables){for(const row of rows){const columns=Object.keys(row);const values=columns.map(c=>jsonColumns.has(c)&&row[c]!==null?JSON.stringify(row[c]):row[c]);await client.query('INSERT INTO '+quote(table)+' ('+columns.map(quote).join(',')+') VALUES ('+values.map((_,i)=>'$'+(i+1)).join(',')+')',values);}}
    await client.query('CREATE TABLE "_prisma_migrations" ("id" varchar(36) PRIMARY KEY,"checksum" varchar(64) NOT NULL,"finished_at" timestamptz,"migration_name" varchar(255) NOT NULL,"logs" text,"rolled_back_at" timestamptz,"started_at" timestamptz NOT NULL DEFAULT now(),"applied_steps_count" integer NOT NULL DEFAULT 0)');
    for(const name of fs.readdirSync(folder).sort()){const file=path.join(folder,name,'migration.sql');if(fs.existsSync(file))await client.query('INSERT INTO "_prisma_migrations" (id,checksum,finished_at,migration_name,applied_steps_count) VALUES ($1,$2,now(),$3,1)',[crypto.randomUUID(),crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),name]);}
    await client.query('CREATE TABLE _demo_bootstrap (version int PRIMARY KEY)');await client.query('INSERT INTO _demo_bootstrap VALUES (1)');await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e;}finally{await client.end();}
}
module.exports={restore};

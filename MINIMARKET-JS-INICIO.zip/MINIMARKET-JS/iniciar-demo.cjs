const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const net=require('node:net');const {spawn,spawnSync}=require('node:child_process');
const {restore}=require('./restaurar-demo.cjs');
const root=__dirname;const local=path.join(root,'.local');const pgBin=path.join(root,'postgres','bin');const pgData=path.join(local,'base');const configFile=path.join(local,'config.json');const access=path.join(root,'ACCESO.txt');
let server;let startedDatabase=false;let stopping=false;
function open(target){const p=spawn('rundll32.exe',['url.dll,FileProtocolHandler',target],{detached:true,stdio:'ignore'});p.on('error',()=>{});p.unref();}
function run(program,args,quiet=false){const r=spawnSync(path.join(pgBin,program),args,{stdio:quiet?'ignore':'inherit',windowsHide:true});if(r.error)throw r.error;if(r.status!==0)throw Error('No se pudo iniciar la base local. Revisa .local/postgres.log.');}
async function freePort(preferred){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',()=>{if(preferred)freePort(0).then(resolve,reject);else reject(Error('No hay un puerto local disponible.'));});s.listen(preferred,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});}
async function stop(){if(stopping)return;stopping=true;if(server&&!server.killed)server.kill();if(startedDatabase)spawnSync(path.join(pgBin,'pg_ctl.exe'),['-D',pgData,'-m','fast','-w','stop'],{stdio:'ignore',windowsHide:true});}
async function main(){
  if(process.platform!=='win32'||process.arch!=='x64')throw Error('Este paquete requiere Windows 10/11 de 64 bits.');
  console.log('\nMINIMARKET JS - DEMOSTRACION LOCAL\nSolo datos ficticios. No publica nada en Internet.\n');
  const system=path.join(process.env.SystemRoot||'C:\\Windows','System32');
  if(!fs.existsSync(path.join(system,'vcruntime140.dll'))||!fs.existsSync(path.join(system,'msvcp140.dll'))||!fs.existsSync(path.join(system,'vcruntime140_1.dll'))){console.log('Falta el complemento gratuito Microsoft Visual C++.\nSe abrira la descarga oficial. Instalalo y vuelve a abrir INICIAR-MINIMARKET.cmd.');open('https://aka.ms/vs/17/release/vc_redist.x64.exe');process.exitCode=1;return;}
  fs.mkdirSync(local,{recursive:true});let config=fs.existsSync(configFile)?JSON.parse(fs.readFileSync(configFile,'utf8')):null;
  if(config?.appPid){try{process.kill(config.appPid,0);const r=await fetch('http://127.0.0.1:'+config.appPort+'/login',{signal:AbortSignal.timeout(1500)});if(r.ok){open('http://127.0.0.1:'+config.appPort+'/login');spawn('notepad.exe',[access],{detached:true,stdio:'ignore'}).unref();console.log('La aplicacion ya esta abierta.');return;}}catch{}}
  if(!config){config={database:'minimarket_demo',host:'127.0.0.1',port:await freePort(55432),user:'minimarket',password:crypto.randomBytes(24).toString('hex')};fs.writeFileSync(configFile,JSON.stringify(config));}
  const database={database:config.database,host:config.host,port:config.port,user:config.user,password:config.password};
  const pwfile=path.join(local,'clave-temporal.txt');
  if(!fs.existsSync(path.join(pgData,'PG_VERSION'))){console.log('Preparando PostgreSQL privado en esta carpeta...');fs.writeFileSync(pwfile,config.password+'\n');try{run('initdb.exe',['-D',pgData,'-U','minimarket','--encoding=UTF8','--locale=C','--auth=scram-sha-256','--pwfile='+pwfile]);}finally{fs.rmSync(pwfile,{force:true});}}
  const running=spawnSync(path.join(pgBin,'pg_ctl.exe'),['-D',pgData,'status'],{stdio:'ignore',windowsHide:true}).status===0;
  if(!running){run('pg_ctl.exe',['-D',pgData,'-l',path.join(local,'postgres.log'),'-o','-h 127.0.0.1 -p '+config.port,'-w','start']);startedDatabase=true;}
  console.log('Cargando la demostracion. Tus pruebas anteriores se conservan...');await restore(database);
  const appPort=await freePort(3000);const url='http://127.0.0.1:'+appPort+'/login';
  const env={...process.env,NODE_ENV:'production',DATABASE_URL:'postgresql://minimarket:'+config.password+'@127.0.0.1:'+config.port+'/minimarket_demo',PRIVATE_UPLOAD_DIR:path.join(root,'comprobantes-demo')};
  server=spawn(process.execPath,[path.join(root,'app','node_modules','next','dist','bin','next'),'start','--hostname','127.0.0.1','--port',String(appPort)],{cwd:path.join(root,'app'),env,stdio:'inherit',windowsHide:true});
  server.on('error',e=>console.error(e.message));server.once('exit',code=>{stop().finally(()=>{process.exitCode=code||0;});});
  config.appPid=server.pid;config.appPort=appPort;fs.writeFileSync(configFile,JSON.stringify(config));
  let ready=false;for(let i=0;i<60;i++){if(server.exitCode!==null)break;try{const r=await fetch(url,{signal:AbortSignal.timeout(1500)});if(r.ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,1000));}
  if(!ready)throw Error('La aplicacion no respondio. Revisa el mensaje que aparece arriba.');
  fs.writeFileSync(path.join(root,'ABRIR-APLICACION.url'),'[InternetShortcut]\r\nURL='+url+'\r\n');
  console.log('\nLISTO. Direccion: '+url+'\nSe abriran el navegador y el archivo con tus datos de acceso.\nMantén esta ventana abierta mientras pruebas. Para detener: Ctrl+C.\n');
  spawn('notepad.exe',[access],{detached:true,stdio:'ignore'}).unref();open(url);
}
process.on('SIGINT',()=>stop().finally(()=>process.exit()));process.on('SIGTERM',()=>stop().finally(()=>process.exit()));
main().catch(async e=>{console.error('\n'+e.message);await stop();process.exitCode=1;});
